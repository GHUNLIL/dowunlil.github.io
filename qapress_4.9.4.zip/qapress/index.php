<?php defined('ABSPATH') || exit;
/**
 * Plugin Name: QAPress
 * Plugin URI: https://www.wpcom.cn/plugins/qapress.html
 * Description: WordPress问答功能插件
 * Version: 4.9.4
 * Author: WPCOM
 * Author URI: https://www.wpcom.cn
 * Requires PHP: 7.0
 * Requires at least: 6.1
 */

define( 'QAPress_VERSION', '4.9.4' );
define( 'QAPress_DIR', plugin_dir_path( __FILE__ ) );
define( 'QAPress_URI', plugins_url( '/', __FILE__ ) );

$themer_path = is_dir($framework_path = QAPress_DIR . '/admin/') ? $framework_path : plugin_dir_path( __DIR__ ) . '/Themer/admin/' ;
require $themer_path . 'load.php';

add_action('plugins_loaded', function(){
    do_action('wpcom_setup_plugin_themer');
    $QAPress_info = array(
        'slug' => 'QAPress',
        'name' => 'QAPress',
        'ver' => QAPress_VERSION,
        'title' => '问答',
        'icon' => 'dashicons-editor-help',
        'position' => 30,
        'key' => 'qa_options',
        'plugin_id' => '46b3ade48ebb2b3e',
        'basename' => plugin_basename( __FILE__ )
    );
    $GLOBALS['QAPress'] = new WPCOM_Plugin_Panel($QAPress_info);
}, 5);

add_action('activate_'. plugin_basename( __FILE__ ), 'flush_rewrite_rules');

require_once QAPress_DIR . 'includes/sql.php';
require_once QAPress_DIR . 'includes/html.php';
require_once QAPress_DIR . 'includes/rewrite.php';
require_once QAPress_DIR . 'includes/ajax.php';
require_once QAPress_DIR . 'includes/functions.php';