<?php defined( 'ABSPATH' ) || exit;

if(!class_exists('WPCOM_Widget')){
    abstract class WPCOM_Widget extends WP_Widget {
        public $widget_cssclass;
        public $widget_description;
        public $widget_id;
        public $widget_name;
        public $settings;

        public function __construct() {
            $widget_ops = array(
                'classname'   => $this->widget_cssclass,
                'description' => $this->widget_description,
                'customize_selective_refresh' => true
            );

            parent::__construct( 'wpcom-'.$this->widget_id, $this->widget_name, $widget_ops );

            add_action( 'save_post', array( $this, 'flush_widget_cache' ) );
            add_action( 'deleted_post', array( $this, 'flush_widget_cache' ) );
            add_action( 'switch_theme', array( $this, 'flush_widget_cache' ) );
        }

        public function get_cached_widget( $args ) {
            $cache = wp_cache_get( $this->get_widget_id_for_cache( $this->widget_id ), 'widget' );

            if ( ! is_array( $cache ) ) {
                $cache = array();
            }

            if ( isset( $cache[ $this->get_widget_id_for_cache( $args['widget_id'] ) ] ) ) {
                echo $cache[ $this->get_widget_id_for_cache( $args['widget_id'] ) ];
                return true;
            }

            return false;
        }

        public function cache_widget( $args, $content, $expire=0 ) {
            global $options;
            if($options && isset($options['enable_cache']) && $options['enable_cache']=='0') return $content;
            $cache = wp_cache_get( $this->get_widget_id_for_cache( $this->widget_id ), 'widget' );
            if ( ! is_array( $cache ) ) {
                $cache = array();
            }
            $cache[ $this->get_widget_id_for_cache( $args['widget_id'] ) ] = $content;
            wp_cache_set( $this->get_widget_id_for_cache( $this->widget_id ), $cache, 'widget', $expire );
            return $content;
        }

        public function flush_widget_cache() {
            foreach ( array( 'https', 'http' ) as $scheme ) {
                wp_cache_delete( $this->get_widget_id_for_cache( $this->widget_id, $scheme ), 'widget' );
            }
        }

        public function widget_start( $args, $instance ) {
            echo $args['before_widget'];
            if ( $title = apply_filters( 'widget_title', isset($instance['title']) && is_string($instance['title']) ? $instance['title'] : '', $instance, $this->id_base ) ) {
                echo $args['before_title'] . $title . $args['after_title'];
            }
        }

        public function widget_end( $args ) {
            echo $args['after_widget'];
        }

        public function update( $new_instance, $instance ) {
            // Loop settings and get values to save.
            foreach ( $this->settings as $key => $setting ) {
                $new_instance[ $key ] = apply_filters( 'wpcom_widget_settings_sanitize_option', $new_instance[ $key ], $instance, $key, $setting );
            }
            $this->flush_widget_cache();
            return $new_instance;
        }

        public function form( $instance ) {
            if ( empty( $this->settings ) ) return; ?>
            <widget-panel base-id="<?php echo 'wpcom-'.$this->widget_id;?>"><?php echo base64_encode(wp_json_encode($instance));?></widget-panel>
        <?php }

        protected function get_widget_id_for_cache( $widget_id, $scheme = '' ) {
            if ( defined( 'ICL_SITEPRESS_VERSION' ) ){ // WPML兼容
                $lang = defined( 'ICL_LANGUAGE_CODE' ) ? ICL_LANGUAGE_CODE : get_bloginfo( 'language' );
                $widget_id = $widget_id . '-' . $lang;
            }

            if ( $scheme ) {
                $widget_id_for_cache = $widget_id . '-' . $scheme;
            } else {
                $widget_id_for_cache = $widget_id . '-' . ( is_ssl() ? 'https' : 'http' );
            }

            return apply_filters( 'wpcom_widget_cached_id', $widget_id_for_cache );
        }
    }

    add_action('load-customize.php', 'wpcom_customize_widget_init');
    add_action('admin_print_scripts-widgets.php', 'wpcom_customize_widget_init');
    function wpcom_customize_widget_init(){
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        WPCOM_ADMIN_UTILS::panel_script();
    }

    add_action('sidebar_admin_page', 'wpcom_widget_panel_options');
    add_action('customize_controls_head', 'wpcom_widget_panel_options');
    function wpcom_widget_panel_options(){
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php'; ?>
        <script>_plugins_options = [<?php echo wpcom_init_widget_options();?>];</script>
        <div style="display: none;"><?php wp_editor( 'EDITOR', 'WPCOM-EDITOR', WPCOM_ADMIN_UTILS::editor_settings(array('textarea_name'=>'EDITOR-NAME')) );?></div>
    <?php }

    function wpcom_init_widget_options(){
        global $wp_widget_factory;
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        $widgets = $wp_widget_factory->widgets;
        $settings = array();
        foreach ($widgets as $name => $widget){
            if(preg_match('/^wpcom_/i', $name)){
                $settings[$widget->id_base] = $widget->settings;
            }
        }
        $res = array('type' => 'widget');
        $res['ver'] = WPCOM_ADMIN_VERSION;
        $res['plugin-id'] = 'plugin-id';
        $res['settings'] = $settings;
        $res['pages'] = WPCOM_ADMIN_UTILS::get_all_pages();
        $res['framework_url'] = WPCOM_ADMIN_URI;
        $res['framework_ver'] = WPCOM_ADMIN_VERSION;
        $res = apply_filters('wpcom_widget_panel_options', $res);
        return wp_json_encode($res);
    }
}