<?php
$_user = get_user_by('ID', $comment->user_id);
$_avatar = get_avatar( $comment->user_id ? (int)$comment->user_id : $comment->comment_author_email, '60', '', $comment->user_id ? $comment->user_nicename : $comment->comment_author );
$del = current_user_can( 'manage_options' ) ? 1 : 0;
$reply_to_name = '';
$max_depth = (int)get_option('thread_comments_depth');
$max_depth = $max_depth ? $max_depth : 5;
if($parent && $parent != $comment->comment_parent){
    $reply_to = get_comment($comment->comment_parent);
    $reply_to_user = get_user_by('ID', $reply_to->user_id);
    if(!($_user && isset($_user->ID) && $reply_to_user->ID == $_user->ID)){
        if($reply_to_user && isset($reply_to_user->ID) && $reply_to_user->ID){
            $reply_to_name = '<span class="as-comment-author">' . $reply_to_user->display_name . '</span>';
            if(class_exists('WPCOM_Member') && apply_filters( 'wpcom_member_show_profile' , true )){
                $reply_to_url = get_author_posts_url( $reply_to_user->ID );
                $reply_to_name = '<a class="as-comment-url j-user-card" data-user="'.$reply_to_user->ID.'" href="'.$reply_to_url.'" target="_blank">' .$reply_to_name.'</a>';
            }
        }else{
            $reply_to_name = '<span class="as-comment-author">' . $reply_to->comment_author . '</span>';
        }
    }
}
if($reply_to_name) $reply_to_name = '<i class="wpcom-icon wi"><svg viewBox="0 0 16 16"><path d="M10.727 7.48a.63.63 0 0 1 0 1.039l-4.299 2.88c-.399.268-.926-.028-.926-.519V5.12c0-.491.527-.787.926-.52l4.299 2.881Z"></path></svg></i>' . $reply_to_name;
if($_user && isset($_user->ID) && $_user->ID){
    $author = apply_filters( 'get_comment_author', $_user->display_name ? $_user->display_name : $_user->user_nicename, $comment->comment_ID, $comment );
    $author_name = '<span class="as-comment-author">' . $_avatar . $author . '</span>';
    if(class_exists('WPCOM_Member') && apply_filters( 'wpcom_member_show_profile' , true )){
        $url = get_author_posts_url( $_user->ID );
        $author_name = '<a class="as-comment-url j-user-card" data-user="'.$_user->ID.'" href="'.$url.'" target="_blank">' .$author_name.'</a>';
    }
}else{
    $author_name = '<span class="as-comment-author">' . $_avatar . $comment->comment_author . '</span>';
}
?>
<li class="as-comments-item" data-id="<?php echo esc_attr($comment->comment_ID);?>">
    <div class="as-comment-name"><?php echo $author_name . $reply_to_name;?>
    </div>
    <div class="as-comment-content">
        <?php echo wpautop($comment->comment_content);?>
    </div>
    <div class="as-comment-meta">
        <span class="as-comment-meta-item"><?php echo QAPress_format_date(get_comment_date( 'U', $comment->comment_ID ));?></span>
        <?php if(isset($comment->depth) && $max_depth >= $comment->depth){ ?><span class="as-comment-meta-item reply"><a class="j-reply-comment" href="javascript:;"><i class="wpcom-icon wi"><svg aria-hidden="true"><use xlink:href="#wi-reply"></use></svg></i><?php _ex('Reply', 'qapress comment', 'wpcom');?></a></span><?php } ?>
        <?php if($del) { ?><span class="as-comment-meta-item delete"><a class="j-del-comment" href="javascript:;"><i class="wpcom-icon wi"><svg aria-hidden="true"><use xlink:href="#wi-delete"></use></svg></i><?php _ex('Delete', 'qapress', 'wpcom');?></a></span><?php } ?>
    </div>
</li>