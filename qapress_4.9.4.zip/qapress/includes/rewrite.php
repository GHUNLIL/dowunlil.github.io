<?php
add_filter( 'rewrite_rules_array', 'QAPress_rewrite' );
function QAPress_rewrite( $rules ){
    global $qa_slug, $qa_options, $permalink_structure;
    if(!isset($qa_options)) $qa_options = get_option('qa_options');

    $qa_page_id = isset($qa_options['list_page']) ? $qa_options['list_page'] : '';

    if($qa_slug==''){
        $qa_page = get_post($qa_page_id);
        $qa_slug = isset($qa_page->ID) ? $qa_page->post_name : '';
    }

    $newrules = array();
    if($qa_slug){
        if(!isset($permalink_structure)) $permalink_structure = get_option('permalink_structure');
        $pre = preg_match( '/^\/index\.php\//i', $permalink_structure) ? 'index.php/' : '';
        $slug = untrailingslashit($qa_slug) . '/';
        $newrules[$pre . $slug . '(\d+)\.html$'] = 'index.php?post_type=qa_post&p=$matches[1]';
        $newrules[$pre . $slug . '(\d+)?$'] = 'index.php?page_id=' . $qa_page_id . '&qa_page=$matches[1]';
        $newrules[$pre . $slug . '([^/]+)?$'] = 'index.php?page_id=' . $qa_page_id . '&qa_cat=$matches[1]';
        $newrules[$pre . $slug . '([^/]+)/(\d+)?$'] = 'index.php?page_id=' . $qa_page_id . '&qa_cat=$matches[1]&qa_page=$matches[2]';
    }

    return array_merge($newrules, $rules);
}

add_filter('redirect_canonical', 'QAPress_redirect_canonical', 10, 2);
function QAPress_redirect_canonical($redirect, $url){
    global $qa_options;
    if(!isset($qa_options)) $qa_options = get_option('qa_options');
    $qa_page_id = $qa_options['list_page'];

    if ( is_page() && $front_page = get_option( 'page_on_front' ) ) {
        $qa_page = get_post($qa_page_id);
        $qa_slug = isset($qa_page->ID) ? $qa_page->post_name : '';
        if($qa_page_id === $front_page && is_page( $front_page ) && untrailingslashit($url)!==untrailingslashit(get_permalink($qa_page_id)).'/'.$qa_slug) {
            $redirect = false;
        }
    }

    return $redirect;
}

add_action( 'init', 'QAPress_single_rewrite' );
function QAPress_single_rewrite() {
    global $wp_rewrite, $permalink_structure, $qa_slug, $qa_options;
    if(!isset($qa_options)) $qa_options = get_option('qa_options');
    if(!isset($permalink_structure)) $permalink_structure = get_option('permalink_structure');

    if($permalink_structure){
        if(!isset($qa_slug) || !$qa_slug ){
            $qa_page_id = isset($qa_options['list_page']) ? $qa_options['list_page'] : '';
            $qa_page = get_post($qa_page_id);
            $qa_slug = isset($qa_page->ID) ? $qa_page->post_name : '';
        }
        if($qa_slug){
            $queryarg = 'post_type=qa_post&p=';
            $wp_rewrite->add_rewrite_tag( '%qa_post_id%', '([^/]+)', $queryarg );
            $wp_rewrite->add_permastruct( 'QAPress', $qa_slug.'/%qa_post_id%.html', false );
        }
    }
}

add_filter('post_type_link', 'QAPress_single_permalink', 5, 2);
function QAPress_single_permalink( $post_link, $id ) {
    global $wp_rewrite, $permalink_structure;
    if(!isset($permalink_structure)) $permalink_structure = get_option('permalink_structure');
    if($permalink_structure) {
        $post = get_post($id);
        if (!is_wp_error($post) && $post->post_type == 'qa_post') {
            $newlink = $wp_rewrite->get_extra_permastruct('QAPress');
            $newlink = str_replace('%qa_post_id%', $post->ID, $newlink);
            $newlink = home_url(untrailingslashit($newlink));
            return $newlink;
        }
    }
    return $post_link;
}

add_filter('template_include', 'QAPress_template_include');
function QAPress_template_include($template){
    global $qa_options, $wp_query, $post;
    if(is_singular('qa_post') || (is_search() && $wp_query->get('post_type') === 'qa_post')){
        if(!isset($qa_options)) $qa_options = get_option('qa_options');
        $qa_page_id = isset($qa_options['list_page']) ? $qa_options['list_page'] : '';
        $tpl_sulg = get_page_template_slug( $qa_page_id );
        $_template = get_query_template( 'page', array($tpl_sulg) );
        if($_template=='') $_template = get_query_template( 'page', array('page.php') );
        $template = $_template == '' ? $template : $_template;
        if(is_search() && $qa_page_id) $post = get_post($qa_page_id);
    }
    return $template;
}

add_filter( 'posts_pre_query', function( $posts, \WP_Query $query ){
    if($query->is_search() && $query->is_main_query() && $query->get('post_type') === 'qa_post' && !is_admin()) {
        global $qa_options;
        $posts = [];
        $query->found_posts = 0;
        $qa_page_id = isset($qa_options['list_page']) ? $qa_options['list_page'] : '';
        $post = get_post($qa_page_id);
        if($post) $posts = [$post];
    }
    return $posts;
}, 100, 2 );

// 问答搜索页面边栏遵循问答页面
add_filter('wpcom_get_sidebar', function($sidebar){
    global $wp_query, $qa_options, $options;
    if(is_search() && $wp_query->get('post_type') === 'qa_post'){
        global $wp_query;
        $qa_page_id = isset($qa_options['list_page']) ? $qa_options['list_page'] : '';
        if($qa_page_id){
            $sidebar = get_post_meta($qa_page_id, 'wpcom_sidebar', true);
            if($sidebar === '' && isset($options['page_sidebar']) && $options['page_sidebar'] !== ''){
                $sidebar = $options['page_sidebar'];
            }
        }
    }
    return $sidebar;
});

add_filter('the_content', 'QAPress_single_content', 1);
function QAPress_single_content($content){
    global $wp_query;
    if( isset($wp_query->query['post_type']) && $wp_query->query['post_type'] == 'qa_post' ){
        $content = '[QAPress]';
    }
    return $content;
}

add_filter('query_vars', 'QAPress_query_vars', 10, 1 );
function QAPress_query_vars($public_query_vars) {
    $public_query_vars[] = 'qa_page';
    $public_query_vars[] = 'qa_cat';

    return $public_query_vars;
}

add_filter('user_trailingslashit', 'QAPress_untrailingslashit', 10, 2);
function QAPress_untrailingslashit($string, $url){
    if(preg_match('/\.html\/$/i', $string)){
        return untrailingslashit($string);
    }
    return $string;
}

function QAPress_category_url($cat, $page=1){
    global $permalink_structure, $wp_rewrite, $qa_options, $wp_query;
    if(is_search() && $wp_query->get('post_type') === 'qa_post'){
        $url = $page == 1 ? remove_query_arg('paged') : add_query_arg('paged', $page);
        return $url;
    }

    if(!isset($qa_options)) $qa_options = get_option('qa_options');
    if(!isset($permalink_structure)) $permalink_structure = get_option('permalink_structure');

    $qa_page_id = $qa_options['list_page'];

    if($permalink_structure){
        $qa_page = get_post($qa_page_id);
        $qa_slug = isset($qa_page->ID) ? $qa_page->post_name : '';
        $pre = preg_match('/^\/index\.php\//i', $permalink_structure) ? 'index.php/' : '';
        $qa_slug = $pre . $qa_slug;

        if($cat){
            $page_url = get_home_url(null, $qa_slug);
            $url = trailingslashit($page_url).$cat;
            if($page>1){
                $url = trailingslashit($url).$page;
            }
        }else{
            $url = get_permalink($qa_page_id);
            if($page>1){
                $page_url = get_home_url(null, $qa_slug);
                $url = trailingslashit($page_url).$page;
            }
        }
    }else{
        $page_url = get_permalink($qa_page_id);
        $url =  $cat ? add_query_arg('qa_cat', $cat, $page_url) : $page_url;
        if($page>1){
            $url = add_query_arg('qa_page', $page, $url);
        }
    }

    if ( $wp_rewrite->use_trailing_slashes )
        $url = trailingslashit($url);
    else
        $url = untrailingslashit($url);

    return $url;
}

function QAPress_edit_url( $qid ){
    global $qa_options;
    if(!isset($qa_options)) $qa_options = get_option('qa_options');
    $new_page_id = $qa_options['new_page'];

    $edit_url = get_permalink($new_page_id);

    $edit_url =  add_query_arg('type', 'edit', $edit_url);
    $edit_url =  add_query_arg('id', $qid, $edit_url);

    return $edit_url;
}

add_action( 'template_redirect', 'QAPress_404_page', 1 );
function QAPress_404_page() {
    global $wp_query, $wpcomqadb, $qa_options, $current_cat, $wpdb, $post;
    if(!isset($qa_options)) $qa_options = get_option('qa_options');

    if( isset($wp_query->query['post_type']) && $wp_query->query['post_type'] == 'qa_post' ){
        $qa_single = $post;
        $qtable = $wpdb->prefix.'wpcom_questions';
        if( ! ( $qa_single && isset($qa_single->ID) ) && $wpdb->get_var("SHOW TABLES LIKE '$qtable'") == $qtable ){
            $id = isset($wp_query->query['p']) ? $wp_query->query['p'] : '';
            if($id){
                $post = $wpdb->get_row("SELECT * FROM `$qtable` WHERE ID = '$id'");
                if($post && $post->flag<0){
                    $new_id = -($post->flag);
                    if($new_id && $link = get_permalink($new_id) ) {
                        wp_redirect( $link, 301 );
                        exit;
                    }
                }
            }

            $wp_query->set_404();
            status_header(404);
            get_template_part( 404 );
            exit();
        }
    }else if(isset($wp_query->query['qa_cat']) && $wp_query->query['qa_cat']){
        if(!$current_cat) $current_cat = get_term_by('slug', $wp_query->query['qa_cat'], 'qa_cat');
        if(!$current_cat){
            $wp_query->set_404();
            status_header(404);
            get_template_part( 404 );
            exit();
        }
    }

    if((isset($wp_query->query['qa_page']) && $wp_query->query['qa_page']) || (isset($wp_query->query['post_type']) && $wp_query->query['post_type'] == 'qa_post' && is_search() && isset($wp_query->query['paged']) && $wp_query->query['paged'])){
        $paged = isset($wp_query->query['qa_page']) && $wp_query->query['qa_page'] ? $wp_query->query['qa_page'] : $wp_query->query['paged'];
        $search = isset($_GET['search']) && $_GET['search'] !== '' ? sanitize_text_field($_GET['search']) : '';
        $search = isset($_GET['s']) && $_GET['s'] !== '' ? sanitize_text_field($_GET['s']) : $search;
        $total_q = $wpcomqadb->get_questions_total( isset($current_cat) ? $current_cat->term_id : 0, $search );
        $per_page = isset($qa_options['question_per_page']) && $qa_options['question_per_page'] ? $qa_options['question_per_page'] : 20;
        $numpages = ceil($total_q/$per_page);
        if($paged > $numpages){
            $wp_query->set_404();
            status_header(404);
            get_template_part( 404 );
            exit();
        }
    }
}