<?php

class WPCOM_QA_Widget_New extends WPCOM_Widget {
    public function __construct() {
        $this->widget_cssclass = 'widget_qapress_new';
        $this->widget_description = '问答插件发布新帖按钮';
        $this->widget_id = 'qapress-new';
        $this->widget_name = '#QAPress#发布新帖';
        $this->settings = array(
            'text' => array(
                'name' => '按钮名',
                's' => '发布新帖',
                'd' => '支持html代码'
            ),
            'show' => array(
                'name' => '按钮显示',
                't' => 'r',
                'ux' => 1,
                's' => '0',
                'd' => '会员介绍说明',
                'o' => array(
                    '0' => '仅问答页面',
                    '1' => '全部显示'
                )
            )
        );
        parent::__construct();
    }

    public function widget( $args, $instance ) {
        global $qa_options, $wp_query;
        if(!isset($qa_options)) $qa_options = get_option('qa_options');

        $text = empty( $instance['text'] ) ? '发布新帖' : $instance['text'];
        $show = isset($instance['show']) && $instance['show']=='1' ? '1' :  '0';

        if($show=='0'){
            $qa_page_id = $qa_options['list_page'];
            if(! (is_page($qa_page_id) || (isset($wp_query->query['post_type']) && $wp_query->query['post_type'] == 'qa_post')) ) return false;
        }

        $new_page_id = $qa_options['new_page'];
        $new_url = get_permalink($new_page_id);

        echo $args['before_widget'];
        echo '<a class="q-btn-new" href="'.$new_url.'">'.$text.'</a>';
        echo $args['after_widget'];
    }
}


class WPCOM_QA_Widget_List extends WPCOM_Widget {
    public function __construct() {
        $this->widget_cssclass = 'widget_qapress_list';
        $this->widget_description = '问答插件问题列表';
        $this->widget_id = 'qapress-list';
        $this->widget_name = '#QAPress#问题列表';
        $this->settings = array(
            'title' => array(
                'name' => '标题'
            ),
            'number' => array(
                'name' => '显示数量',
                's' => '10'
            ),
            'category' => array(
                'name' => '问答分类',
                's' => '10',
                't' => 'cs',
                'd' => '可选，不设置分类默认获取所有分类内容',
                'tax' => 'qa_cat'
            ),
            'orderby' => array(
                'name' => '排序',
                't' => 's',
                's' => '0',
                'd' => '如果网站文章较多（例如10w+）不推荐选择随机排序，会有性能问题',
                'o' => array(
                    '0' => '发布时间',
                    '1' => '回答数量',
                    '2' => '浏览数',
                    '3' => '随机排序'
                )
            )
        );
        parent::__construct();
    }

    public function widget( $args, $instance ) {
        $title = $instance['title'];
        $orderby_id = empty( $instance['orderby'] ) ? 0 :  $instance['orderby'];
        $number = empty( $instance['number'] ) ? 10 : absint( $instance['number'] );
        $category = empty( $instance['category'] ) ? '' : absint( $instance['category'] );

        $orderby = 'date';
        if($orderby_id==1){
            $orderby = 'comment_count';
        }else if($orderby_id==2){
            $orderby = 'meta_value_num';
        }else if($orderby_id==3){
            $orderby = 'rand';
        }

        $parg = array(
            'showposts' => $number,
            'orderby' => $orderby,
            'post_type' => 'qa_post',
            'ignore_sticky_posts' => true,
            'no_found_rows' => true
        );
        if($orderby=='meta_value_num') $parg['meta_key'] = 'views';
        if($category){
            $parg['tax_query'] = array(
                array(
                    'taxonomy' => 'qa_cat',
                    'terms'    => $category,
                )
            );
        }

        $posts = new WP_Query( $parg );

        echo $args['before_widget'];

        if ( $title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base ) ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }

        if ( $posts->have_posts() ) : ?>
            <ul>
                <?php while ( $posts->have_posts() ) : $posts->the_post(); ?>
                <li>
                    <a target="_blank" href="<?php the_permalink();?>" title="<?php echo esc_attr(get_the_title());?>">
                        <?php the_title(); ?>
                    </a>
                </li>
                <?php endwhile; wp_reset_postdata();?>
            </ul>
        <?php
        else:
            echo '<p style="color:#999;font-size: 12px;text-align: center;padding: 10px 0;margin:0;">暂无内容</p>';
        endif;

        echo $args['after_widget'];
    }
}



class WPCOM_QA_Widget_Related extends WPCOM_Widget {

    public function __construct() {
        $this->widget_cssclass = 'widget_qapress_related';
        $this->widget_description = '问答插件相关问题，仅在问题详情页的边栏显示';
        $this->widget_id = 'qapress-related';
        $this->widget_name = '#QAPress#相关问题';
        $this->settings = array(
            'title' => array(
                'name' => '标题'
            ),
            'number' => array(
                'name' => '显示数量',
                's' => '10'
            )
        );
        parent::__construct();
    }

    public function widget( $args, $instance ) {
        global $qa_options, $wp_query;
        if(isset($wp_query->query) && isset($wp_query->query['post_type']) && $wp_query->query['post_type']==='qa_post'){
            $title = $instance['title'];
            $number = empty( $instance['number'] ) ? 10 : absint( $instance['number'] );
            $postid = isset($wp_query->query['qa_id']) && $wp_query->query['qa_id'] ? $wp_query->query['qa_id'] : $wp_query->query['p'];
            $related = QAPress_related($postid, $number);

            if($related){
                echo $args['before_widget'];

                if ( $title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base ) ) {
                    echo $args['before_title'] . $title . $args['after_title'];
                }
                ?>
                <ul class="q-related">
                    <?php foreach ($related as $rp) { ?>
                        <li class="q-related-item">
                            <a class="q-related-title" href="<?php echo get_permalink($rp->ID);?>" target="_blank">
                                <?php echo get_the_title($rp->ID);?>
                            </a>
                            <div class="q-related-meta">
                                <span class="q-related-date"><?php echo get_the_date(get_option('date_format'), $rp->ID);?></span>
                                <div class="q-related-right">
                                    <span class="q-related-comments">
                                        <i class="wpcom-icon wi"><svg aria-hidden="true"><use xlink:href="#wi-comment"></use></svg></i><?php echo $rp->comment_count;?>
                                    </span>
                                    <?php if((isset($qa_options['show_views']) && $qa_options['show_views']) || !isset($qa_options['show_views'])){ ?>
                                    <span class="q-related-views">
                                        <i class="wpcom-icon wi"><svg aria-hidden="true"><use xlink:href="#wi-eye"></use></svg></i><?php $views = get_post_meta($rp->ID, 'views', true); echo $views ?: 0;?>
                                    </span>
                                    <?php } ?>
                                </div>
                            </div>
                        </li>
                    <?php } ?>
                </ul>
                <?php echo $args['after_widget'];
            }
        }
    }
}


class WPCOM_QA_Widget_Search extends WPCOM_Widget {
    public function __construct() {
        $this->widget_cssclass = 'widget_qapress_search';
        $this->widget_description = '问答搜索框';
        $this->widget_id = 'qapress-search';
        $this->widget_name = '#QAPress#搜索';
        $this->settings = array(
            'placeholder' => array(
                'name' => '提示文字',
                'd' => '例如：输入关键词搜索...'
            )
        );
        parent::__construct();
    }

    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        $placeholder = isset($instance['placeholder']) && $instance['placeholder'] ? $instance['placeholder'] :  '输入关键词搜索...';
        $search_query = isset($_GET['s']) && $_GET['s'] !== '' && isset($_GET['post_type']) && $_GET['post_type'] === 'qa_post' ? sanitize_text_field($_GET['s']) : '';
        ?>
        <form class="search-form" action="<?php echo get_bloginfo('url');?>" method="get" role="search">
            <input type="hidden" name="post_type" value="qa_post">
            <input type="text" class="keyword" name="s" placeholder="<?php echo esc_attr($placeholder);?>" value="<?php echo esc_attr($search_query); ?>">
            <button type="submit" class="submit"><i class="wpcom-icon wi"><svg aria-hidden="true"><use xlink:href="#wi-search"></use></svg></i></button>
        </form>
    <?php echo $args['after_widget'];
    }
}


// register widget
add_action( 'widgets_init', function(){
    register_widget( 'WPCOM_QA_Widget_New' );
    register_widget( 'WPCOM_QA_Widget_List' );
    register_widget( 'WPCOM_QA_Widget_Related' );
    register_widget( 'WPCOM_QA_Widget_Search' );
});