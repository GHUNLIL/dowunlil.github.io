<?php

class QAPress_AJAX {
    protected $qadb;
    function __construct(){
        global $wpcomqadb;
        $this->qadb = $wpcomqadb;
        if (wp_doing_ajax()){ //只接受ajax请求
            add_action('wp_ajax_QAPress_views', array($this, 'add_views'));
            add_action('wp_ajax_nopriv_QAPress_views', array($this, 'add_views'));

            add_action('wp_ajax_QAPress_answers_pagination', array($this, 'answers_pagination'));
            add_action('wp_ajax_nopriv_QAPress_answers_pagination', array($this, 'answers_pagination'));

            add_action('wp_ajax_QAPress_comments', array($this, 'get_comments'));
            add_action('wp_ajax_nopriv_QAPress_comments', array($this, 'get_comments'));

            add_action('wp_ajax_QAPress_add_comment', array($this, 'add_comment'));
            add_action('wp_ajax_nopriv_QAPress_add_comment', array($this, 'add_comment'));

            add_action('wp_ajax_QAPress_add_answer', array($this, 'add_answer'));
            add_action('wp_ajax_nopriv_QAPress_add_answer', array($this, 'add_answer'));

            add_action('wp_ajax_QAPress_add_question', array($this, 'add_question'));
            // add_action('wp_ajax_nopriv_QAPress_add_question', array($this, 'add_question'));

            add_action('wp_ajax_QAPress_img_upload', array($this, 'img_upload'));
            // add_action('wp_ajax_nopriv_QAPress_img_upload', array($this, 'img_upload'));

            add_action('wp_ajax_QAPress_delete_question', array($this, 'delete_question'));
            // add_action('wp_ajax_nopriv_QAPress_delete_question', array($this, 'delete_question'));

            add_action('wp_ajax_QAPress_approve_question', array($this, 'approve_question'));

            add_action('wp_ajax_QAPress_set_top', array($this, 'set_top'));
            // add_action('wp_ajax_nopriv_QAPress_set_top', array($this, 'set_top'));

            add_action('wp_ajax_QAPress_delete_answer', array($this, 'delete_answer'));
            // add_action('wp_ajax_nopriv_QAPress_delete_answer', array($this, 'delete_answer'));

            add_action('wp_ajax_QAPress_delete_comment', array($this, 'delete_comment'));
            // add_action('wp_ajax_nopriv_QAPress_delete_comment', array($this, 'delete_comment'));

            add_action('wp_ajax_QAPress_adopt_answer', array($this, 'adopt_answer'));

            add_action('wp_ajax_QAPress_vote', array($this, 'vote'));
            add_action('wp_ajax_nopriv_QAPress_vote', array($this, 'vote'));
        }
    }

    function add_views(){
        $data = map_deep($_POST, 'sanitize_text_field');
        if(isset($data['id']) && $data['id'] && is_numeric($data['id'])){
            echo $this->qadb->add_views($data['id']);
        }
        exit;
    }

    function answers_pagination(){
        global $wpcomqadb, $qa_options;
        $data = map_deep($_POST, 'sanitize_text_field');
        $res = array();
        $res['result'] = 1;
        if(isset($data['page']) && isset($data['question']) && is_numeric($data['page']) && is_numeric($data['question'])){
            if(!isset($qa_options)) $qa_options = get_option('qa_options');

            $answers_order = isset($qa_options['answers_order']) && $qa_options['answers_order']=='1' ? 'DESC' : 'ASC';
            $answers_per_page = isset($qa_options['answers_per_page']) && $qa_options['answers_per_page'] ? $qa_options['answers_per_page'] : 20;
            $answers = $wpcomqadb->get_answers($data['question'], $answers_per_page, $data['page'], $answers_order);
            $res['result'] = 0;
            $res['answers'] = array();
            global $comment;
            $adopted_answer = $qa_options && isset($qa_options['enable_best']) && $qa_options['enable_best'] ? (int)get_post_meta($data['question'], 'adopted_answer', true) : 0;
            foreach ($answers as $comment) {
                $res['answers'][] = QAPress_template('comment', array('comment' => $comment, 'adopted_answer' => $adopted_answer));
            }
        }
        wp_send_json($res);
    }

    function get_comments(){
        $data = map_deep($_POST, 'sanitize_text_field');
        $res = array();
        if(isset($data['aid']) && $data['aid'] && is_numeric($data['aid'])){
            $comments = $this->qadb->get_comments($data['aid']);
            if($comments){
                usort($comments, 'QAPress_reply_sort');
                $res_comments = '';
                foreach ($comments as $comment) {
                    $res_comments .= QAPress_template('comment-reply', ['comment' => $comment, 'parent' => $data['aid']]);
                }
                $res['comments'] = $res_comments;
                $res['delete'] = current_user_can( 'manage_options' ) ? 1 : 0;
            }
            $res['result'] = 0;
        }else{
            $res['result'] = 1;
        }
        wp_send_json($res);
    }


    function add_comment(){
        global $QAPress;
        $data = $_POST;
        $res = array();
        $user =  wp_get_current_user();
        if($data['id'] && $user->ID && $QAPress->is_active()){
            $parent = get_comment($data['id']);
            $comment = array();
            $comment['comment_parent'] = sanitize_text_field($data['id']);
            $comment['comment_content'] = sanitize_textarea_field($data['comment']);
            $comment['user_id'] = $user->ID;
            $comment['comment_author_email'] = $user->user_email;
            $comment['comment_author'] = $user->display_name;
            $comment['comment_approved'] = 1;
            $comment['comment_post_ID'] = $parent->comment_post_ID;
            $comment['comment_type'] = 'qa_comment';

            if(trim(strip_tags($comment['comment_content'])) == ''){
                $res['result'] = 101;
            }else{
                $id = $this->qadb->insert_comment($comment);
                if(is_wp_error($id)){
                    $res['result'] = 1;
                    $res['msg'] = $id->get_error_message();
                }else if($id){
                    $res['result'] = 0;
                }else{
                    $res['result'] = 1;
                }
            }
        }else{
            $res['result'] = 2;
        }

        wp_send_json($res);
    }


    function add_answer(){
        global $QAPress;
        $data = $_POST;
        $res = array();
        $user =  wp_get_current_user();
        if($data['id'] && $user->ID && $QAPress->is_active()){ // 已登录
            $answer = array();
            $answer['comment_post_ID'] = sanitize_text_field($data['id']);
            $question = '';
            if($data['id'] && is_numeric($data['id'])) $question = $this->qadb->get_question($data['id']);;

            if($question){ // 问题存在
                $qa_options = get_option('qa_options');
                $answer['comment_content'] = wp_kses_post($data['answer']);
                $answer['user_id'] = $user->ID;
                $answer['comment_author_email'] = $user->user_email;
                $answer['comment_author'] = $user->display_name;
                $answer['comment_approved'] = 1;
                $answer['comment_type'] = 'answer';

                if(trim($answer['comment_content']) == ''){
                    $res['result'] = 101;
                }else{
                    // 判断是否需要审核
                    if( !current_user_can( 'publish_posts' ) ){
                        $moderation = isset($qa_options['answer_moderation']) ? $qa_options['answer_moderation'] : 0;
                        if( $moderation == '1' ){ // 第一次审核
                            $q_total = $this->qadb->get_questions_total_by_user($user->ID);
                            $a_total = $this->qadb->get_answers_total_by_user($user->ID);
                            $answer['comment_approved'] = $q_total || $a_total ? 1 : 0;
                        }else if( $moderation == '2' ){ // 全部需要审核
                            $answer['comment_approved'] = 0;
                        }
                    }

                    $id = $this->qadb->insert_answer($answer);
                    if(is_wp_error($id)){
                        $res['result'] = 1;
                        $res['msg'] = $id->get_error_message();
                    }else if($id){
                        $answer['ID'] = $id;
                        $res['result'] = 0;
                        $res['answer'] = $answer;
                        $res['answer']['date'] = QAPress_format_date(strtotime(current_time('mysql')));
                        $res['answer']['content'] = wpautop($answer['comment_content']);
                        $res['user'] = array();
                        $user_name = $user->display_name ? $user->display_name : $user->user_nicename;
                        $res['user']['nickname'] = $user_name;
                        $res['user']['avatar'] = get_avatar($user->ID, 60);

                        //邮件、通知信息，发送问题作者和管理员
                        $subject = isset($qa_options['email_answer_title']) ? $qa_options['email_answer_title'] : '';
                        if(trim($subject)!=''){ // 根据标题判断是否发送邮件
                            $color = isset($qa_options['color']) && $qa_options['color'] ? $qa_options['color'] : '#1471CA';
                            $content = '<p>' . sprintf( __( 'Your question [%s] has a new reply:', 'wpcom' ), $question->post_title ) . '</p>';
                            $content .= '<div style="background: #f9f9f9;color:#666;padding: 10px 10px 10px 15px;border-left: 3px solid '.$color.';">'.$answer['comment_content'].'</div>';
                            $content .= '<p>' . __( 'For details, please visit:', 'wpcom' ) . '<a href="'.get_permalink($question->ID).'">'.get_permalink($question->ID).'</a></p>';

                            $quser = get_user_by('ID', $question->post_author);
                            if($quser->ID) QAPress_mail( $quser->data->user_email, $subject, $content );
                            // 抄送管理员
                            $cc = isset($qa_options['email_answer_cc']) ? $qa_options['email_answer_cc'] : 1;
                            if( $cc ) {
                                $admin_email = get_bloginfo ('admin_email');
                                if($quser->email != $admin_email) QAPress_mail( $admin_email, $subject, $content );
                            }
                        }
                    }else{
                        $res['result'] = 1;
                    }
                }
            }else{ // 问题不存在
                $res['result'] = 4;
            }
        }else{ // 未登录
            $res['result'] = 2;
        }

        wp_send_json($res);
    }

    function delete_answer(){
        global $QAPress;
        $res = array();
        if( current_user_can( 'manage_options' ) && $QAPress->is_active()){ // 管理员才能执行此操作
            if(isset($_POST['id']) && is_numeric($_POST['id'])){
                $id = sanitize_text_field($_POST['id']);
                // 删除回复的评论
                $this->qadb->delete_comments( $id );
                // 删除回复
                $this->qadb->delete_answer( $id );
                $res['result'] = 0;
            }else{
                $res['result'] = 1;
            }
        }else{
            $res['result'] = 2;
        }
        wp_send_json($res);
    }

    function adopt_answer(){
        $res = array();
        $post_id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : 0;
        $answer_id = isset($_POST['aid']) ? sanitize_text_field($_POST['aid']) : 0;
        if(QAPress_can_adopt_best($post_id)){
            $post = get_post($post_id);
            $comment = get_comment($answer_id);
            if($post && isset($post->ID) && $comment && isset($comment->comment_ID) && $comment->comment_post_ID == $post->ID){
                $adopted_answer = get_post_meta($post->ID, 'adopted_answer', true);
                if($adopted_answer){
                    delete_comment_meta($adopted_answer, 'adopted_answer');
                }
                $set = update_post_meta($post->ID, 'adopted_answer', $comment->comment_ID);
                if($set){
                    update_comment_meta($comment->comment_ID, 'adopted_answer', 1);
                    $res['result'] = 0;
                }else{
                    $res['result'] = 3;
                }
            }else{
                $res['result'] = 1;
            }
        }else{
            $res['result'] = 2;
        }
        wp_send_json($res);
    }

    function delete_comment(){
        global $QAPress;
        $res = array();
        if( current_user_can( 'manage_options' ) && $QAPress->is_active() ){ // 管理员才能执行此操作
            if(isset($_POST['id']) && is_numeric($_POST['id'])){
                $id = sanitize_text_field($_POST['id']);
                // 删除评论
                $this->qadb->delete_comment( $id );
                $res['result'] = 0;
            }else{
                $res['result'] = 1;
            }
        }else{
            $res['result'] = 2;
        }
        wp_send_json($res);
    }

    function add_question(){
        global $QAPress;
        $res = array();
        $nonce = isset($_POST['add_question_nonce']) ? sanitize_text_field($_POST['add_question_nonce']) : '';

        // Check nonce
        if ( ! $nonce || ! wp_verify_nonce( $nonce, 'QAPress_add_question' ) ){
            $res['result'] = 1;
            wp_send_json($res);
        }

        $user =  wp_get_current_user();
        if($user->ID && $QAPress->is_active()){
            $post = array();
            $qid = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : 0;
            $qa_options = get_option('qa_options');

            $question = $qid ? $this->qadb->get_question($qid) : null;

            if($question && ( $question->post_author==$user->ID || $user->has_cap( 'edit_others_posts' ) ) ) { // 问题存在，并比对用户权限
                $post['ID'] = $question->ID;
                $post['post_author'] = $question->post_author;
            }else{
                $post['post_author'] = $user->ID;
                $post['post_status'] = 'publish';
                $post['post_type'] = 'qa_post';
            }

            $post['post_title'] = strip_tags(sanitize_text_field($_POST['title']));
            $post['post_content'] = wp_kses_post($_POST['content']);

            if(trim($post['post_title']) == '' || trim($post['post_content']) == '' || trim($_POST['category']) == ''){
                $res['result'] = 101;
            }else if(mb_strlen(trim($post['post_content']))<10){ // 内容不能少于10个字符
                $res['result'] = 102;
            }else{
                $id = $this->qadb->insert_question($post);

                if(is_wp_error($id)){
                    $res['result'] = 1;
                    $res['msg'] = $id->get_error_message();
                }else if($id){
                    if(!$qid) update_post_meta($id, 'views', 1);
                    wp_set_object_terms( $id, array( (int)sanitize_text_field($_POST['category']) ), 'qa_cat' );
                    $res['location'] = get_permalink($id);
                    if(!$qid){ // 新帖，非修改
                        //邮件、通知信息，发送管理员
                        $subject = isset($qa_options['email_new_title']) ? $qa_options['email_new_title'] : '';
                        if( trim($subject)!='' ){
                            $color = isset($qa_options['color']) && $qa_options['color'] ? $qa_options['color'] : '#1471CA';
                            $content = '<p>' . __('Your site posted a new question:', 'wpcom') . '</p>';
                            $content .= '<div style="background: #f9f9f9;color:#666;padding: 10px 10px 10px 15px;border-left: 3px solid '.$color.';">'.$post['post_title'].'</div>';
                            $content .= '<p>' . __( 'For details, please visit:', 'wpcom' ) . '<a href="'.get_permalink($id).'">'.get_permalink($id).'</a></p>';
                            QAPress_mail( get_bloginfo ('admin_email'), $subject, $content );
                        }
                        $post = get_post($id);
                        if( $post->ID && $post->post_status=='pending' ){ //审核中
                            $list_page_id = $qa_options['list_page'];
                            $res['location'] = get_permalink($list_page_id); // 跳转回列表
                            $res['msg'] = __('Published successfully, please wait for the site administrator to review!', 'wpcom'); // 提示语
                        }
                    }
                    $res['result'] = 0;
                    $res['id'] = $id;
                }else{
                    $res['result'] = 1;
                }
            }
        }else{
            $res['result'] = 2;
        }

        wp_send_json($res);
    }

    function delete_question(){
        global $QAPress;
        $res = array();
        $current_user =  wp_get_current_user();
        $post_id = sanitize_text_field($_POST['id']);
        $question = get_post($post_id);
        if( (current_user_can( 'manage_options' ) || $current_user->ID == $question->post_author) && $QAPress->is_active() ){ // 管理员才能执行此操作
            if(isset($_POST['id']) && is_numeric($_POST['id'])){
                // 删除回复
                $this->qadb->delete_answers( $post_id );
                $this->qadb->delete_question( $post_id );
                $res['result'] = 0;
            }else{
                $res['result'] = 1;
            }
        }else{
            $res['result'] = 2;
        }
        wp_send_json($res);
    }

    function approve_question(){
        global $QAPress, $wpdb;
        $res = array();
        if( current_user_can( 'manage_options' ) && $QAPress->is_active() ){ // 管理员才能执行此操作
            if(isset($_POST['id']) && is_numeric($_POST['id']) && $post = get_post($_POST['id'])){
                $wpdb->update($wpdb->posts, array( 'post_status' => 'publish' ), array('ID' => $post->ID));
                wp_transition_post_status( 'publish', 'pending', $post );
                $res['result'] = 0;
            }else{
                $res['result'] = 1;
            }
        }else{
            $res['result'] = 2;
        }
        wp_send_json($res);
    }

    function set_top(){
        $res = array();
        if( current_user_can( 'manage_options' ) ){ // 管理员才能执行此操作
            if(isset($_POST['id']) && is_numeric($_POST['id'])){
                $id = sanitize_text_field($_POST['id']);
                $this->qadb->set_top($id);
                $res['result'] = 0;
            }else{
                $res['result'] = 1;
            }
        }else{
            $res['result'] = 2;
        }
        wp_send_json($res);
    }

    function vote(){
        $res = array(
            'result' => 0
        );

        // Check nonce
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if ( ! $nonce || ! wp_verify_nonce( $nonce, 'QAPress_comments_list' ) ){
            $res['result'] = 1;
            wp_send_json($res);
        }

        $current_user =  wp_get_current_user();
        if($current_user && $current_user->ID){
            $id = isset($_POST['id']) && $_POST['id'] ? sanitize_text_field($_POST['id']) : '';
            $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '';
            $vote_type = $type == '1' ? 'upvote' : 'downvote';
            $upvote_count = get_comment_meta( $id, 'upvote_count', true );
            $downvote_count = get_comment_meta( $id, 'downvote_count', true );
            $upvote_count = $upvote_count ?: 0;
            $downvote_count = $downvote_count ?: 0;

            if($id && $type !==''){
                $vote = $this->qadb->get_comment_vote($id, $current_user->ID);
                $res['voted'] = $vote_type;
                if($vote && $vote->meta_key === $vote_type){ // 取消赞同或者反对
                    delete_comment_meta( $id, $vote_type, $current_user->ID );
                    $count = $vote_type === 'upvote' ? $upvote_count : $downvote_count;
                    $count = $count - 1;
                    $count = $count < 0 ? 0 : $count;
                    update_comment_meta($id, $vote_type.'_count', $count);
                    if($vote_type === 'upvote'){
                        $upvote_count = $count;
                    }else{
                        $downvote_count = $count;
                    }
                    $res['voted'] = false;
                }else if($vote){ // 点击的是相反的按钮
                    $this->qadb->update_comment_vote($id, $current_user->ID, $vote_type);
                    if($vote_type === 'upvote'){
                        $upvote_count += 1;
                        $downvote_count -= 1;
                    }else{
                        $upvote_count -= 1;
                        $downvote_count += 1;
                    }
                    update_comment_meta($id, 'upvote_count', $upvote_count);
                    update_comment_meta($id, 'downvote_count', $downvote_count);
                }else{ // 新点击
                    $this->qadb->update_comment_vote($id, $current_user->ID, $vote_type);
                    $count = $vote_type === 'upvote' ? $upvote_count : $downvote_count;
                    $count = $count + 1;
                    $count = $count < 0 ? 0 : $count;
                    update_comment_meta($id, $vote_type.'_count', $count);
                    if($vote_type === 'upvote'){
                        $upvote_count = $count;
                    }else{
                        $downvote_count = $count;
                    }
                    update_comment_meta($id, $vote_type.'_count', $count);
                }
            }
            $res['upvote'] = $upvote_count;
            $res['downvote_count'] = $downvote_count;
        }else{
            $res['result'] = 2;
            $res['msg'] = __('You are not signed in, please sign in before proceeding with related operations!', 'wpcom');
        }
        wp_send_json($res);
    }

    function img_upload(){
        $res = array();

        $user =  wp_get_current_user();
        if($user->ID){
            $upfile = $_FILES['upfile'];
            $upload_overrides = array('test_form' => false);
            $file_return = wp_handle_upload($upfile, $upload_overrides);

            if ($file_return && !isset($file_return['error'])) {
                // 保存到媒体库
                $attachment = array(
                    'post_title' => preg_replace( '/\.[^.]+$/', '', basename( $file_return['file'] ) ),
                    'post_mime_type' => $file_return['type'],
                );
                $attach_id = wp_insert_attachment($attachment, $file_return['file']);
                $attach_data = self::generate_attachment_metadata($attach_id, $file_return['file']);
                wp_update_attachment_metadata($attach_id, $attach_data);
                $res['result'] = 0;
                $file_return['alt'] = preg_replace( '/\.[^.]+$/', '', basename( $file_return['file'] ) );
                $res['image'] = $file_return;
            } else {
                $res['result'] = 1;
            }
        } else {
            $res['result'] = 2;
        }
        wp_send_json($res);
    }

    function generate_attachment_metadata($attachment_id, $file) {
        $attachment = get_post ( $attachment_id );
        $metadata = array ();
        if (!function_exists('file_is_displayable_image')) include( ABSPATH . 'wp-admin/includes/image.php' );

        if (preg_match ( '!^image/!', get_post_mime_type ( $attachment ) ) && file_is_displayable_image ( $file )) {
            $imagesize = getimagesize ( $file );
            $metadata ['width'] = $imagesize [0];
            $metadata ['height'] = $imagesize [1];
            list ( $uwidth, $uheight ) = wp_constrain_dimensions ( $metadata ['width'], $metadata ['height'], 128, 96 );
            $metadata ['hwstring_small'] = "height='$uheight' width='$uwidth'";

            // Make the file path relative to the upload dir
            $metadata ['file'] = _wp_relative_upload_path ( $file );
            // work with some watermark plugin
            $metadata = apply_filters ( 'wp_generate_attachment_metadata', $metadata, $attachment_id, 'create' );
        }
        return $metadata;
    }
}

new QAPress_AJAX();