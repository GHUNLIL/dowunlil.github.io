<?php defined('ABSPATH') || exit;
/**
 * Plugin Name: WPCOM用户中心高级版
 * Plugin URI: https://www.wpcom.cn
 * Description: WPCOM主题用户中心高级版，可支持会员订阅、付费阅读、付费下载等高级增强功能
 * Version: 1.11.1
 * Author: WPCOM
 * Author URI: https://www.wpcom.cn
 * Requires PHP: 7.0
 * Requires at least: 6.1
 * Requires Plugins: wpcom-member
 */

define('WPCOM_MP_VERSION', '1.11.1');
define('WPCOM_MP_DIR', plugin_dir_path(__FILE__));
define('WPCOM_MP_URI', plugins_url('/', __FILE__));

$themer_path = is_dir($framework_path = WPCOM_MP_DIR . '/admin/') ? $framework_path : plugin_dir_path( __DIR__ ) . '/Themer/admin/' ;
require $themer_path . 'load.php';

add_action('plugins_loaded', function(){
    do_action('wpcom_setup_plugin_themer');
    if(defined('WPMX_VERSION')){
        $wpcom_mp_info = array(
            'slug' => 'wpcom-member-pro',
            'name' => '用户中心',
            'ver' => WPCOM_MP_VERSION,
            'title' => '用户中心',
            'icon' => 'dashicons-wpcom-logo',
            'position' => 72,
            'key' => 'wpmx_options',
            'plugin_id' => 'a23e6c668dc508a3',
            'basename' => plugin_basename(__FILE__)
        );
        $GLOBALS['wpcom_mp'] = new WPCOM_PLUGIN_PANEL($wpcom_mp_info);
    }
}, 5);

include WPCOM_MP_DIR . 'includes/functions.php';