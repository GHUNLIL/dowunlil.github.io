<?php
defined('ABSPATH') || exit;

if (!class_exists('WP_List_Table')) require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';

class WPCOM_Orders_List extends WP_List_Table {
    protected $table;
    protected $item_table;
    private $total_items = array();
    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'wpcom_orders';
        $this->item_table = $wpdb->prefix . 'wpcom_order_items';

        wp_enqueue_script( 'jquery-ui-dialog' );
        wp_enqueue_style( 'wp-jquery-ui-dialog' );

        parent::__construct([
            'screen' => 'wpcom_orders'
        ]);
    }

    public function ajax_user_can() {
        return current_user_can('manage_options');
    }

    public function get_views(){
        $status = isset($_GET['status']) && $_GET['status'] ? sanitize_text_field($_GET['status']) : 'all';
        $views = array(
            'all' => array(
                'url' => esc_url( add_query_arg( array('page' => 'wpcom-orders'), 'admin.php' ) ),
                'label' => '全部 <span class="count">（'.$this->total_items['all'].'）</span>',
                'current' => $status === 'all'
            ),
            'paid' => array(
                'url' => esc_url( add_query_arg( array('page' => 'wpcom-orders', 'status' => 'paid'), 'admin.php' ) ),
                'label' => '已付款 <span class="count">（'.$this->total_items['paid'].'）</span>',
                'current' => $status === 'paid'
            ),
            'unpaid' => array(
                'url' => esc_url( add_query_arg( array('page' => 'wpcom-orders', 'status' => 'unpaid'), 'admin.php' ) ),
                'label' => '未付款 <span class="count">（'.$this->total_items['unpaid'].'）</span>',
                'current' => $status === 'unpaid'
            ),
            'cancel' => array(
                'url' => esc_url( add_query_arg( array('page' => 'wpcom-orders', 'status' => 'cancel'), 'admin.php' ) ),
                'label' => '已取消 <span class="count">（'.$this->total_items['cancel'].'）</span>',
                'current' => $status === 'cancel'
            )
        );
        return $this->get_views_links($views);
    }

    public function prepare_items() {
        global $wpdb, $orderby, $order;
        wp_reset_vars(array('orderby', 'order'));

        $this->process_bulk_action();

        $per_page = 20;
        $orderby = $orderby ?: 'ID';
        $order = $order ?: 'DESC';

        $paged = $this->get_pagenum();
        $offset = ($paged - 1) * $per_page;

        $search = isset($_REQUEST['s']) ? wp_unslash(trim($_REQUEST['s'])) : '';
        $status = isset($_GET['status']) && $_GET['status'] ? sanitize_text_field($_GET['status']) : 'all';
        $where_sql = '';
        if($status !== 'all') $where_sql = "WHERE `status` = '$status'";
        $where_sql .= $search ? ($where_sql ? ' AND' : ' WHERE') . " (number LIKE '%$search%' OR user = '$search' OR ID = '$search')" : '';
        $order_type = isset($_GET['order_type']) && $_GET['order_type'] ? sanitize_text_field($_GET['order_type']) : '';
        if($order_type){
            $where_sql .= $order_type ? ($where_sql ? ' AND' : ' WHERE') . " I.type='$order_type'" : '';
            $results = $wpdb->get_results("SELECT O.* FROM $this->table O LEFT JOIN $this->item_table I ON O.ID=I.order_id $where_sql ORDER BY $orderby $order limit $offset, $per_page");
        }else{
            $results = $wpdb->get_results("SELECT * FROM $this->table $where_sql ORDER BY $orderby $order limit $offset, $per_page");
        }
        $this->total_items['all'] = $wpdb->get_var("SELECT count(*) FROM $this->table");
        $this->total_items['paid'] = $wpdb->get_var("SELECT count(*) FROM $this->table WHERE `status` = 'paid'");
        $this->total_items['unpaid'] = $wpdb->get_var("SELECT count(*) FROM $this->table WHERE `status` = 'unpaid'");
        $this->total_items['cancel'] = $wpdb->get_var("SELECT count(*) FROM $this->table WHERE `status` = 'cancel'");
        $this->total_items['current'] = $wpdb->get_var("SELECT count(*) FROM $this->table $where_sql");

        $this->set_pagination_args([
            'total_items' => $this->total_items['current'],
            'per_page'    => $per_page
        ]);
        $this->items = $results;
    }

    function export(){ ?>
        <div id="orders-export-dialog">
            <form method="post" id="orders-export-form">
                <?php wp_nonce_field( 'wpcom_orders_export', 'wpcom_orders_export_nonce' ); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="status">订单状态</label></th>
                        <td>
                            <select name="status" id="orders-status" class="regular-text">
                                <option value="">全部</option>
                                <?php
                                $_status = array(
                                    'paid' => '已付款',
                                    'unpaid' => '未付款',
                                    'refund' => '已退款',
                                    'cancel' => '已取消'
                                );
                                foreach($_status as $k => $v){
                                    echo '<option value="'.$k.'">'.$v.'</option>';
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="time">订单时间</label></th>
                        <td>
                            <?php
                            $today = current_time('Y-m-d');?>
                            <label><input type="date" name="begin_time" value="" max="<?php echo $today;?>"></label>
                            <span style="margin: 0 10px;"> 至 </span>
                            <label><input type="date" name="end_time" value="<?php echo $today;?>" max="<?php echo $today;?>"></label>
                            <p class="description" style="margin-top: 10px;font-size: 13px;">不设置开启时间则默认为所有时间；如果网站订单较多建议时间跨度不要太大，避免造成服务器负载过大或者内存溢出的问题</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="ext">文件格式</label></th>
                        <td>
                            <label><input type="radio" name="ext" value="xlsx" checked>xlsx</label>
                            <label style="margin-left: 12px;"><input type="radio" name="ext" value="csv">csv</label>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <p class="submit"><input type="submit" name="submit" class="button button-primary" value="生成报表"></p>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
        <script>
            jQuery(function($){
                $('#orders-export-dialog').dialog({
                    title: '批量导出订单',
                    dialogClass: 'wp-dialog',
                    autoOpen: false,
                    width: '680',
                    modal: true,
                    focus: false,
                    position: {
                        my: "center",
                        at: "center",
                        of: window
                    }
                });
                $('a.j-orders-export').on('click', function(e){
                    e.preventDefault();
                    $('#orders-export-dialog').dialog('open');
                });
                $('form#orders-export-form').on('submit', function(){
                    let _data = $(this).serialize() + '&action=wpcom_orders_export';
                    $.ajax({
                        type: 'POST',
                        url: ajaxurl,
                        data: _data,
                        dataType: 'json',
                        success(data){
                            if(data && data.result == 0 ){
                                window.location.href = ajaxurl + '?' + _data;
                            }else if(data && data.msg){
                                alert(data.msg);
                            }
                        },
                        error(){
                            alert('导出出错，请稍后再试！');
                        }
                    })
                });
            });
        </script>
    <?php }

    function get_columns() {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'number' => '订单号',
            'items' => '购买项目',
            'user' => '用户',
            'time' => '时间',
            'status' => '状态',
            'price' => '合计',
            'payment_gateway' => '付款方式'

        );
        return $columns;
    }

    protected function extra_tablenav( $which ) {
		?>
		<div class="alignleft actions">
		<?php
		if ( 'top' === $which ) {
			ob_start();
			$this->order_type_dropdown();
			do_action( 'restrict_manage_wpcom_orders', $which );
			$output = ob_get_clean();
			if ( ! empty( $output ) ) {
				echo $output;
				submit_button( __( 'Filter' ), '', 'filter_action', false, array( 'id' => 'orders-query-submit' ) );
			}
		}
		?>
		</div>
		<?php
		do_action( 'manage_wpcom_orders_extra_tablenav', $which );
	}

    protected function order_type_dropdown() {
		$displayed_order_type = isset( $_GET['order_type'] ) ? $_GET['order_type'] : '';
        $types = array(
            'premium-content' => '付费内容',
            'premium-download' => '付费下载',
            'copy-post' => '付费复制'
        );
        $types = apply_filters('wpcom_order_types', $types);
		?>
		<label for="filter-by-type" class="screen-reader-text">根据订单类型筛选</label>
		<select name="order_type" id="filter-by-type">
			<option<?php selected( $displayed_order_type, '' ); ?> value="">所有订单</option>
			<?php
			foreach ( $types as $slug => $title ) { ?>
                <option<?php selected( $displayed_order_type, $slug ); ?> value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $title ); ?></option>
			<?php } ?>
		</select>
		<?php
	}

    public function process_bulk_action() {
        if ('delete-order' === $this->current_action()) {
            $nonce = esc_attr($_REQUEST['_wpnonce']);
            if (wp_verify_nonce($nonce, 'bulk-wpcom_orders')) {
                $ids = isset($_REQUEST['check']) ? $_REQUEST['check'] : array();
                if (!empty($ids)) foreach($ids as $id) WPCOM_Order::delete_order($id);
            } else if (isset($_GET['id']) && $_GET['id']) {
                $nonce = esc_attr($_REQUEST['_wpnonce']);
                if (wp_verify_nonce($nonce, 'delete-order_' . $_GET['id'])) {
                    WPCOM_Order::delete_order($_GET['id']);
                }
            }
        }
    }

    protected function get_bulk_actions() {
        $actions = array();
        $actions['delete-order'] = __('Delete');
        return $actions;
    }
    protected function get_sortable_columns() {
        $status = isset($_GET['status']) && $_GET['status'] ? sanitize_text_field($_GET['status']) : 'all';
        if($status === 'all'){
            return array(
                'time' => 'time',
                'price' => 'price',
                'user' => 'user',
                'status' => 'status',
            );
        }else{
            return array(
                'time' => 'time',
                'price' => 'price',
                'user' => 'user'
            );
        }
    }
    protected function get_default_primary_column_name() {
        return 'number';
    }
    public function column_cb($order) { ?>
        <label class="screen-reader-text" for="cb-select-<?php echo $order->ID; ?>"> </label>
        <input type="checkbox" name="check[]" id="cb-select-<?php echo $order->ID; ?>" value="<?php echo esc_attr($order->ID); ?>" />
<?php
    }
    public function column_user($order) {
        if(!$order->user) {
            return  '-';
        }else{
            $user = get_user_by('ID', $order->user);
            if($user && $user->ID){
                printf(
                    '<strong><a class="row-title" href="%s" target="_blank">%s</a></strong>',
                    get_edit_user_link($user->ID),
                    $user->display_name
                );
            }else{
                return '无效用户';
            }
        }
    }
    public function column_number($order) {
        return sprintf(
            '<a href="%s">%s</a>',
            admin_url( "admin.php?page=wpcom-edit-order&id=$order->ID" ),
            $order->number
        );
    }
    public function column_items($order) {
        $items = WPCOM_Order::get_order_items($order->ID);?>
        <div class="orders-list">
            <?php if ($items) {
                foreach ($items as $item) {
                    $url = apply_filters('wpcom_order_item_url', '', $item); ?>
                    <div class="orders-list-item">
                        <?php if($url){ ?>
                            <a class="orders-list-item-title" href="<?php echo esc_url($url);?>" target="_blank"><?php echo $item->title; ?></a>
                        <?php }else{ ?>
                            <div class="orders-list-item-title"><?php echo $item->title; ?></div>
                        <?php } ?>
                        <div class="orders-list-item-price">￥<?php echo $item->price; ?></div>
                        <?php if(isset($item->data) && $item->data && $data = json_decode($item->data, true)){
                            if(isset($data['quantity']) && $data['quantity'] > 1){
                                echo '<div class="orders-list-item-qty"><span>×</span>' .$data['quantity'].'</div>';
                            }
                        }?>
                    </div>
            <?php }
            } ?>
        </div>
    <?php }
    public function column_price($order) {
        return '￥'.$order->price;
    }
    public function column_time($order) {
        return $order->time;
    }
    public function column_status($order) {
        $status = WPCOM_Order::get_order_status_display($order->status);
        return '<span class="' . $order->status . '">' . $status . '</span>';
    }

    public function column_payment_gateway($order) {
        if($order->payment_gateway){
            $gateways = apply_filters('wpcom_payment_gateways', array());
            if($gateways && isset($gateways[$order->payment_gateway])){
                return $gateways[$order->payment_gateway]->title;
            }else{
                return $order->payment_gateway;
            }
        }
    }

    protected function column_default( $item, $column_name ) {
        return apply_filters("manage_{$this->screen->id}_custom_column", '', $item, $column_name);
    }

    protected function handle_row_actions($order, $column_name, $primary) {
        if ($primary !== $column_name) return '';

        $actions           = array();
        $actions['edit'] = sprintf(
            '<a href="%s">%s</a>',
            admin_url( "admin.php?page=wpcom-edit-order&id=$order->ID" ),
            __('Edit')
        );
        $actions['delete'] = sprintf(
            '<a class="submitdelete" href="%s" onclick="return confirm( \'%s\' );">%s</a>',
            wp_nonce_url("?page=wpcom-orders&action=delete-order&id=$order->ID", 'delete-order_' . $order->ID),
            esc_js(sprintf('删除订单可能导致用户购买数据丢失，请谨慎操作，您确定需要删除吗？', $order->ID)),
            __('Delete')
        );

        return $this->row_actions($actions);
    }
}
