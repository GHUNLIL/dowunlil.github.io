<?php
defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'WP_List_Table' ) ) require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
if ( ! class_exists( 'WPCOM_Affiliate_List' ) ) :
    class WPCOM_Affiliate_List extends WP_List_Table {
        protected $table;
        public function __construct(){
            global $wpdb;
            $this->table = $wpdb->prefix . 'wpcom_aff_logs';

            parent::__construct([
                'screen' => 'affiliate'
            ]);
        }

        public function prepare_items() {
            global $wpdb, $orderby, $order;
            wp_reset_vars( array( 'orderby', 'order' ) );

            $this->process_bulk_action();

            $orderby = $orderby ?: 'ID';
            $order = $order ?: 'DESC';
            $per_page = 30;

            $paged = $this->get_pagenum();
            $results = WPCOM_Affiliate::get_aff_logs(['per_page' => $per_page, 'paged' => $paged, 'orderby' => $orderby, 'order' => $order]);
            $total = $wpdb->get_var( "SELECT COUNT(*) FROM $this->table" );

            $this->set_pagination_args( [
                'total_items' => $total,
                'per_page'    => $per_page
            ] );
            $this->items = $results;
        }

        function get_columns(){
            $columns = array(
                'cb' => '<input type="checkbox" />',
                'ref_id' => '推荐用户',
                'user_id' => '被推荐用户',
                'order_id' => '推荐订单',
                'income' => '佣金收入',
                'time' => '交易时间'
            );
            return $columns;
        }

        public function process_bulk_action() {
            global $wpdb;
            if ( 'delete-log' === $this->current_action() ) {
                $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                if ( wp_verify_nonce( $nonce, 'bulk-affiliate' ) ) {
                    $ids = isset($_REQUEST['check']) ? $_REQUEST['check'] : array();
                    if(!empty($ids)) {
                        $ids = implode( ',', array_map( 'absint', $ids ) );
                        $wpdb->query("DELETE FROM $this->table WHERE ID IN($ids)");
                    }
                }else if(isset($_GET['id']) && $_GET['id']){
                    $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                    if ( wp_verify_nonce( $nonce, 'delete-log_'.$_GET['id'] ) ) {
                        $wpdb->delete($this->table, array('ID' => $_GET['id']));
                    }
                }
            }
        }

        protected function get_bulk_actions() {
            $actions           = array();
            $actions['delete-log'] = __( 'Delete' );
            return $actions;
        }
        protected function get_sortable_columns() {
            return array(
                'ref_id' => 'ref_id',
                'income' => 'income',
                'time' => 'time'
            );
        }
        protected function get_default_primary_column_name() {
            return 'ref_id';
        }
        public function column_cb( $log ) { ?>
            <label class="screen-reader-text" for="cb-select-<?php echo $log->ID; ?>"> </label>
            <input type="checkbox" name="check[]" id="cb-select-<?php echo $log->ID; ?>" value="<?php echo esc_attr( $log->ID ); ?>" />
            <?php
        }
        public function column_ref_id( $log ) {
            $user = get_user_by('ID', $log->ref_id);
            if(!is_wp_error($user) && isset($user->ID)) {
                $edit_link = add_query_arg( 'wp_http_referer', urlencode( wp_unslash( $_SERVER['REQUEST_URI'] ) ), get_edit_user_link( $user->ID ) );
                return '<a href="'.esc_url($edit_link).'" target="_blank">'.$user->display_name.'</a>';
            }else{
                return $log->ref_id;
            }
        }
        public function column_user_id( $log ) {
            $user = get_user_by('ID', $log->user_id);
            if(!is_wp_error($user) && isset($user->ID)) {
                $edit_link = add_query_arg( 'wp_http_referer', urlencode( wp_unslash( $_SERVER['REQUEST_URI'] ) ), get_edit_user_link( $user->ID ) );
                return '<a href="'.esc_url($edit_link).'" target="_blank">'.$user->display_name.'</a>';
            }else{
                return $log->user_id;
            }
        }
        public function column_order_id( $log ) {
            $order = WPCOM_Order::get_order($log->order_id);
            if($order && isset($order->ID)){
                $items = WPCOM_Order::get_order_items($order->ID);
                $edit_link = admin_url('admin.php?page=wpcom-edit-order&id='.$order->ID);
                $html = '<a href="'.esc_url($edit_link).'" target="_blank">'.$order->number.'</a>';
                if ($items) {
                    $html .= '<div style="padding: 5px 10px;border-radius:4px;background: rgba(0,0,0,.04);line-height: 1.67;margin:4px 0 0;">';
                    foreach ($items as $item) {
                        $url = apply_filters('wpcom_order_item_url', '', $item);
                        if($url){
                            $html .= '<div class="orders-list-item"><a class="orders-list-item-title" href="'.esc_url($url).'" target="_blank">'.$item->title.'</a></div>';
                        }else{
                            $html .= '<div class="orders-list-item-title">'.$item->title.'</div>';
                        }
                    }
                    $html .= '</div>';
                }
                return $html;
            }else{
                return $log->order_id;
            }
        }
        public function column_time( $log ) {
            return $log->time;
        }
        public function column_income( $log ) {
            return number_format($log->income, 2, '.', '');
        }
        protected function handle_row_actions( $log, $column_name, $primary ) {
            if ( $primary !== $column_name ) return '';

            $actions           = array();
            $actions['delete'] = sprintf(
                '<a class="submitdelete" href="%s" onclick="return confirm( \'%s\' );">%s</a>',
                wp_nonce_url( "?page=wpcom-affiliate-logs&tab=logs&action=delete-log&id=$log->ID", 'delete-log_' . $log->ID ),
                esc_js( sprintf( __( "即将删除此推广佣金记录，请问是否确认删除？", 'wpcom' ), $log->ID ) ),
                __( 'Delete' )
            );

            return $this->row_actions( $actions );
        }
    }
endif;