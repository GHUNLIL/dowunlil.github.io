<?php
defined('ABSPATH') || exit;
class WPCOM_Invitation_Code{
    protected static $table = 'wpcom_invitcodes';
    function __construct(){
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('wpcom_invitcodes_cron', array($this, 'cron') );
        add_action('register_form', array($this, 'default_register_form'));
        add_action('signup_extra_fields', array($this, 'default_register_form') );
        add_action('user_register', array($this, 'user_register') );
        add_action('wpmx_social_login_register_form', array($this, 'sl_register'));
        add_action('load-index.php', function(){ self::init_database(); });

        add_filter('wpcom_member_invitcodes_metas', array($this, 'invitcodes_metas'), 1);
        add_filter('wpcom_member_edit_code_metas', array($this, 'edit_code_metas'), 1);
        add_filter('registration_errors', array($this, 'registration_errors'));
        add_filter('wpmu_validate_user_signup' , array($this, 'registration_errors') );
        add_filter('wpcom_register_form_items',  array($this, 'wpcom_register_form') );
        add_filter('wpcom_register_form_validate', array($this, 'registration_errors'));
        add_filter('wpcom_login_field_text', array($this, 'input_notice'), 10, 2);
        add_filter('wpmx_social_login_pre_insert_user', array($this, 'registration_errors'));

        add_filter('parent_file', array($this, 'parent_file_filter'));
        add_filter('submenu_file', array($this, 'submenu_file_filter'));
    }

    public function admin_menu() {
        add_submenu_page('wpcom-member-pro', '邀请码', '邀请码', 'manage_options', 'wpcom-invitation-code', array(&$this, 'codes_list'), 10);
        add_submenu_page('wpcom-invitation-code', '生成邀请码', '生成邀请码', 'manage_options', 'wpcom-add-code', array(&$this, 'add_code'), 10);
        add_submenu_page('wpcom-invitation-code', '编辑邀请码', '编辑邀请码', 'manage_options', 'wpcom-edit-code', array(&$this, 'edit_code'), 10);
        if (!wp_next_scheduled ( 'wpcom_invitcodes_cron' )) wp_schedule_event(time(), 'hourly', 'wpcom_invitcodes_cron');
    }

    public function parent_file_filter($parent_file) {
        global $_wp_real_parent_file, $plugin_page, $_wp_menu_nopriv;
        if($plugin_page === 'wpcom-add-code' || $plugin_page === 'wpcom-edit-code'){
            $_wp_real_parent_file[$plugin_page] = 'wpcom-member-pro';
            $_wp_menu_nopriv[$plugin_page] = 'wpcom-member-pro';
            if ($parent_file === 'wpcom-invitation-code') $parent_file = 'wpcom-member-pro';
        }
        return $parent_file;
    }

    public function submenu_file_filter($submenu_file) {
        global $pagenow;
        $screen = get_current_screen();
        if ($pagenow == 'admin.php' && ($screen->base == 'admin_page_wpcom-add-code' || $screen->base == 'admin_page_wpcom-edit-code')) {
            $submenu_file = 'wpcom-invitation-code';
        }
        return $submenu_file;
    }

    public function codes_list() { ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">邀请码</h1>
            <a href="<?php echo admin_url('admin.php?page=wpcom-add-code'); ?>" class="page-title-action">生成邀请码</a>
            <form method="post">
                <?php
                if (!class_exists('WPCOM_Invitation_Code_List')) require_once WPCOM_MP_DIR . '/includes/invitation-code-list.php';
                $list = new WPCOM_Invitation_Code_List();
                $list->prepare_items();
                $list->search_box('搜索邀请码', 'codes');
                $list->display();
                ?>
            </form>
        </div>
    <?php }

    public function add_code() {
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        WPCOM_ADMIN_UTILS::panel_script();
        $data = map_deep($_POST, 'sanitize_text_field');
        $res = $data && isset($data['add-code-nonce']) && wp_verify_nonce($data['add-code-nonce'], 'add-code') ? self::generate_code($data) : '';
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">生成邀请码</h1>
            <?php if (!is_wp_error($res) && !empty($res)) { ?>
                <div id="message" class="notice notice-success">
                    <p><strong>邀请码生成成功。</strong></p>
                    <p><a href="<?php echo admin_url('admin.php?page=wpcom-invitation-code'); ?>">← 返回“邀请码”页面 </a></p>
                </div>
            <?php } else if (is_wp_error($res)) { ?>
                <div id="message" class="notice notice-error">
                    <p><strong>邀请码生成失败。</strong></p>
                    <p><?php echo $res->get_error_message(); ?></p>
                </div>
            <?php } ?>
            <?php if (!is_wp_error($res) && !empty($res)) { ?>
                <h3>本次生成的邀请码</h3>
                <p>多个邀请码则一行一个，可点击下方按钮一键复制</p>
                <div class="form-field">
                    <textarea name="invitation-code" id="invitation-code" cols="30" rows="10"><?php echo implode("\r\n", $res);?></textarea>
                </div>
                <div class="form-field">
                    <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="复制邀请码"></p>
                </div>
                <script>
                if (typeof _plugins_options === 'undefined') _plugins_options = [];
                jQuery(function($){
                    $('#submit').on('click', function(){
                        if( typeof document.execCommand !== 'undefined' ){
                            var t = document.querySelector('#invitation-code');
                            t.select();
                            document.execCommand('copy');
                            alert('复制成功');
                        }else{
                            alert('浏览器不支持复制，请通过手动全选复制来完成复制操作');
                        }
                    })
                })
                </script>
            <?php } else { ?>
            <form name="add-code" id="edittag" method="post" action="" class="add-code validate">
                <?php wp_nonce_field('add-code', 'add-code-nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr id="wpcom-plugin-panel" class="wpcom-term-wrap">
                        <td colspan="2">
                            <term-panel :ready="ready" />
                        </td>
                    </tr>
                </table>
                <input type="submit" class="button button-primary" value="提交" />
            </form>
            <div style="display: none;"><?php wp_editor('EDITOR', 'WPCOM-EDITOR', WPCOM_ADMIN_UTILS::editor_settings(array('textarea_name' => 'EDITOR-NAME'))); ?></div>
            <script>
                if (typeof _plugins_options === 'undefined') _plugins_options = [];
                _plugins_options.push(<?php echo $this->get_invitcodes_metas(); ?>);
            </script>
            <?php } ?>
        </div>
    <?php }

    public function edit_code(){
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        WPCOM_ADMIN_UTILS::panel_script();
        $data = map_deep($_POST, 'sanitize_text_field');
        $res = $data && isset($data['edit-code-nonce']) && wp_verify_nonce($data['edit-code-nonce'], 'edit-code') ? self::update_code($data) : '';
        $id = isset($_GET['id']) ? sanitize_text_field($_GET['id']) : 0;
        if($id && $code = self::get_code($id, 'ID')){
            if($data && $code && $res !== ''){
                $code->code = trim($data['wpcom_code']);
                $code->expired = trim($data['wpcom_expired']);
                $code->times = trim($data['wpcom_times']);
                $code->disable = $data['wpcom_disable'];
            }
            ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">编辑邀请码</h1>
            <?php if (!is_wp_error($res) && !empty($res)) { ?>
                <div id="message" class="notice notice-success">
                    <p><strong>邀请码更新成功。</strong></p>
                    <p><a href="<?php echo admin_url('admin.php?page=wpcom-invitation-code'); ?>">← 返回“邀请码”页面 </a></p>
                </div>
            <?php } else if (is_wp_error($res)) { ?>
                <div id="message" class="notice notice-error">
                    <p><strong>邀请码更新失败。</strong></p>
                    <p><?php echo $res->get_error_message(); ?></p>
                </div>
            <?php } ?>
            <form name="edit-code" id="edittag" method="post" action="" class="add-code validate">
                <input type="hidden" name="code_id" value="<?php echo esc_attr($id); ?>" />
                <?php wp_nonce_field('edit-code', 'edit-code-nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr id="wpcom-plugin-panel" class="wpcom-term-wrap">
                        <td colspan="2">
                            <term-panel :ready="ready" />
                        </td>
                    </tr>
                </table>
                <input type="submit" class="button button-primary" value="提交" />
            </form>
            <div style="display: none;"><?php wp_editor('EDITOR', 'WPCOM-EDITOR', WPCOM_ADMIN_UTILS::editor_settings(array('textarea_name' => 'EDITOR-NAME'))); ?></div>
            <script>
                if (typeof _plugins_options === 'undefined') _plugins_options = [];
                _plugins_options.push(<?php echo $this->get_invitcodes_metas($code); ?>);
            </script>
        </div>
        <?php }else{
            wp_die('邀请码获取失败');
        }
    }

    function update_code($data){
        global $wpdb;
        $_code = isset($data['code_id']) ? self::get_code($data['code_id'], 'ID') : '';
        if(!$_code) return new WP_Error('code_error', '获取邀请码信息失败');
        $code = array();
        $data['wpcom_code'] = isset($data['wpcom_code']) ? trim($data['wpcom_code']) : '';
        if($data['wpcom_code'] && preg_match('/^[a-zA-Z0-9_-]{6,64}$/', $data['wpcom_code'])){
            $code['code'] = $data['wpcom_code'];
        }else{
            return new WP_Error('code_error', '邀请码错误：仅支持字母、数字以及 _ - 符号');
        }
        $expired = isset($data['wpcom_expired']) ? trim($data['wpcom_expired']) : '';
        if($expired){
            $expired = str_replace('：', ':', $expired);
            try{
                $date = new DateTime($expired, wp_timezone());
                $expired = $date->format('Y-m-d H:i:s');
                $code['expired'] = $expired;
            }catch(Exception $e){
                return new WP_Error('expired_error', '过期时间格式错误');
            }
        }
        $code['times'] = isset($data['wpcom_times']) && is_numeric(trim($data['wpcom_times'])) && trim($data['wpcom_times']) > 0 ? trim($data['wpcom_times']) : 1;
        $code['status'] = isset($data['wpcom_disable']) && $data['wpcom_disable'] == '1' ? '-1' : $_code->status;
        if(isset($data['wpcom_disable']) && $data['wpcom_disable'] == '1'){
            $code['status'] = -1;
        }else{
            $code['status'] = 0;
            $date2 = new DateTime($expired, wp_timezone());
            $expired2 = $date2->format('U');
            if($expired && $expired2 > 0 && $expired2 < time()){ // 过期
                $code['status'] = 2;
            }
            if($_code->users && $users = maybe_unserialize($_code->users)){ // 达到次数限制
                if(is_array($users) && count($users) >= $code['times']){
                    $code['status'] = 1;
                }
            }
        }
        $table = $wpdb->prefix . self::$table;
        return $wpdb->update($table, $code, array('ID' => $_code->ID));
    }

    public static function generate_code($data){
        $prefix = isset($data['wpcom_prefix']) ? trim($data['wpcom_prefix']) : '';
        if(!preg_match('/^[a-zA-Z0-9_-]{0,32}$/', $prefix)){
            return new WP_Error('prefix_error', '邀请码前缀错误：仅支持字母、数字以及 _ - 符号');
        }
        $len = isset($data['wpcom_len']) && is_numeric(trim($data['wpcom_len'])) && trim($data['wpcom_len']) >= 6 && trim($data['wpcom_len']) <= 64 ? trim($data['wpcom_len']) : 32;
        $times = isset($data['wpcom_times']) && is_numeric(trim($data['wpcom_times'])) && trim($data['wpcom_times']) > 0 ? trim($data['wpcom_times']) : 1;
        $expired = isset($data['wpcom_expired']) ? trim($data['wpcom_expired']) : '';
        if($expired){
            $expired = str_replace('：', ':', $expired);
            try{
                $date = new DateTime($expired, wp_timezone());
                $expired = $date->format('Y-m-d H:i:s');
            }catch(Exception $e){
                return new WP_Error('expired_error', '过期时间格式错误');
            }
        }
        $num = isset($data['wpcom_num']) && is_numeric(trim($data['wpcom_num'])) && trim($data['wpcom_num']) > 0 ? (int) trim($data['wpcom_num']) : 1;
        $num = $num > 100 ? 100 : $num;
        $codes = array();
        $i=0; $x = 0;
        while ( $i < $num && $x < 200 ){
            $code = $prefix . wp_generate_password($len, false);
            $res = self::insert_code($code, $times, $expired);
            if($res) {
                $codes[] = $code;
                $i++;
            }
            $x++;
        }
        return $codes;
    }

    public static function insert_code($code, $times, $expired){
        global $wpdb;
        $table = $wpdb->prefix . self::$table;
        $sql = "insert ignore into $table ( code, times, users, expired, status ) values( '$code', '$times', '', '$expired', 0 )";
        return $wpdb->query($sql);
    }

    public static function get_code($val, $by='code'){
        global $wpdb;
        $table = $wpdb->prefix . self::$table;
        $code = $wpdb->get_row("SELECT * FROM `$table` WHERE `$by` = '$val'");
        if ($code && $code->ID) return $code;
    }

    private function get_invitcodes_metas($code = null) {
        $res = array('type' => 'taxonomy', 'tax' => 'invitcodes', 'options' => array());
        if($code && isset($code->ID)){
            $res['options'] = $code;
            if($code->status == '-1') $res['options']->disable = 1;
        }
        $plugin = $GLOBALS['wpcom_mp']->info;
        $res['filters'] = apply_filters($code ? 'wpcom_member_edit_code_metas' : 'wpcom_member_invitcodes_metas', array());
        $res['ver'] = $plugin['ver'];
        $res['plugin-id'] = $plugin['plugin_id'];
        $res['plugin-slug'] = $plugin['slug'];
        $res['framework_ver'] = WPCOM_ADMIN_UTILS::framework_version($plugin['slug']);
        return wp_json_encode($res);
    }

    function default_register_form($errors){
        $options = $GLOBALS['wpmx_options'];
        $invitation_code = '';
        if ( isset( $_POST['invitation_code'] ) && is_string( $_POST['invitation_code'] ) ) {
            $invitation_code = wp_unslash( sanitize_text_field($_POST['invitation_code']) );
        }
        $action = current_filter();
        if($action === 'register_form'){
        ?>
        <p>
            <label for="invitation_code">邀请码</label>
            <input type="text" name="invitation_code" id="invitation_code" class="input" value="<?php echo esc_attr( $invitation_code ); ?>" size="100" autocomplete="off" />
        </p>
        <?php
            if(isset($options['invitcode_input']) && $options['invitcode_input']){
                echo '<p style="margin:-12px 6px 16px 0;">' . wp_kses($options['invitcode_input'], wpmx_allowed_html()) . '</p>';
            }
        } else if($action === 'signup_extra_fields'){ ?>
            <label for="invitation_code">邀请码</label>
            <?php if ( $errmsg = $errors->get_error_message( 'invitation_code_error' ) ) : ?>
                <p class="error"><?php echo $errmsg; ?></p>
            <?php endif; ?>
            <input style="width: 100%; font-size: 24px; margin: 5px 0;" type="text" name="invitation_code" id="invitation_code" class="input" value="<?php echo esc_attr( $invitation_code ); ?>" size="100" autocomplete="off" />
            <?php
            if(isset($options['invitcode_input']) && $options['invitcode_input']){
                echo '<br />' . wp_kses($options['invitcode_input'], wpmx_allowed_html());
            }
            ?>
        <?php }
    }

    function sl_register(){
        $options = $GLOBALS['wpmx_options'];?>
        <div class="sl-input-item">
            <label>邀请码</label>
            <div class="sl-input">
                <input class="require" type="text" name="invitation_code" placeholder="请输入邀请码">
            </div>
             <?php if(isset($options['invitcode_input']) && $options['invitcode_input']){ ?>
                <div class="form-input-desc"><?php echo wp_kses($options['invitcode_input'], wpmx_allowed_html());?></div>
            <?php } ?>
        </div>
    <?php }

    function wpcom_register_form($items){
        $item = array(
            'type' => 'text',
            'label' => '邀请码',
            'icon' => 'shield-keyhole',
            'name' => 'invitation_code',
            'require' => true,
            'placeholder' => '请输入邀请码',
        );
        if(is_wpcom_enable_phone()) {
            $items += array(
                45 => $item
            );
        }else{
            $items += array(
                35 => $item
            );
        }

        return $items;
    }

    function registration_errors($res){
        $action = current_filter();
        $err = '';
        if ( empty( $_POST['invitation_code'] ) ) {
            $err = '请填写邀请码';
        }else{
            $invitation_code = sanitize_text_field( $_POST['invitation_code'] );
            $status = self::get_code_status($invitation_code);
            if($status === false){
                $err = '请填写正确的邀请码';
            }else if($status !== 0){
                $err = '邀请码不可用';
            }
        }

        if($action === 'wpcom_register_form_validate' && $res['result'] == 1 && $err){
            $res['result'] = 0;
            $res['error'] = $err;
        }else if($action === 'wpmx_social_login_pre_insert_user' && $err){
            return new WP_Error( 'invitation_code_error', $err );
        }else if($err){
            $errors = $action === 'registration_errors' ? $res : $res['errors'];
            $errors->add( 'invitation_code_error', $err );
            if($action === 'registration_errors'){
                $res = $errors;
            }else{
                $res['errors'] = $errors;
            }
        }

        return $res;
    }

    function user_register($user_id){
        if(!$user_id) return false;
        if ( !empty( $_POST['invitation_code'] ) && sanitize_text_field( $_POST['invitation_code'] ) !== '' ) {
            $code = sanitize_text_field( $_POST['invitation_code'] );
            $this->update_for_user_register($user_id, $code);
        }
    }

    function update_for_user_register($user_id, $code){
        global $wpdb;
        $table = $wpdb->prefix . self::$table;
        $result = self::get_code($code);
        if($result && isset($result->ID)){
            $users = maybe_unserialize($result->users);
            $users = $users ?: array();
            $users[] = $user_id;
            $users = array_filter($users);
            $status = $result->status;
            if(count($users) >= $result->times){
                $status = 1;
            }
            $_code = array(
                'users' => maybe_serialize($users),
                'status' => $status
            );

            add_user_meta( $user_id, 'invitation_code', $result->code, true );
            return $wpdb->update($table, $_code, array('ID' => $result->ID));
        }
    }

    public static function get_code_status($invitation_code){
        $code = self::get_code($invitation_code);
        if($code && isset($code->ID)){
            if($code->status == '0'){
                if($code->expired && $code->expired != '0000-00-00 00:00:00' ){ // 过期
                    $date = new DateTime($code->expired, wp_timezone());
                    $expired = $date->format('U');
                    if($expired < time()) $code->status = 2;
                }
                if($code->users && $users = maybe_unserialize($code->users)){
                    if(is_array($users) && $count = count($users)){
                        if($count >= $code->times) $code->status = 1;
                    }
                }
            }
            return (int) $code->status;
        }
        return false;
    }

    public function invitcodes_metas($metas) {
        $metas['invitcodes'] = array(
            array(
                'n' => 'prefix',
                'l' => '邀请码前缀',
                'd' => '可选，不设置则无前缀'
            ),
            array(
                'n' => 'len',
                'l' => '邀请码长度',
                's' => 32,
                'd' => '字符长度，最少6，最大64，不包含前缀，不设置或者长度不符则为默认 32'
            ),
            array(
                'n' => 'times',
                'l' => '使用次数',
                's' => 1,
                'd' => '可选，邀请码可使用的次数限制，不设置默认为1次'
            ),
            array(
                'n' => 'expired',
                'l' => '过期时间',
                'd' => '可选，不设置则无时间限制，格式：'.current_time('mysql')
            ),
            array(
                'n' => 'num',
                'l' => '生成数量',
                's' => 1,
                'd' => '可批量生成多个，不设置默认仅生成1个，同时为避免误输入导致性能问题，每次生成数量上限为100'
            ),
        );
        return $metas;
    }

    public function edit_code_metas($metas) {
        $metas['invitcodes'] = array(
            array(
                'n' => 'code',
                'l' => '邀请码',
                'd' => '长度最少6，最大64'
            ),
            array(
                'n' => 'times',
                'l' => '使用次数',
                's' => 1,
                'd' => '可选，邀请码可使用的次数限制，不设置默认为1次'
            ),
            array(
                'n' => 'expired',
                'l' => '过期时间',
                'd' => '可选，不设置则无时间限制，格式：'.current_time('mysql')
            ),
            array(
                'n' => 'disable',
                'l' => '停用此邀请码',
                't' => 't',
                'd' => '开启后邀请码无法使用，关闭后将根据过期时间、可用次数进行判断'
            )
        );
        return $metas;
    }

    public function input_notice($html, $args){
        if(isset($args['name']) && $args['name'] === 'invitation_code'){
            $options = $GLOBALS['wpmx_options'];
            if(isset($options['invitcode_input']) && $options['invitcode_input']){
                $html .= '<div class="form-input-desc">'.wp_kses($options['invitcode_input'], wpmx_allowed_html()).'</div>';
            }
        }
        return $html;
    }

    private static function init_database(){
        global $wpdb;
        $table = $wpdb->prefix . self::$table;
        if( $wpdb->get_var("SHOW TABLES LIKE '$table'") != $table ){
            $charset_collate = $wpdb->get_charset_collate();
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            $create_sql = "CREATE TABLE $table (".
                "ID BIGINT(20) NOT NULL auto_increment,".
                "code varchar(100) NOT NULL,".
                "times INT NOT NULL,".
                "users text,".
                "expired datetime,".
                "status varchar(20),".
                "PRIMARY KEY (ID),".
                "UNIQUE KEY (code)) $charset_collate;";
            dbDelta( $create_sql );
        }
    }

    public static function cron(){
        global $wpdb;
        $table = $wpdb->prefix . self::$table;
        if( $wpdb->get_var("SHOW TABLES LIKE '$table'") == $table ) {
            $time = current_time('mysql');
            $temps = $wpdb->get_results("SELECT * FROM `$table` WHERE expired > '1000-00-00 00:00:00' AND expired < '$time' AND status='0'");
            if ($temps) {
                foreach ($temps as $temp) {
                    $wpdb->update($table, array('status' => 2), array('ID' => $temp->ID));
                }
            }
        }
    }
}

new WPCOM_Invitation_Code();