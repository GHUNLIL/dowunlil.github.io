<?php defined('ABSPATH') || exit;

class WPCOM_Premium_Content {
    function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_ajax_wpcom_get_premium_content', array($this, 'premium_content'));
        add_action('wp_ajax_nopriv_wpcom_get_premium_content', array($this, 'premium_content'));

        add_action('wp_ajax_wpcom_get_premium_content_data', array($this, 'premium_content_data'));
        add_action('wp_ajax_nopriv_wpcom_get_premium_content_data', array($this, 'premium_content_data'));

        add_action('wpcom_order_item_detail_premium-content', array($this, 'show_in_order'));
        add_filter('wpcom_order_item_url', array($this, 'order_item_url'), 10, 2);

        add_filter('the_content', array($this, 'unlock_content'));
        add_filter('wpmx_premium_content_sales_html', array($this, 'sales_html'), 10, 2);

        if(defined('WWA_VERSION')){
            add_action('rest_api_init', array($this, 'for_rest_api') );
        }
    }

    public function init() {
        register_block_type('wpcom/premium-content', array(
            'render_callback' => function ($attr, $content) {
                global $post, $wpcom_member;
                extract($attr);
                $sales = 0;
                if(isset($attr['show_sales']) && $show_sales){
                    $sales = WPCOM_Order::get_item_sales('premium-content', $post->ID.'::'.$id);
                    if(isset($attr['sales_base']) && $sales_base) $sales += $sales_base;
                    $sales = apply_filters('wpcom_premium_content_sales', $sales, $attr, $post);
                }
                $attr['sales'] = $sales;
                $output = $wpcom_member->load_template('premium-content', $attr);
                return '<div class="wp-block-wpcom-premium-content">' . $output . '</div>';
            }
        ));
    }

    public function unlock_content($content){
        global $post;
        if(!isset($post->ID)) return $content;
        $view_type = get_post_meta($post->ID, 'wpcom_view_type', true);
        if($view_type === '1'){
            if(function_exists('WWA_is_rest') && WWA_is_rest()){
                preg_match( '/<!--more(.*?)?-->/i', $content, $matches );
            }else{
                preg_match( '/<span id="more-' . $post->ID . '"><\/span>/i', $content, $matches );
            }
            if ( $matches && isset($matches[0]) ) {
                $content = explode( $matches[0], $content, 2 );
                $content = $content[0];
                $text = '解锁查看全文';
                if ( preg_match( '/<!--more(.*?)?-->/', $post->post_content, $matches2 ) ) {
                    $text = isset($matches2[1]) && $matches2[1] ? $matches2[1] : $text;
                }
                $content .= '<div class="wpcom-unlock-more"><span>剩余内容需解锁观看</span></div>';
                $type = get_post_meta($post->ID, 'wpcom_unlock_type', true);
                if($type === '3' || $type === '5'){
                    $blockName = 'wpcom/premium-content';
                    $attrs = $this->generate_premium_block_attrs($post);
                    $attrs['tips'] = $text;
                }else{
                    $blockName = 'wpcom/hidden-content';
                    $attrs = array(
                        'id' => 'post-hidden-content-'.$post->ID,
                        'type' => $type ? $type : '0',
                        'user_group' => $type === '2' ? get_post_meta($post->ID, 'wpcom_unlock_groups', true) : '',
                        'tips' => $text
                    );
                    if($type === '4'){
                        $attrs['type'] = '3';
                        $attrs['password'] = get_post_meta($post->ID, 'wpcom_unlock_password', true);
                    }
                }
                $content .= render_block(array(
                    'blockName' => $blockName,
                    'attrs' => $attrs,
                    'innerBlocks' => array(),
                    'innerHTML' => '',
                    'innerContent' => array()
                ));
            }
        }

        return $content;
    }

    public function sales_html($html, $sales){
        global $wpmx_options;
        if(isset($wpmx_options['content_sales_text']) && trim($wpmx_options['content_sales_text'])){
            $html = wpmx_icon('huo', 0) . str_replace('%SALES%', '<span class="premium-content-sales">'.$sales.'</span>', trim($wpmx_options['content_sales_text']));
        }
        return $html;
    }

    public function premium_content() {
        remove_filter('the_content','wpautop');
        $post_id = isset($_POST['post_id']) ? sanitize_text_field($_POST['post_id']) : 0;
        $res = $this->get_premium_content($post_id);
        wp_send_json($res);
    }

    function get_premium_content($post_id){
        global $post;
        $res = array();
        if($post_id && $post = get_post($post_id)){
            if(isset($post->ID)){
                $blocks = $this->get_premium_content_blocks($post);
                if($blocks && is_array($blocks)){
                    foreach ($blocks as $block){
                        if(isset($block['attrs']) && (isset($block['attrs']['price']) || isset($block['attrs']['vip_price']) || (isset($block['attrs']['vip']) && $block['attrs']['vip']) ) && isset($block['attrs']['id']) && $block['attrs']['id']){
                            $order_id = WPCOM_Order::is_admin_free($post->ID);
                            $content_id = $post->ID . '::' . $block['attrs']['id'];
                            if(!$order_id){
                                $vip_price = isset($block['attrs']['vip_price']) ? $block['attrs']['vip_price'] : array();
                                $price = isset($block['attrs']['vip']) && $block['attrs']['vip'] ? 0 : $block['attrs']['price'];
                                $order_id = WPCOM_VIP::is_vip_free($price, $vip_price, 'content') && WPCOM_VIP::is_vip_visable('premium-content/'.$content_id);
                            }
                            if(!$order_id) $order_id = WPCOM_Order::is_item_paid('premium-content', $content_id);
                            if($order_id && isset($block['innerBlocks'])){
                                $output = '';
                                foreach ( $block['innerBlocks'] as $b ) {
                                    $output .= render_block( $b );
                                }
                                $content = apply_filters('the_content', $output);
                                $res[$block['attrs']['id']] = $content;
                            }
                        }
                    }
                }
            }
        }
        return $res;
    }

    function get_premium_content_blocks($post){
        $blocks = parse_blocks($post->post_content);
        $res = $this->loop_blocks($blocks);
        if((empty($blocks) || empty($res)) && class_exists('WPCOM_Module')){
            $template = get_post_meta($post->ID, '_wp_page_template', true);
            if($template === 'page-home.php'){
                $blocks = WPCOM_MP_get_gutenberg_blocks($post->ID);
                if($blocks && !empty($blocks)) $res = $this->loop_blocks($blocks);
            }
        }
        $view_type = get_post_meta($post->ID, 'wpcom_view_type', true);
        if($blocks && $view_type === '1'){
            $type = get_post_meta($post->ID, 'wpcom_unlock_type', true);
            if($type === '3' || $type === '5'){
                $skip = true;
                $innerBlocks = array();
                foreach($blocks as $block){
                    if($block['blockName'] === 'core/more'){
                        $skip = false;
                    }else if($skip === false){
                        $innerBlocks[] = $block;
                    }
                }
                $attrs = $this->generate_premium_block_attrs($post);
                $res[] = array(
                    'blockName' => 'wpcom/premium-content',
                    'attrs' => $attrs,
                    'innerBlocks' => $innerBlocks,
                    'innerHTML' => '',
                    'innerContent' => array()
                );
            }
        }
        return $res;
    }

    public function order_item_url($url, $item){
        if($item && isset($item->type) && $item->type === 'premium-content' && $item->type_id && $ids = explode('::', $item->type_id)){
            $post_id = $ids[0];
            $block_id = $ids[1];
            if ($post_id && $post = get_post($post_id)) {
                $url = get_permalink($post->ID);
                if($block_id) $url .= '#' . $block_id;
            }
        }
        return $url;
    }

    public function show_in_order($item) {
        if ($item->type_id && $ids = explode('::', $item->type_id)) {
            $post_id = $ids[0];
            $block_id = $ids[1];
            if ($post_id && $post = get_post($post_id)) { ?>
                <ul class="member-account-order">
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">关联文章：</div>
                        <div class="member-account-order-value"><?php echo get_the_title($post->ID); ?></div>
                    </li>
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">付费内容：</div>
                        <div class="member-account-order-value"><?php echo $item->title;?></div>
                    </li>
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">内容链接：</div>
                        <div class="member-account-order-value">
                            <a class="btn btn-primary btn-xs" href="<?php echo esc_url(get_permalink($post->ID)); ?>#<?php echo $block_id;?>" target="_blank">点击查看</a>
                        </div>
                    </li>
                </ul>
            <?php }
        }
    }

    public function premium_content_data($return = false) {
        $res = array('result' => 0);
        if (WPCOM_MP_can_setup_order()) {
            $post_id = isset($_POST['post_id']) ? sanitize_text_field($_POST['post_id']) : '';
            $id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
            if ($post_id && $id) {
                $block = $this->get_block($post_id, $id);
                if ($block && isset($block['attrs'])) {
                    $post = get_post($post_id);
                    $user_id = get_current_user_id();
                    $_price = isset($block['attrs']['price']) && $block['attrs']['price'] ? $block['attrs']['price'] : 0;
                    // VIP专属默认价格为0
                    $_price = isset($block['attrs']['vip']) && $block['attrs']['vip'] ? 0 : $_price;
                    $_vip_price = isset($block['attrs']['vip_price']) && $block['attrs']['vip_price'] ? $block['attrs']['vip_price'] : array();
                    $price = WPCOM_VIP::get_vip_price_by_user($user_id, $_price, $_vip_price, 'content');
                    $items = array(
                        array(
                            'title' => isset($block['attrs']['title']) && $block['attrs']['title'] ? $block['attrs']['title'] : '文章【' . $post->post_title . '】的付费内容',
                            'price' => number_format($price, 2, '.', ''),
                            'url' => get_permalink($post_id),
                            'number' => 1,
                            'type' => 'premium-content',
                            'type_id' => $post_id . '::' . $id
                        )
                    );
                    $res['total'] = number_format($price, 2, '.', '');
                    $res['items'] = $items;
                    $res = WPCOM_Order::setup_order_data($res);
                    if($price == 0 && $vip = WPCOM_VIP::get_user_vip($user_id)){ // VIP资源提示解锁
                        $res['result'] = -9;
                        $res['type'] = 'premium-content';
                        $res['vip'] = array(
                            'id' => $vip['id'],
                            'icon' => $vip['icon'],
                            'title' => $vip['title'],
                            'upgrade' => WPCOM_VIP::vip_can_upgrade($vip)
                        );
                        $res['unlock_times'] = WPCOM_VIP::get_vip_unlock_times($user_id);
                    }
                } else {
                    $res['result'] = -3;
                }
            } else {
                $res['result'] = -2;
            }
        } else { // 未登录
            $res['result'] = -1;
        }
        if($return) return $res;
        wp_send_json($res);
    }

    private function get_block($post_id, $id) {
        $post = get_post($post_id);
        $blocks = parse_blocks($post->post_content);
        if(preg_match('/^post-premium-content-'.$post_id.'$/i', $id)){
            $skip = true;
            $innerBlocks = array();
            foreach($blocks as $block){
                if($block['blockName'] === 'core/more'){
                    $skip = false;
                }else if($skip === false){
                    $innerBlocks[] = $block;
                }
            }
            $block = array(
                'blockName' => 'wpcom/premium-content',
                'attrs' => $this->generate_premium_block_attrs($post),
                'innerBlocks' => $innerBlocks,
                'innerHTML' => '',
                'innerContent' => array()
            );
            return $block;
        }
        $block = WPCOM_MP_loop_find_block($blocks, $id, 'wpcom/premium-content');
        // 检查是否来自自定义页
        if(!$block && class_exists('WPCOM_Module')){
            $template = get_post_meta($post->ID, '_wp_page_template', true);
            if($template === 'page-home.php'){
                $block = WPCOM_MP_get_module_block($id, 'wpcom/premium-content', $post_id);
            }
        }
        return $block;
    }

    function loop_blocks($blocks){
        $res = array();
        if($blocks){
            foreach ($blocks as $block){
                if($block['blockName'] === 'wpcom/premium-content'){
                    $res[] = $block;
                }else if(isset($block['innerBlocks']) && $block['innerBlocks']){
                    $childs = $this->loop_blocks($block['innerBlocks']);
                    if($childs) $res = array_merge($res, $childs);
                }
            }
        }
        return $res;
    }

    private function generate_premium_block_attrs($post){
        $attrs = array();
        $type = get_post_meta($post->ID, 'wpcom_unlock_type', true);
        if($type === '3' || $type === '5'){
            $price = get_post_meta($post->ID, 'wpcom_unlock_price', true);
            $title = get_post_meta($post->ID, 'wpcom_unlock_title', true);
            $btn = get_post_meta($post->ID, 'wpcom_unlock_btn', true);
            $show_sales = (bool) get_post_meta($post->ID, 'wpcom_unlock_sales', true);
            if($show_sales){
                $sales_base = get_post_meta($post->ID, 'wpcom_unlock_sales_base', true);
                $sales_base = (int)($sales_base ?: 0);
            }
            $vip_types = WPCOM_VIP::get_vip_types();
            $vip_price = array();
            if(!empty($vip_types)){
                foreach($vip_types as $_type){
                    $id = $_type['id'];
                    $vip_price[$id.'_price'] = get_post_meta($post->ID, 'wpcom_'.$id.'_price', true);
                }
            }
            $attrs = array(
                'id' => 'post-premium-content-'.$post->ID,
                'price' => $price,
                'vip_price' => $vip_price,
                'title' => $title ?: $post->post_title,
                'show_sales' => $show_sales,
                'sales_base' => $show_sales && $sales_base ? $sales_base : 0,
                'btn' => $btn ?: '付费解锁'
            );
            if($type === '5') $attrs['vip'] = true;
        }
        return $attrs;
    }

    public function for_rest_api(){
        register_rest_route('wpcom/v1', '/premium-content', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array($this, 'rest_get_content'),
                'args'                => $this->rest_get_read_params(),
                'permission_callback' => array( $this, 'rest_permission_check' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array($this, 'rest_create_order'),
                'args'                => $this->rest_init_order_params(),
                'permission_callback' => array( $this, 'rest_permission_check' )
            )
        ));
    }

    function rest_get_read_params(){
        return array(
            'post_id' => array(
                'required'          => true,
                'default'           => 0,
                'type'              => 'integer',
                'validate_callback' => 'rest_validate_request_arg',
            )
        );
    }

    function rest_init_order_params(){
        return array(
            'post_id' => array(
                'required'          => true,
                'default'           => 0,
                'type'              => 'integer',
                'validate_callback' => 'rest_validate_request_arg',
            ),
            'block_id' => array(
                'required'          => true,
                'default'           => '',
                'type'              => 'string',
                'validate_callback' => 'rest_validate_request_arg',
            )
        );
    }

    function rest_get_content($request){
        $_POST = $_POST ?: array();
        $_POST['post_id'] = $request['post_id'];
        $this->premium_content();
    }

    function rest_create_order($request){
        $_POST = $_POST ?: array();
        $_POST['post_id'] = $request['post_id'];
        $_POST['id'] = $request['block_id'];
        $data = $this->premium_content_data(true);
        $data['nonce'] = wp_create_nonce('wpcom_payment_form');
        return rest_ensure_response( $data );
    }

    function rest_permission_check(){
        if ( get_current_user_id() ) {
            return true;
        } else {
            return new WP_Error( 'rest_user_cannot_view', '请登录后操作！', array( 'status' => 200 ) );
        }
    }
}

new WPCOM_Premium_Content();
