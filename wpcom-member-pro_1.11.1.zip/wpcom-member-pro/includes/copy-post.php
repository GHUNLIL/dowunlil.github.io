<?php defined( 'ABSPATH' ) || exit;

class WPCOM_Copy_Post{
    function __construct(){
        add_filter('wpmx_localize_script', array($this, 'localize_script'));
        add_action('wp_ajax_wpcom_copy_post_init', array($this, 'copy_post_init'));
        add_action('wp_ajax_nopriv_wpcom_copy_post_init', array($this, 'copy_post_init'));
        add_action('wp_ajax_wpcom_get_copy_post_data', array($this, 'get_copy_post_data'));
        add_action('wp_ajax_nopriv_wpcom_get_copy_post_data', array($this, 'get_copy_post_data'));
        add_action('wpcom_order_item_detail_copy-post', array($this, 'show_in_order'));
        add_filter('wpcom_order_item_url', array($this, 'order_item_url'), 10, 2);
    }

    public function localize_script($script){
        global $post;
        if(is_singular('post')){
            $enable = get_post_meta($post->ID, 'wpcom_copy_post', true);
            if($enable === ''){ // 获取全局设置
                $enable = wpcom_mp_options('copy_post');
            }
            if($enable === '1'){
                $script['copy_post'] = true;
                $text = get_post_meta($post->ID, 'wpcom_copy_post_text', true);
                $text = $text ?: wpcom_mp_options('copy_post_text');
                $script['copy_post_text'] = $text;
                $container = wpcom_mp_options('copy_post_container');
                $container = $container ?: '.entry-content';
                $script['copy_post_container'] = $container;
            }
        }
        return $script;
    }

    public function copy_post_init(){
        $res = array('result' => 0);
        $post = get_post(sanitize_text_field($_POST['post_id']));
        if(WPCOM_MP_can_setup_order() && isset($_POST['post_id']) && $post && $post->ID){
            $order_id = WPCOM_Order::is_admin_free($post->ID);
            if(!$order_id){
                $price = get_post_meta($post->ID, 'wpcom_copy_post_price', true);
                if($price === ''){ // 获取全局设置
                    $price = wpcom_mp_options('copy_post_price');
                }
                $vip_types = WPCOM_VIP::get_vip_types();
                $vip_price = array();
                if(!empty($vip_types)){
                    foreach($vip_types as $_type){
                        $id = $_type['id'];
                        $vip_price[$id.'_price'] = get_post_meta($post->ID, 'wpcom_'.$id.'_copy_post_price', true);
                    }
                }
                $order_id = WPCOM_VIP::is_vip_free($price, $vip_price, 'copy') && WPCOM_VIP::is_vip_visable('copy-post/'.$post->ID);
            }
            if(!$order_id) $order_id = WPCOM_Order::is_item_paid('copy-post', $post->ID);
            if($order_id){
                $res['result'] = 1;
            }else if(WPCOM_VIP::is_vip_free($price, $vip_price, 'copy')){ // VIP免费则提示解锁
                $res['result'] = -9;
            }
        }
        if($post && $post->ID && $res['result'] == 0){
            if(isset($price) && isset($vip_price)){
                $prices = WPCOM_VIP::get_vip_price_html($price, $vip_price, 'copy');
                if($prices) $res['vip_price'] = $prices;
            }else{
                $price = get_post_meta($post->ID, 'wpcom_copy_post_price', true);
                if($price === ''){ // 获取全局设置
                    $price = wpcom_mp_options('copy_post_price');
                }
                $vip_types = WPCOM_VIP::get_vip_types();
                $vip_price = array();
                if(!empty($vip_types)){
                    foreach($vip_types as $_type){
                        $id = $_type['id'];
                        $vip_price[$id.'_price'] = get_post_meta($post->ID, 'wpcom_'.$id.'_copy_post_price', true);
                    }
                    if($prices = WPCOM_VIP::get_vip_price_html($price, $vip_price, 'copy')) {
                        $res['vip_price'] = $prices;
                    }
                }
            }
            if(isset($res['vip_price']) && $res['vip_price']){
                $user_id = get_current_user_id();
                $res['is_vip'] = $user_id && WPCOM_VIP::get_user_vip($user_id);
            }
            $res['price'] =  number_format($price ?: 0, 2, '.', '');
        }
        wp_send_json($res);
    }
    public function get_copy_post_data(){
        $res = array('result' => 0);
        if (WPCOM_MP_can_setup_order()) {
            $post_id = isset($_POST['post_id']) ? sanitize_text_field($_POST['post_id']) : '';
            if ($post_id && $post = get_post($post_id)) {
                $price = get_post_meta($post->ID, 'wpcom_copy_post_price', true);
                if($price === ''){ // 获取全局设置
                    $price = wpcom_mp_options('copy_post_price');
                }
                $user_id = get_current_user_id();
                $vip_types = WPCOM_VIP::get_vip_types();
                $vip_price = array();
                if(!empty($vip_types)){
                    foreach($vip_types as $_type){
                        $id = $_type['id'];
                        $vip_price[$id.'_price'] = get_post_meta($post->ID, 'wpcom_'.$id.'_copy_post_price', true);
                    }
                }
                $price = WPCOM_VIP::get_vip_price_by_user($user_id, $price, $vip_price, 'copy');
                $items = array(
                    array(
                        'title' => '解锁【' . $post->post_title . '】的复制权限',
                        'price' => number_format($price ?: 0, 2, '.', ''),
                        'url' => get_permalink($post_id),
                        'number' => 1,
                        'type' => 'copy-post',
                        'type_id' => $post_id
                    )
                );
                $res['total'] = number_format($price ?: 0, 2, '.', '');
                $res['items'] = $items;
                $res = WPCOM_Order::setup_order_data($res);
                if($price == 0 && $vip = WPCOM_VIP::get_user_vip($user_id)){ // VIP资源提示解锁
                    $res['result'] = -9;
                    $res['type'] = 'copy-post';
                    $res['type_text'] = '复制权限';
                    $res['vip'] = array(
                        'id' => $vip['id'],
                        'icon' => $vip['icon'],
                        'title' => $vip['title'],
                        'upgrade' => WPCOM_VIP::vip_can_upgrade($vip)
                    );
                    $res['unlock_times'] = WPCOM_VIP::get_vip_unlock_times($user_id);
                }
            } else {
                $res['result'] = -2;
            }
        } else { // 未登录
            $res['result'] = -1;
        }
        wp_send_json($res);
    }

    public function order_item_url($url, $item){
        if($item && isset($item->type) && $item->type === 'copy-post' && $item->type_id){
            $post_id = $item->type_id;
            if ($post_id && $post = get_post($post_id)) {
                $url = get_permalink($post->ID);
            }
        }
        return $url;
    }

    public function show_in_order($item) {
        if ($item->type_id && $post = get_post($item->type_id)) {  ?>
            <ul class="member-account-order">
                <li class="member-account-order-item">
                    <div class="member-account-order-label">关联文章：</div>
                    <div class="member-account-order-value"><?php echo get_the_title($post->ID); ?></div>
                </li>
                <li class="member-account-order-item">
                    <div class="member-account-order-label">付费内容：</div>
                    <div class="member-account-order-value"><?php echo $item->title;?></div>
                </li>
                <li class="member-account-order-item">
                    <div class="member-account-order-label">内容链接：</div>
                    <div class="member-account-order-value">
                        <a class="btn btn-primary btn-xs" href="<?php echo esc_url(get_permalink($post->ID)); ?>" target="_blank">点击查看</a>
                    </div>
                </li>
            </ul>
        <?php }
    }
}

new WPCOM_Copy_Post();