<?php
defined('ABSPATH') || exit;

class WPCOM_Virtual_Service {
    function __construct() {
        add_action('init', array($this, 'init'));

        add_action('wp_ajax_wpcom_get_virtual_service_data', array($this, 'virtual_service_data'));
        add_action('wp_ajax_nopriv_wpcom_get_virtual_service_data', array($this, 'virtual_service_data'));

        add_action('wpcom_order_item_detail_virtual-service', array($this, 'show_in_order'));
        add_filter('wpcom_order_item_url', array($this, 'order_item_url'), 10, 2);
        add_filter('wpcom_order_virtual-service_set_number', '__return_true');

        add_filter('wpmx_virtual_service_sales_html', array($this, 'sales_html'), 10, 2);

        if(defined('WWA_VERSION')){
            add_action('rest_api_init', array($this, 'for_rest_api') );
        }
    }

    public function init() {
        register_block_type('wpcom/virtual-service', array(
            'render_callback' => function ($attr, $content) {
                global $post, $wpcom_member;
                extract($attr);
                $sales = 0;
                if(isset($attr['show_sales']) && $show_sales){
                    $sales = WPCOM_Order::get_item_sales('virtual-service', $post->ID.'::'.$id);
                    if(isset($attr['sales_base']) && $sales_base) $sales += $sales_base;
                    $sales = apply_filters('wpcom_virtual_service_sales', $sales, $attr, $post);
                }
                $attr['sales'] = $sales;
                $attr['type'] = isset($attr['type']) ? $attr['type'] : '0';
                $output = $wpcom_member->load_template('virtual-service', $attr);
                return '<div class="wp-block-wpcom-virtual-service">' . $output . '</div>';
            }
        ));
    }

    public function sales_html($html, $sales){
        global $wpmx_options;
        if(isset($wpmx_options['virtual_sales_text']) && trim($wpmx_options['virtual_sales_text'])){
            $html = wpmx_icon('huo', 0) . str_replace('%SALES%', '<span>'.$sales.'</span>', trim($wpmx_options['virtual_sales_text']));
        }
        return $html;
    }

    public function order_item_url($url, $item){
        if($item && isset($item->type) && $item->type === 'virtual-service' && $item->type_id && $ids = explode('::', $item->type_id)){
            $post_id = $ids[0];
            $block_id = $ids[1];
            if ($post_id && $post = get_post($post_id)) {
                $url = get_permalink($post->ID);
                if($block_id) $url .= '#' . $block_id;
            }
        }
        return $url;
    }

    public function show_in_order($item) {
        if ($item->type_id && $ids = explode('::', $item->type_id)) {
            $post_id = $ids[0];
            $block_id = $ids[1];
            $data = $item->data ? json_decode($item->data) : '';
            if ($post_id && $post = get_post($post_id)) { ?>
                <ul class="member-account-order">
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">关联文章：</div>
                        <div class="member-account-order-value"><?php echo get_the_title($post->ID); ?></div>
                    </li>
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">购买服务：</div>
                        <div class="member-account-order-value"><?php echo $item->title;?></div>
                    </li>
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">服务链接：</div>
                        <div class="member-account-order-value">
                            <a class="btn btn-primary btn-xs" href="<?php echo esc_url(get_permalink($post->ID)); ?>#<?php echo $block_id;?>" target="_blank">点击查看</a>
                        </div>
                    </li>
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">订单说明：</div>
                        <div class="member-account-order-value">
                            <?php echo $data && isset($data->paid_desc) && $data->paid_desc ? wp_kses_post(wpautop($data->paid_desc)) : '/';?>
                        </div>
                    </li>
                </ul>
            <?php }
        }
    }

    public function virtual_service_data($return = false) {
        $res = array('result' => 0);
        if (WPCOM_MP_can_setup_order()) {
            $post_id = isset($_POST['post_id']) ? sanitize_text_field($_POST['post_id']) : '';
            $id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
            if ($post_id && $id) {
                $block = $this->get_block($post_id, $id);
                if ($block && isset($block['attrs'])) {
                    $post = get_post($post_id);
                    $price = isset($block['attrs']['price']) && $block['attrs']['price'] ? $block['attrs']['price'] : 0;
                    $items = array(
                        array(
                            'title' => isset($block['attrs']['title']) && $block['attrs']['title'] ? $block['attrs']['title'] : '文章【' . $post->post_title . '】的虚拟服务',
                            'price' => number_format($price, 2, '.', ''),
                            'url' => get_permalink($post_id),
                            'number' => 1,
                            'set_number' => 1,
                            'type' => 'virtual-service',
                            'type_id' => $post_id . '::' . $id,
                            'data' => array(
                                'paid_desc' => isset($block['attrs']['paid_desc']) ? $block['attrs']['paid_desc'] : ''
                            )
                        )
                    );
                    $res['total'] = number_format($price, 2, '.', '');
                    $res['items'] = $items;
                    $res = WPCOM_Order::setup_order_data($res);
                } else {
                    $res['result'] = -3;
                }
            } else {
                $res['result'] = -2;
            }
        } else { // 未登录
            $res['result'] = -1;
        }
        if($return) return $res;
        wp_send_json($res);
    }

    private function get_block($post_id, $id) {
        $post = get_post($post_id);
        $blocks = parse_blocks($post->post_content);
        $block = WPCOM_MP_loop_find_block($blocks, $id, 'wpcom/virtual-service');

        // 检查是否来自自定义页
        if(!$block && class_exists('WPCOM_Module')){
            $template = get_post_meta($post->ID, '_wp_page_template', true);
            if($template === 'page-home.php'){
                $block = WPCOM_MP_get_module_block($id, 'wpcom/virtual-service', $post_id);
            }
        }
        return $block;
    }

    public function for_rest_api(){
        register_rest_route('wpcom/v1', '/virtual-service', array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array($this, 'rest_create_order'),
                'args'                => $this->rest_init_order_params(),
                'permission_callback' => array( $this, 'rest_permission_check' )
            )
        ));
    }

    function rest_init_order_params(){
        return array(
            'post_id' => array(
                'required'          => true,
                'default'           => 0,
                'type'              => 'integer',
                'validate_callback' => 'rest_validate_request_arg',
            ),
            'block_id' => array(
                'required'          => true,
                'default'           => '',
                'type'              => 'string',
                'validate_callback' => 'rest_validate_request_arg',
            )
        );
    }

    function rest_create_order($request){
        $_POST = $_POST ?: array();
        $_POST['post_id'] = $request['post_id'];
        $_POST['id'] = $request['block_id'];
        $data = $this->virtual_service_data(true);
        $data['nonce'] = wp_create_nonce('wpcom_payment_form');
        return rest_ensure_response( $data );
    }

    function rest_permission_check(){
        if ( get_current_user_id() ) {
            return true;
        } else {
            return new WP_Error( 'rest_user_cannot_view', '请登录后操作！', array( 'status' => 200 ) );
        }
    }
}

new WPCOM_Virtual_Service();
