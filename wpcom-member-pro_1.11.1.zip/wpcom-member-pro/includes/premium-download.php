<?php defined('ABSPATH') || exit;

class WPCOM_Premium_Download {
    function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_ajax_wpcom_get_premium_download', array($this, 'premium_download'));
        add_action('wp_ajax_nopriv_wpcom_get_premium_download', array($this, 'premium_download'));
        add_action('wp_ajax_wpcom_get_hidden_download', array($this, 'hidden_download'));
        add_action('wp_ajax_nopriv_wpcom_get_hidden_download', array($this, 'hidden_download'));
        add_action('set_comment_cookies', array( $this, 'set_comment_cookies'));

        add_action( 'load-post.php', array( $this, 'post_script') );
        add_action( 'load-post-new.php', array( $this, 'post_script') );

        add_action('wp_ajax_wpcom_get_premium_download_data', array($this, 'premium_download_data'));
        add_action('wp_ajax_nopriv_wpcom_get_premium_download_data', array($this, 'premium_download_data'));

        add_action('wpcom_order_item_detail_premium-download', array($this, 'show_in_order'));
        add_filter('wpcom_order_item_url', array($this, 'order_item_url'), 10, 2);

        add_filter('the_content', array($this, 'add_download_box'));

        if(defined('WWA_VERSION')){
            add_action('rest_api_init', array($this, 'for_rest_api') );
        }
    }

    public function init() {
        register_block_type('wpcom/premium-download', array(
            'render_callback' => function ($attr, $content) {
                global $wpcom_member;
                if(!isset($attr['title']) || trim($attr['title']) === ''){
                    $attr['title'] = get_the_title();
                }
                $output = $wpcom_member->load_template('premium-download', $attr);
                return '<div class="wp-block-wpcom-premium-download">' . $output . '</div>';
            }
        ));
        register_block_type('wpcom/hidden-download', array(
            'render_callback' => function ($attr, $content) {
                global $wpcom_member;
                if(!isset($attr['title']) || trim($attr['title']) === ''){
                    $attr['title'] = get_the_title();
                }
                $output = $wpcom_member->load_template('hidden-download', $attr);
                return '<div class="wp-block-wpcom-hidden-download">' . $output . '</div>';
            }
        ));
    }

    function post_script(){
        add_action('admin_print_footer_scripts', array($this, 'post_script_handle'), 20);
    }

    function post_script_handle(){ ?>
        <script>
            jQuery(function ($){
                const $body = $(document.body);
                $body.off('ready.dl_args', '#wpcom-metas, #wpcom-plugin-metas').on('ready.dl_args', '#wpcom-metas, #wpcom-plugin-metas', function (){
                    let $label = $('[for="wpcom_dl_args"]').closest('.form-group');
                    $('#wpcom_dl_args_tpl').trigger('change', ['']);
                    if($label.length && $label.find('.repeat-wrap').length){
                        setTimeout(function(){$('#wpcom_dl_args_tpl').trigger('change', ['0']);}, 0);
                    }
                    $body.off('delRepeat.dl_args', '.wpcom-panel-repeat').on('delRepeat.dl_args', '.wpcom-panel-repeat', function (){
                        $label = $('[for="wpcom_dl_args"]').closest('.form-group');
                        if($label.find('.repeat-wrap').length === 0){
                            $('#wpcom_dl_args_tpl').trigger('change', ['']);
                        }
                    });

                    $body.off('change.dl_args', '[name="_wpcom_dl_args_tpl"]').on('change.dl_args', '[name="_wpcom_dl_args_tpl"]', function (){
                        let val = $(this).val();
                        $label = $('[for="wpcom_dl_args"]').closest('.form-group');
                        if(val && val !== '0'){
                            if(window._themer_options && window._themer_options['wpmx_options'] && window._themer_options['wpmx_options']['dl_tpl_id']){
                                let index  = window._themer_options['wpmx_options']['dl_tpl_id'].indexOf(val);
                                $label.find('.wpcom-panel-repeat').trigger('repeat', [{
                                    dl_args_l: window._themer_options['wpmx_options']['dl_tpl_key'][index],
                                    dl_args_v: window._themer_options['wpmx_options']['dl_tpl_val'][index]
                                }]);
                            }
                        }
                    })
                });
            });
        </script>
    <?php }

    public function set_comment_cookies($comment){
        if($comment->comment_author_email){
            $comment_cookie_lifetime = time() + (int)apply_filters( 'comment_cookie_lifetime', 30000000 );
            $secure = ( 'https' === parse_url( home_url(), PHP_URL_SCHEME ) );
            setcookie( 'wpcom_comment_author_email_' . COOKIEHASH, $comment->comment_author_email, $comment_cookie_lifetime, COOKIEPATH, COOKIE_DOMAIN, $secure );
        }
    }

    public function add_download_box($content){
        global $post;
        if ( (is_singular() && in_the_loop() && is_main_query()) || $this->is_rest_content() ) {
            $block = $this->generate_download_block($post);
            if($block) $content .= render_block($block);
        }
        return $content;
    }

    private function is_rest_content(){
        if(function_exists('WWA_is_rest') && WWA_is_rest()){
            $current_url = wp_parse_url( add_query_arg( array( ) ) );
            if($current_url['path'] && preg_match('/\/posts\/\d+$/i', $current_url['path'])){
                return true;
            }
            if(isset($current_url['query']) && $current_url['query']){
                $str = urldecode($current_url['query']);
                return preg_match('/\/posts\/\d+/i', $str);
            }
        }
    }

    public function premium_download() {
        $post_id = isset($_POST['post_id']) ? sanitize_text_field($_POST['post_id']) : 0;
        $res = $this->get_premium_download($post_id);
        wp_send_json($res);
    }

    public function hidden_download(){
        $post_id = isset($_POST['post_id']) ? sanitize_text_field($_POST['post_id']) : 0;
        $password = isset($_POST['password']) ? (string)$_POST['password'] : '';
        $id = $password && isset($_POST['id']) ? $_POST['id'] : '';
        $res = $this->get_hidden_download($post_id, $password, $id);
        wp_send_json($res);
    }

    function get_premium_download($post_id){
        global $post;
        $res = array();
        if($post_id && $post = get_post($post_id)){
            if(isset($post->ID)){
                $blocks = $this->get_premium_download_blocks($post);
                if($blocks && is_array($blocks)){
                    foreach ($blocks as $block){
                        if(isset($block['attrs']) && (isset($block['attrs']['price']) || isset($block['attrs']['vip_price']) || (isset($block['attrs']['vip']) && $block['attrs']['vip']) ) && isset($block['attrs']['id']) && $block['attrs']['id']){
                            $content_id = $post->ID . '::' . $block['attrs']['id'];
                            $order_id = WPCOM_Order::is_admin_free($post->ID);
                            if(!$order_id){
                                $vip_price = isset($block['attrs']['vip_price']) ? $block['attrs']['vip_price'] : array();
                                $price = isset($block['attrs']['vip']) && $block['attrs']['vip'] ? 0 : $block['attrs']['price'];
                                $order_id = WPCOM_VIP::is_vip_free($price, $vip_price, 'download') && WPCOM_VIP::is_vip_visable('premium-download/'.$content_id);
                            }
                            if(!$order_id) $order_id = WPCOM_Order::is_item_paid('premium-download', $content_id);
                            if($order_id && $block['attrs']['files']){
                                $res[$block['attrs']['id']] = $this->get_download_url($block['attrs']['files']);
                            }
                        }
                    }
                }
            }
        }
        return $res;
    }

    function get_hidden_download($post_id, $password='', $id=''){
        global $post, $current_user;
        $res = array();
        if($post_id && $post = get_post($post_id)){
            if(isset($post->ID)){
                $blocks = $this->get_premium_download_blocks($post, 'hidden');
                if($blocks && is_array($blocks)){
                    foreach ($blocks as $block){
                        $show = 0;
                        if(isset($block['attrs']) && isset($block['attrs']['type']) && isset($block['attrs']['id']) && $block['attrs']['id']){
                            switch ($block['attrs']['type']){
                                case '0': // 回复
                                    $show = $this->is_comment();
                                    break;
                                case '1': // 登录
                                    $show = $current_user && isset($current_user->ID) && $current_user->ID;
                                    break;
                                case '2': // 用户组
                                    $show = $this->is_group($block);
                                    break;
                                case '3': // 口令
                                    if($password && $id && isset($block['attrs']['password']) && $block['attrs']['password'] === $password && $block['attrs']['id'] === $id){
                                        WPCOM_Session::set($post->ID . '_' . $block['attrs']['id'], 1);
                                        $show = 1;
                                    }else if(isset($block['attrs']['id']) && WPCOM_Session::get($post->ID . '_' . $block['attrs']['id']) == 1){
                                        $show = 1;
                                    }
                                    break;
                                case '-1': // 无需权限
                                    $show = 1;
                                    break;
                            }
                            if(isset($show) && $show && $block['attrs']['files']) {
                                $res[$block['attrs']['id']] = $this->get_download_url($block['attrs']['files']);
                            }
                        }
                    }
                }
            }
        }
        return $res;
    }

    function is_comment(){
        global $post, $current_user;
        $show = 0;
        if($current_user && isset($current_user->ID) && $current_user->ID){
            $c_args = array(
                'post_id' => $post->ID,
                'user_id' => $current_user->ID,
                'count'   => true
            );
            if($post && $post->post_type === 'qa_post') $c_args['type'] = 'answer';
            $show = get_comments( $c_args );
        }else if(isset($_COOKIE['wpcom_comment_author_email_' . COOKIEHASH])){
            $email = urldecode($_COOKIE['wpcom_comment_author_email_' . COOKIEHASH]);
            if($email){
                $c_args = array(
                    'post_id' => $post->ID,
                    'author_email' => $email,
                    'count'   => true
                );
                if($post && $post->post_type === 'qa_post') $c_args['type'] = 'answer';
                $show = get_comments( $c_args );
            }
        }
        if($show) return true;
        return false;
    }

    function is_group($block){
        global $current_user;
        if($current_user && isset($current_user->ID) && $current_user->ID && isset($block['attrs']['user_group']) && is_array($block['attrs']['user_group'])){
            $group = wpcom_get_user_group($current_user->ID);
            if($group && in_array($group->term_id, $block['attrs']['user_group']) ){
                return true;
            }
        }
        return false;
    }

    function get_premium_download_blocks($post, $type='premium'){
        $blocks = parse_blocks($post->post_content);
        $res = $this->loop_blocks($blocks, $type);
        if((empty($blocks) || empty($res)) && class_exists('WPCOM_Module')){
            $template = get_post_meta($post->ID, '_wp_page_template', true);
            if($template === 'page-home.php'){
                $blocks = WPCOM_MP_get_gutenberg_blocks($post->ID);
                if($blocks && !empty($blocks)) $res = $this->loop_blocks($blocks, $type);
            }
        }
        $block = $this->generate_download_block($post);
        if($block) $res[] = $block;
        return $res;
    }

    public static function generate_download_block($post){
        $view_type = get_post_meta($post->ID, 'wpcom_view_type', true);
        if($view_type === '2'){
            $type = get_post_meta($post->ID, 'wpcom_unlock_type', true);
            $title = get_post_meta($post->ID, 'wpcom_dl_title', true);
            $image = get_post_meta($post->ID, 'wpcom_dl_image', true);
            $btn = $type === '3' ? get_post_meta($post->ID, 'wpcom_dl_btn', true) : '';
            $files_url = get_post_meta($post->ID, 'wpcom_dl_file_url', true);
            $files_title = get_post_meta($post->ID, 'wpcom_dl_file_title', true);
            $files_code = get_post_meta($post->ID, 'wpcom_dl_file_code', true);
            $files = array();
            if(!empty($files_url)){
                foreach($files_url as $i => $url){
                    $files[] = array(
                        'url' => $url,
                        'title' => isset($files_title[$i]) ? $files_title[$i] : '',
                        'code' => isset($files_code[$i]) ? $files_code[$i] : '',
                    );
                }
            }
            $dl_args_l = get_post_meta($post->ID, 'wpcom_dl_args_l', true);
            $dl_args_v = get_post_meta($post->ID, 'wpcom_dl_args_v', true);
            $dl_args = array();
            if(!empty($dl_args_l)){
                foreach($dl_args_l as $x => $l){
                    $dl_args[] = array(
                        'label' => $l,
                        'value' => isset($dl_args_v[$x]) ? $dl_args_v[$x] : ''
                    );
                }
            }
            if($type === '3' || $type === '5'){
                $blockName = 'premium-download';
                $vip_types = WPCOM_VIP::get_vip_types();
                $vip_price = array();
                if(!empty($vip_types)){
                    foreach($vip_types as $_type){
                        $id = $_type['id'];
                        $vip_price[$id.'_price'] = get_post_meta($post->ID, 'wpcom_'.$id.'_price', true);
                    }
                }
                $attrs = array(
                    'id' => 'post-'.$blockName.'-'.$post->ID,
                    'title' => $title,
                    'image' => $image ? wp_get_attachment_url($image) : '',
                    'price' => $type === '3' ? get_post_meta($post->ID, 'wpcom_unlock_price', true) : 0,
                    'vip_price' => $vip_price,
                    'files' => $files,
                    'args' => $dl_args,
                    'btn' => $btn ?: '',
                    'sales_base' => (int)get_post_meta($post->ID, 'wpcom_unlock_sales_base', true)
                );
                if($type === '5') $attrs['vip'] = true;
            }else{
                $blockName = 'hidden-download';
                $type = $type === '4' ? '3' : $type;
                $btn = '';
                switch($type){
                    case '0':
                        $btn = '回复后下载';
                        break;
                    case '1':
                        $btn = '登录后下载';
                        break;
                }
                $user_group = get_post_meta($post->ID, 'wpcom_unlock_groups', true);
                $attrs = array(
                    'id' => 'post-'.$blockName.'-'.$post->ID,
                    'title' => $title,
                    'image' => $image ? wp_get_attachment_url($image) : '',
                    'files' => $files,
                    'args' => $dl_args,
                    'user_group' => $user_group,
                    'type' => $type,
                );
                if($type === '3') $attrs['password'] = get_post_meta($post->ID, 'wpcom_unlock_password', true);
            }

            return array(
                'blockName' => 'wpcom/' . $blockName,
                'attrs' => $attrs,
                'innerBlocks' => array(),
                'innerHTML' => '',
                'innerContent' => array()
            );
        }
    }

    function get_download_url($str){
        if(is_array($str) && isset($str[0]) && isset($str[0]['url'])) return $str;
        $res = array();
        $urls = explode(PHP_EOL, $str);
        if($urls){
            foreach($urls as $url){
                if($url && $_url = explode('||', $url)){
                    if(count($_url) >= 3){
                        $res[] = array(
                            'title' => trim($_url[0]),
                            'url' => trim($_url[1]),
                            'code' => trim($_url[2])
                        );
                    }else if(count($_url) === 1){
                        $res[] = array(
                            'url' => is_numeric(trim($_url[0])) ? wp_get_attachment_url(trim($_url[0])) : trim($_url[0]),
                        );
                    }else{
                        if(is_numeric(trim($_url[0])) || preg_match('/^(http:\/\/|https:\/\/|ftp:\/\/|\/\/)/i', trim($_url[0]))){
                            $res[] = array(
                                'url' => is_numeric(trim($_url[0])) ? wp_get_attachment_url(trim($_url[0])) : trim($_url[0]),
                                'code' => trim($_url[1])
                            );
                        }else{
                            $res[] = array(
                                'title' => trim($_url[0]),
                                'url' => is_numeric(trim($_url[1])) ? wp_get_attachment_url(trim($_url[1])) : trim($_url[1])
                            );
                        }
                    }
                }
            }
        }
        return $res;
    }

    public static function get_arg_value($value, $attr){
        global $post;
        if(preg_match('%PRICE%', $value)) {
            $_price = 0;
            // VIP专属则获取最低等级会员价格
            if(isset($attr['vip']) && $attr['vip'] && !empty($attr['vip_price'])){
                $prices = WPCOM_VIP::get_vip_price(0, $attr['vip_price'], 'download');
                if(!empty($prices) && is_array($prices)){
                    $first = array_shift($prices);
                    $_price = $first['price'];
                }
            }else{
                $_price = isset($attr['price']) && $attr['price'] ? $attr['price'] : 0;
            }
            $value = str_replace('%PRICE%', '<span class="premium-download-price">¥'.number_format($_price, 2, '.', '').'</span>', $value);
        }
        if(preg_match('%SALES%', $value)) {
            $sales = WPCOM_Order::get_item_sales('premium-download', $post->ID.'::'.$attr['id']);
            if(isset($attr['sales_base']) && $attr['sales_base']) $sales += (int)$attr['sales_base'];
            $sales = apply_filters('wpcom_premium_content_sales', $sales, $attr, $post);
            $sales = $sales ?: 0;
            $value = str_replace('%SALES%', '<span class="premium-download-sales">'.wpmx_icon('huo', 0).$sales.'</span>', $value);
        }
        if(preg_match('%PUBLISH_TIME%', $value)) {
            $value = str_replace('%PUBLISH_TIME%', date_i18n(get_option('date_format'), strtotime($post->post_date)), $value);
        }
        if(preg_match('%MODIFIED_TIME%', $value)) {
            $value = str_replace('%MODIFIED_TIME%', date_i18n(get_option('date_format'), strtotime($post->post_modified)), $value);
        }
        if(preg_match('/^\[(.+)\]\((.+)\)$/', $value, $m)) {
            $value = preg_replace('/^\[(.+)\]\((.+)\)$/', '<a href="${2}" target="_blank" rel="nofollow">${1}</a>', $value);
        }
        return $value;
    }

    public function order_item_url($url, $item){
        if($item && isset($item->type) && $item->type === 'premium-download' && $item->type_id && $ids = explode('::', $item->type_id)){
            $post_id = $ids[0];
            $block_id = $ids[1];
            if ($post_id && $post = get_post($post_id)) {
                $url = get_permalink($post->ID);
                if($block_id) $url .= '#' . $block_id;
            }
        }
        return $url;
    }

    public function show_in_order($item) {
        if ($item->type_id && $ids = explode('::', $item->type_id)) {
            $post_id = $ids[0];
            $block_id = $ids[1];
            if ($post_id && $post = get_post($post_id)) { ?>
                <ul class="member-account-order">
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">关联文章：</div>
                        <div class="member-account-order-value"><?php echo get_the_title($post->ID); ?></div>
                    </li>
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">付费资源：</div>
                        <div class="member-account-order-value"><?php echo $item->title;?></div>
                    </li>
                    <li class="member-account-order-item">
                        <div class="member-account-order-label">内容链接：</div>
                        <div class="member-account-order-value">
                            <a class="btn btn-primary btn-xs" href="<?php echo esc_url(get_permalink($post->ID)); ?>#<?php echo $block_id;?>" target="_blank">点击查看</a>
                        </div>
                    </li>
                </ul>
            <?php }
        }
    }

    public function premium_download_data($return = false) {
        $res = array('result' => 0);
        if (WPCOM_MP_can_setup_order()) {
            $post_id = isset($_POST['post_id']) ? sanitize_text_field($_POST['post_id']) : '';
            $id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
            if ($post_id && $id) {
                $block = $this->get_block($post_id, $id);
                if ($block && isset($block['attrs'])) {
                    $post = get_post($post_id);
                    $user_id = get_current_user_id();
                    $_price = isset($block['attrs']['price']) && $block['attrs']['price'] ? $block['attrs']['price'] : 0;
                    // VIP专属默认价格为0
                    $_price = isset($block['attrs']['vip']) && $block['attrs']['vip'] ? 0 : $_price;
                    $_vip_price = isset($block['attrs']['vip_price']) && $block['attrs']['vip_price'] ? $block['attrs']['vip_price'] : array();
                    $price = WPCOM_VIP::get_vip_price_by_user($user_id, $_price, $_vip_price, 'download');
                    $items = array(
                        array(
                            'title' => isset($block['attrs']['title']) && $block['attrs']['title'] ? $block['attrs']['title'] : '文章【' . $post->post_title . '】的付费资源',
                            'price' => number_format($price, 2, '.', ''),
                            'url' => get_permalink($post_id),
                            'number' => 1,
                            'type' => 'premium-download',
                            'type_id' => $post_id . '::' . $id
                        )
                    );
                    $res['total'] = number_format($price, 2, '.', '');
                    $res['items'] = $items;
                    $res = WPCOM_Order::setup_order_data($res);
                    if($price == 0 && $vip = WPCOM_VIP::get_user_vip($user_id)){ // VIP资源提示解锁
                        $res['result'] = -9;
                        $res['type'] = 'premium-download';
                        $res['type_text'] = '资源';
                        $res['vip'] = array(
                            'id' => $vip['id'],
                            'icon' => $vip['icon'],
                            'title' => $vip['title'],
                            'upgrade' => WPCOM_VIP::vip_can_upgrade($vip)
                        );
                        $res['unlock_times'] = WPCOM_VIP::get_vip_unlock_times($user_id);
                    }
                } else {
                    $res['result'] = -3;
                }
            } else {
                $res['result'] = -2;
            }
        } else { // 未登录
            $res['result'] = -1;
        }
        if($return) return $res;
        wp_send_json($res);
    }

    private function get_block($post_id, $id) {
        $post = get_post($post_id);
        $blocks = parse_blocks($post->post_content);
        if(preg_match('/^post-premium-download-'.$post_id.'$/i', $id)){
            return $this->generate_download_block($post);
        }
        $block = WPCOM_MP_loop_find_block($blocks, $id, 'wpcom/premium-download');
        // 检查是否来自自定义页
        if(!$block && class_exists('WPCOM_Module')){
            $template = get_post_meta($post->ID, '_wp_page_template', true);
            if($template === 'page-home.php'){
                $block = WPCOM_MP_get_module_block($id, 'wpcom/premium-download', $post_id);
            }
        }
        return $block;
    }

    function loop_blocks($blocks, $type='premium'){
        $res = array();
        if($blocks){
            foreach ($blocks as $block){
                if($block['blockName'] === 'wpcom/'.$type.'-download'){
                    $res[] = $block;
                }else if(isset($block['innerBlocks']) && $block['innerBlocks']){
                    $childs = $this->loop_blocks($block['innerBlocks'], $type);
                    if($childs) $res = array_merge($res, $childs);
                }
            }
        }
        return $res;
    }

    public function for_rest_api(){
        register_rest_route('wpcom/v1', '/premium-download', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array($this, 'rest_get_download'),
                'args'                => $this->rest_get_read_params(),
                'permission_callback' => array( $this, 'rest_permission_check' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array($this, 'rest_create_order'),
                'args'                => $this->rest_init_order_params(),
                'permission_callback' => array( $this, 'rest_permission_check' )
            )
        ));
        register_rest_route('wpcom/v1', '/hidden-download', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array($this, 'rest_get_hidden_download'),
                'args'                => $this->rest_get_read_params(),
                'permission_callback' => array( $this, 'no_check' )
            )
        ));
    }

    function rest_get_read_params(){
        return array(
            'post_id' => array(
                'required'          => true,
                'default'           => 0,
                'type'              => 'integer',
                'validate_callback' => 'rest_validate_request_arg',
            ),
            'password' => array(
                'required'          => false,
                'default'           => '',
                'type'              => 'string'
            ),
            'id' => array(
                'required'          => false,
                'default'           => '',
                'type'              => 'string'
            )
        );
    }

    function rest_init_order_params(){
        return array(
            'post_id' => array(
                'required'          => true,
                'default'           => 0,
                'type'              => 'integer',
                'validate_callback' => 'rest_validate_request_arg',
            ),
            'block_id' => array(
                'required'          => true,
                'default'           => '',
                'type'              => 'string',
                'validate_callback' => 'rest_validate_request_arg',
            )
        );
    }

    function rest_get_download($request){
        $res = $this->get_premium_download($request['post_id']);
        return rest_ensure_response( $res );
    }

    function rest_get_hidden_download($request){
        $res = $this->get_hidden_download($request['post_id'], $request['password'], $request['id']);
        return rest_ensure_response( $res );
    }

    function rest_create_order($request){
        $_POST = $_POST ?: array();
        $_POST['post_id'] = $request['post_id'];
        $_POST['id'] = $request['block_id'];
        $data = $this->premium_download_data(true);
        $data['nonce'] = wp_create_nonce('wpcom_payment_form');
        return rest_ensure_response( $data );
    }

    function rest_permission_check(){
        if ( get_current_user_id() ) {
            return true;
        } else {
            return new WP_Error( 'rest_user_cannot_view', '请登录后操作！', array( 'status' => 200 ) );
        }
    }

    function no_check(){
        return true;
    }
}

new WPCOM_Premium_Download();
