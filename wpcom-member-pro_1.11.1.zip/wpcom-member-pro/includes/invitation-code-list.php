<?php
defined('ABSPATH') || exit;

if ( ! class_exists( 'WP_List_Table' ) ) require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
if ( ! class_exists( 'WPCOM_Invitation_Code_List' ) ) :
    class WPCOM_Invitation_Code_List extends WP_List_Table {
        protected $table;
        public function __construct(){
            global $wpdb;
            $this->table = $wpdb->prefix . 'wpcom_invitcodes';
            parent::__construct([
                'screen' => 'invitcodes'
            ]);
        }

        public function ajax_user_can() {
            return current_user_can( 'manage_options' );
        }

        public function prepare_items() {
            global $wpdb, $orderby, $order;
            wp_reset_vars( array( 'orderby', 'order' ) );

            $this->process_bulk_action();

            $orderby = $orderby ?: 'ID';
            $order = $order ?: 'DESC';

            $paged = $this->get_pagenum();
            $offset = ($paged-1) * 50;

            $search = isset( $_REQUEST['s'] ) ? wp_unslash( trim( $_REQUEST['s'] ) ) : '';

            $search_sql = $search ? "WHERE code LIKE '%$search%' OR users LIKE '%$search%'" : '';
            $results = $wpdb->get_results( "SELECT * FROM $this->table $search_sql ORDER BY $orderby $order limit $offset, 50" );
            $total = $wpdb->get_var( "SELECT count(*) FROM $this->table $search_sql" );

            $this->set_pagination_args( [
                'total_items' => $total,
                'per_page'    => 50
            ] );
            $this->items = $results;
        }

        function get_columns(){
            $columns = array(
                'cb' => '<input type="checkbox" />',
                'code' => '邀请码',
                'times' => '可用次数',
                'users' => '注册用户',
                'expired' => '过期时间',
                'status' => '状态'
            );
            return $columns;
        }

        public function process_bulk_action() {
            global $wpdb;
            if ( 'delete-code' === $this->current_action() ) {
                $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                if ( wp_verify_nonce( $nonce, 'bulk-invitcodes' ) ) {
                    $ids = isset($_REQUEST['check']) ? $_REQUEST['check'] : array();
                    if(!empty($ids)) {
                        $ids = implode( ',', array_map( 'absint', $ids ) );
                        $wpdb->query("DELETE FROM $this->table WHERE ID IN($ids)");
                    }
                }else if(isset($_GET['id']) && $_GET['id']){
                    $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                    if ( wp_verify_nonce( $nonce, 'delete-code_'.$_GET['id'] ) ) {
                        $wpdb->delete($this->table, array('ID' => $_GET['id']));
                    }
                }
            }
        }

        protected function get_bulk_actions() {
            $actions           = array();
            $actions['delete-code'] = __( 'Delete' );
            return $actions;
        }
        protected function get_sortable_columns() {
            return array(
                'code' => 'code',
                'times' => 'times',
                'expired' => 'expired',
                'status' => 'status',
            );
        }
        protected function get_default_primary_column_name() {
            return 'ID';
        }
        public function column_cb( $code ) { ?>
            <label class="screen-reader-text" for="cb-select-<?php echo $code->ID; ?>"> </label>
            <input type="checkbox" name="check[]" id="cb-select-<?php echo $code->ID; ?>" value="<?php echo esc_attr( $code->ID ); ?>" />
            <?php
        }
        public function column_code( $code ) {
            echo $code->code;
        }
        public function column_times( $code ) {
            $count = 0;
            if($code->users && $users = maybe_unserialize($code->users)){
                if(is_array($users)) $count = count($users);
            }
            echo $count . '/' . $code->times;
        }
        public function column_users( $code ) {
            if($code->users){
                $users = maybe_unserialize($code->users);
                $res = '';
                if(is_array($users)){
                    foreach($users as $uid){
                        $_user = get_user_by('ID', $uid);
                        if($res) $res .= '、';
                        if($_user && isset($_user->ID)){
                            $res .= '<a href="'.esc_url(get_edit_user_link($_user->ID)).'" target="_blabk">'.wp_kses_post($_user->display_name).'</a>';
                        }else{
                            $res .= $uid;
                        }
                    }
                }
                echo $res;
            }
        }
        public function column_expired( $code ) {
            echo $code->expired && $code->expired != '0000-00-00 00:00:00' ? $code->expired : '不过期';
        }
        public function column_status( $code ) {
            $status = array(
                '-1' => '禁用',
                '0' => '可用',
                '1' => '已使用',
                '2' => '过期'
            );
            if($code->status == '0' && $code->expired && $code->expired != '0000-00-00 00:00:00' ){ // 过期
                $date = new DateTime($code->expired, wp_timezone());
                $expired = $date->format('U');
                if($expired < time()) $code->status = 2;
            }
            echo $code->status !== '' && isset($status[$code->status]) ? '<span class="status-'.esc_attr($code->status).'">' . $status[$code->status] . '</span>' : '';
        }
        protected function handle_row_actions( $code, $column_name, $primary ) {
            if ( $primary !== $column_name ) return '';

            $actions           = array();
            $actions['edit'] = sprintf(
                '<a href="%s">%s</a>',
                admin_url( "admin.php?page=wpcom-edit-code&id=$code->ID" ),
                __('Edit')
            );
            $actions['delete'] = sprintf(
                '<a class="submitdelete" href="%s" onclick="return confirm( \'%s\' );">%s</a>',
                wp_nonce_url( "?page=wpcom-invitation-code&action=delete-code&id=$code->ID", 'delete-code_' . $code->ID ),
                esc_js( sprintf( '删除操作确定后不可撤回，请问是否确定要删除呢？', $code->ID ) ),
                __( 'Delete' )
            );

            return $this->row_actions( $actions );
        }
    }
endif;