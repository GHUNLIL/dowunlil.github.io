<?php
defined('ABSPATH') || exit;

if ( ! class_exists( 'WP_List_Table' ) ) require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
if ( ! class_exists( 'WPCOM_Vouchers_List' ) ) :
    class WPCOM_Vouchers_List extends WP_List_Table {
        protected $table;
        public function __construct(){
            global $wpdb;
            $this->table = $wpdb->prefix . 'wpcom_vouchers';
            parent::__construct([
                'screen' => 'vouchers'
            ]);
        }

        public function ajax_user_can() {
            return current_user_can( 'manage_options' );
        }

        public function prepare_items() {
            global $wpdb, $orderby, $order;
            wp_reset_vars( array( 'orderby', 'order' ) );

            $this->process_bulk_action();

            $orderby = $orderby ?: 'ID';
            $order = $order ?: 'DESC';

            $paged = $this->get_pagenum();
            $offset = ($paged-1) * 50;

            $search = isset( $_REQUEST['s'] ) ? wp_unslash( trim( $_REQUEST['s'] ) ) : '';

            $search_sql = $search ? "WHERE voucher LIKE '%$search%' OR value LIKE '%$search%' OR note LIKE '%$search%'" : '';
            $results = $wpdb->get_results( "SELECT * FROM $this->table $search_sql ORDER BY $orderby $order limit $offset, 50" );
            $total = $wpdb->get_var( "SELECT count(*) FROM $this->table $search_sql" );

            $this->set_pagination_args( [
                'total_items' => $total,
                'per_page'    => 50
            ] );
            $this->items = $results;
        }

        function get_columns(){
            $columns = array(
                'cb' => '<input type="checkbox" />',
                'voucher' => '代金券',
                'value' => '面值',
                'user_id' => '兑换用户',
                'time' => '兑换时间',
                'note' => '备注'
            );
            return $columns;
        }

        public function process_bulk_action() {
            global $wpdb;
            if ( 'delete-voucher' === $this->current_action() ) {
                $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                if ( wp_verify_nonce( $nonce, 'bulk-vouchers' ) ) {
                    $ids = isset($_REQUEST['check']) ? $_REQUEST['check'] : array();
                    if(!empty($ids)) {
                        $ids = implode( ',', array_map( 'absint', $ids ) );
                        $wpdb->query("DELETE FROM $this->table WHERE ID IN($ids)");
                    }
                }else if(isset($_GET['id']) && $_GET['id']){
                    $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                    if ( wp_verify_nonce( $nonce, 'delete-voucher_'.$_GET['id'] ) ) {
                        $wpdb->delete($this->table, array('ID' => $_GET['id']));
                    }
                }
            }
        }

        protected function get_bulk_actions() {
            $actions           = array();
            $actions['delete-voucher'] = __( 'Delete' );
            return $actions;
        }
        protected function get_sortable_columns() {
            return array(
                'voucher' => 'voucher',
                'value' => 'value',
                'time' => 'time',
                'user_id' => 'user_id',
            );
        }
        protected function get_default_primary_column_name() {
            return 'ID';
        }
        public function column_cb( $voucher ) { ?>
            <label class="screen-reader-text" for="cb-select-<?php echo $voucher->ID; ?>"> </label>
            <input type="checkbox" name="check[]" id="cb-select-<?php echo $voucher->ID; ?>" value="<?php echo esc_attr( $voucher->ID ); ?>" />
            <?php
        }
        public function column_voucher( $voucher ) {
            echo $voucher->voucher;
        }
        public function column_value( $voucher ) {
            echo '￥' . $voucher->value;
        }
        public function column_user_id( $voucher ) {
            if($voucher->user_id && $voucher->user_id > 0){
                $user = get_user_by('ID', $voucher->user_id);
                if($user && isset($user->ID) && $user->ID){
                    echo '<a href="'.esc_url(get_edit_user_link($user->ID)).'" target="_blabk">'.wp_kses_post($user->display_name).'</a>';
                }else{
                    echo '无效用户：'.$voucher->user_id;
                }
            }else{
                echo '未兑换';
            }
        }
        public function column_time( $voucher ) {
            echo $voucher->time && $voucher->time != '0000-00-00 00:00:00' ? $voucher->time : '-';
        }
        public function column_note( $voucher ) {
            echo $voucher->note ? $voucher->note : '';
        }
        protected function handle_row_actions( $voucher, $column_name, $primary ) {
            if ( $primary !== $column_name ) return '';

            $actions           = array();
            $actions['edit'] = sprintf(
                '<a href="%s">%s</a>',
                admin_url( "admin.php?page=wpcom-edit-voucher&id=$voucher->ID" ),
                __('Edit')
            );
            $actions['delete'] = sprintf(
                '<a class="submitdelete" href="%s" onclick="return confirm( \'%s\' );">%s</a>',
                wp_nonce_url( "?page=wpcom-vouchers&action=delete-voucher&id=$voucher->ID", 'delete-voucher_' . $voucher->ID ),
                esc_js( sprintf( '删除操作确定后不可撤回，请问是否确定要删除呢？', $voucher->ID ) ),
                __( 'Delete' )
            );

            return $this->row_actions( $actions );
        }
    }
endif;