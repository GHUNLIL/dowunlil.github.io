<?php defined('ABSPATH') || exit;

class WPCOM_Wallet{
    protected static $logs_table = 'wpcom_wallet_logs';
    protected static $vouchers_table = 'wpcom_vouchers';
    function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('wp_ajax_wpcom_recharge_modal', array($this, 'recharge_modal'));
        add_action('wp_ajax_nopriv_wpcom_recharge_modal', array($this, 'recharge_modal'));
        add_action('wp_ajax_wpcom_recharge_data', array($this, 'recharge_data'));
        add_action('wp_ajax_wpcom_recharge_voucher', array($this, 'recharge_voucher'));
        add_action('wp_ajax_wpcom_recharge_byadmin', array($this, 'recharge_byadmin'));
        add_action('wpcom_wallet_payment_complete', array($this, 'payment_complete'), 10, 2);
        add_action('wpcom_order_item_detail_wallet', array($this, 'show_in_order'));
        add_action('admin_print_footer_scripts-users.php', array($this, 'users_page_scripts'));
        add_action('show_user_profile', array($this, 'edit_user_balance' ) );
        add_action('edit_user_profile', array($this, 'edit_user_balance' ) );
        add_action('personal_options_update', array($this, 'save_user_balance' ) );
        add_action('edit_user_profile_update', array($this, 'save_user_balance' ) );
        add_action('load-index.php', function(){ self::init_database(); });

        add_filter('wpcom_account_tabs', array($this, 'account_tabs'));
        add_filter('wpcom_member_vouchers_metas', array($this, 'vouchers_metas'), 1);
        add_filter('wpcom_member_edit_voucher_metas', array($this, 'edit_voucher_metas'), 1);
        add_filter('manage_users_columns', array($this, 'users_columns' ) );
        add_filter('manage_users_custom_column', array($this, 'users_column_value' ), 10, 3 );
        add_filter('manage_users_sortable_columns', array($this ,'users_sortable') );
        add_filter('pre_get_users', array($this, 'filter_users' ) );
        add_filter('user_row_actions', array($this, 'user_row_actions'), 10, 2);
    }

    function admin_menu(){
        global $wpmx_options;
        if(isset($wpmx_options['recharge_types']) && !empty($wpmx_options['recharge_types']) && in_array('t2', $wpmx_options['recharge_types'])){
            add_submenu_page('wpcom-member-pro', '代金券', '代金券', 'manage_options', 'wpcom-vouchers', array(&$this, 'vouchers_list'), 10);
            add_submenu_page('wpcom-vouchers', '生成代金券', '生成代金券', 'manage_options', 'wpcom-add-voucher', array(&$this, 'add_voucher'), 10);
            add_submenu_page('wpcom-vouchers', '编辑代金券', '编辑代金券', 'manage_options', 'wpcom-edit-voucher', array(&$this, 'edit_voucher'), 10);
            add_filter('parent_file', array($this, 'parent_file_filter'));
            add_filter('submenu_file', array($this, 'submenu_file_filter'));
        }
    }

    function account_tabs($tabs){
        $tabs[23] = array(
            'slug' => 'wallet',
            'title' => '我的钱包',
            'icon' => 'wallet',
            'shadow' => 1
        );
        add_action('wpcom_account_tabs_wallet', array($this, 'account_tabs_wallet'));
        return $tabs;
    }

    function account_tabs_wallet(){
        global $wpcom_member, $wpdb;
        $user = wp_get_current_user();
        $balance = get_user_option( '_wpcom_balance', $user->ID );
        $balance = $balance ? $balance : 0;
        $paged = get_query_var('pageid') ? get_query_var('pageid') : 1;
        $table = $wpdb->prefix . self::$logs_table;
        $per_page = 20;
        $total = $wpdb->get_var("SELECT count(*) FROM $table WHERE user_id='$user->ID'");
        $pages = ceil($total / $per_page);
        $atts = array(
            'balance' => $balance,
            'logs' => $this->get_logs($user->ID, $per_page, $paged),
            'pages' => $pages,
            'paged' => $paged
        );
        echo $wpcom_member->load_template('wallet', $atts);
    }

    function recharge_modal(){
        global $wpcom_member, $wpmx_options;
        $res = array('result' => 0);
        $user_id = get_current_user_id();
        if($user_id){
            $args = array(
                'desc' => isset($wpmx_options['recharge_desc']) ? $wpmx_options['recharge_desc'] : '',
                'types' => isset($wpmx_options['recharge_types']) ? $wpmx_options['recharge_types'] : '',
                'voucher_desc' => isset($wpmx_options['voucher_desc']) ? $wpmx_options['voucher_desc'] : '',
                'transfer_desc' => isset($wpmx_options['transfer_desc']) ? $wpmx_options['transfer_desc'] : ''
            );
            $res['tpl'] = $wpcom_member->load_template('recharge-modal', $args);
        }else{
            $res['result'] = -1;
        }
        wp_send_json($res);
    }

    function recharge_data(){
        $res = array('result' => 0);
        $value = isset($_POST['value']) ? sanitize_text_field($_POST['value']) : '';
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';

        if($nonce && wp_verify_nonce($nonce, 'recharge_form_t1')){
            $price = number_format($value, 2, '.', '');
            if ($value && $price && $price > 0) {
                $items = array(
                    array(
                        'title' => '钱包余额充值',
                        'price' => $price,
                        'url' => '',
                        'number' => 1,
                        'type' => 'wallet',
                        'type_id' => ''
                    )
                );
                $res['total'] = $price;
                $res['items'] = $items;
                $res = WPCOM_Order::setup_order_data($res);
            } else {
                $res['result'] = -2;
                $res['msg'] = '充值金额出错，请重新输入';
            }
        }else{
            $res['result'] = -1;
            $res['msg'] = '充值请求失败，请稍后再试';
        }
        wp_send_json($res);
    }

    function payment_complete($item, $order){
        if($order && $order->user && $order->status === 'paid' && isset($item->price) && $item->price){
            $user_id = (int)$order->user;
            $price = (float)$item->price;
            $user = get_user_by('ID', $user_id);
            if($user_id && $user && isset($user->ID) && $price && $price > 0){
                $log_title = '余额充值[在线支付]#' . $order->number;
                $this->use_balance($price, $user->ID, $log_title);
            }
        }
    }

    public function show_in_order($item) {
        if ($item && $item->type === 'wallet') { ?>
            <ul class="member-account-order">
                <li class="member-account-order-item">
                    <div class="member-account-order-label">购买项目：</div>
                    <div class="member-account-order-value">钱包余额充值</div>
                </li>
                <li class="member-account-order-item">
                    <div class="member-account-order-label">充值金额：</div>
                    <div class="member-account-order-value">￥<?php echo number_format($item->price, 2, '.', '');?></div>
                </li>
            </ul>
        <?php }
    }

    public static function use_balance($money, $user_id, $log_title){
        $money = number_format($money, 2, '.', '');
        if(is_numeric($money) && $user_id){
            $balance = (float)get_user_option( '_wpcom_balance', $user_id );
            $balance = $balance && $balance > 0 ? $balance : 0;
            if($balance + $money >= 0){
                $balance = number_format($balance + $money, 2, '.', '');
                $update = update_user_option($user_id, '_wpcom_balance', $balance);
                if($update){
                    $log = array(
                        'user_id' => $user_id,
                        'title' => $log_title,
                        'value' => $money
                    );
                    self::add_wallet_log($log);
                }
                return $update;
            }
        }
    }

    function recharge_voucher(){
        $res = array('result' => 0);
        $value = isset($_POST['value']) ? sanitize_text_field($_POST['value']) : '';
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';

        if($nonce && wp_verify_nonce($nonce, 'recharge_form_t2')){
            $voucher = $this->get_voucher($value);
            if ($voucher && $voucher->ID) {
                if($voucher->user_id && $voucher->user_id > 0){
                    $res['result'] = -3;
                    $res['msg'] = '兑换失败，代金券已被使用';
                }else if($voucher->value && ($voucher->user_id == '' || $voucher->user_id == 0)){
                    $user_id = get_current_user_id();
                    if(!($user_id && $this->use_voucher($voucher->ID, $user_id))){
                        $res['result'] = -5;
                        $res['msg'] = '兑换失败，请稍后再试';
                    }
                }else{
                    $res['result'] = -4;
                    $res['msg'] = '兑换失败，代金券不可用';
                }
            } else {
                $res['result'] = -2;
                $res['msg'] = '兑换失败，请检查券码输入是否正确';
            }
        }else{
            $res['result'] = -1;
            $res['msg'] = '兑换请求失败，请稍后再试';
        }
        wp_send_json($res);
    }

    function use_voucher($voucher_id, $user_id){
        global $wpdb;
        $voucher = $this->get_voucher($voucher_id, 'ID');
        $user = get_user_by('ID', $user_id);
        if($voucher && isset($voucher->ID) && $user && isset($user->ID) && $user->ID){
            $table = $wpdb->prefix . self::$vouchers_table;
            $_voucher = array(
                'user_id' => $user->ID,
                'time' => current_time('mysql')
            );
            $res = $wpdb->update($table, $_voucher, array('ID' => $voucher->ID));
            if($res){
                $log_title = '余额充值[代金券]#' . $voucher->voucher;
                return $this->use_balance($voucher->value, $user->ID, $log_title);
            }
        }
    }

    public static function get_recharge_type($type){
        $types = array(
            't1' => array(
                'title' => '在线支付',
                'icon' => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 15V6h9M15 42H6v-9M42 33v9h-9M33 6h9v9M10 24h28" stroke="var(--member-color,var(--theme-color,#206be7))" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            ),
            't2' => array(
                'title' => '代金券',
                'icon' => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 19.313V9h40v10.313a5.5 5.5 0 0 0-3.636 5.187A5.5 5.5 0 0 0 44 29.687V40H4V29.687A5.5 5.5 0 0 0 7.636 24.5 5.5 5.5 0 0 0 4 19.313z" stroke="var(--member-color,var(--theme-color,#206be7))" stroke-width="3" stroke-linejoin="round"/><path d="M19 16l5 5 5-5M18 22h12M18 28.167h12M24 22v12" stroke="var(--member-color,var(--theme-color,#206be7))" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            ),
            't3' => array(
                'title' => '线下转账',
                'icon' => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M31 34h12M43 26V10a3 3 0 0 0-3-3H8a3 3 0 0 0-3 3v28a3 3 0 0 0 3 3h20.47" stroke="var(--member-color,var(--theme-color,#206be7))" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="M36 39l-5-5 5-5M15 15l5 6 5-6M14 27h12M14 21h12M20 21v12" stroke="var(--member-color,var(--theme-color,#206be7))" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            )
        );
        if($type && isset($types[$type])){
            return $types[$type];
        }
    }

    public static function add_wallet_log($args){
        global $wpdb;
        $table = $wpdb->prefix . self::$logs_table;
        if(isset($args['user_id']) && $args['title'] && $args['value']){
            $log = array(
                'user_id' => $args['user_id'],
                'title' => $args['title'],
                'value' => $args['value'],
                'time' => current_time('mysql')
            );
            $format = array('%d', '%s', '%f', '%s');
            $wpdb->insert($table, $log, $format);
            return $wpdb->insert_id;
        }
    }

    function get_logs($user_id, $per_page=20, $paged=1){
        global $wpdb;
        $table = $wpdb->prefix . self::$logs_table;
        $offset = ($paged - 1) * $per_page;
        $logs = $wpdb->get_results("SELECT * FROM $table WHERE user_id='$user_id' ORDER BY time DESC limit $offset,$per_page");
        return $logs;
    }

    function vouchers_list(){ ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">代金券</h1>
            <a href="<?php echo admin_url('admin.php?page=wpcom-add-voucher'); ?>" class="page-title-action">生成代金券</a>
            <form method="post">
                <?php
                if (!class_exists('WPCOM_Vouchers_List')) require_once WPCOM_MP_DIR . '/includes/vouchers-list.php';
                $list = new WPCOM_Vouchers_List();
                $list->prepare_items();
                $list->search_box('搜索代金券', 'vouchers');
                $list->display();
                ?>
            </form>
        </div>
    <?php }

    public function add_voucher() {
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        WPCOM_ADMIN_UTILS::panel_script();
        $data = map_deep($_POST, 'sanitize_text_field');
        $res = $data && isset($data['add-voucher-nonce']) && wp_verify_nonce($data['add-voucher-nonce'], 'add-voucher') ? self::generate_voucher($data) : '';
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">生成代金券</h1>
            <?php if (!is_wp_error($res) && !empty($res)) { ?>
                <div id="message" class="notice notice-success">
                    <p><strong>代金券生成成功。</strong></p>
                    <p><a href="<?php echo admin_url('admin.php?page=wpcom-vouchers'); ?>">← 返回“代金券”页面 </a></p>
                </div>
            <?php } else if (is_wp_error($res)) { ?>
                <div id="message" class="notice notice-error">
                    <p><strong>代金券生成失败。</strong></p>
                    <p><?php echo $res->get_error_message(); ?></p>
                </div>
            <?php } ?>
            <?php if (!is_wp_error($res) && !empty($res)) { ?>
                <h3>本次生成的代金券</h3>
                <p>多个代金券则一行一个，可点击下方按钮一键复制</p>
                <div class="form-field">
                    <textarea name="vouchers" id="vouchers" cols="30" rows="10"><?php echo implode("\r\n", $res);?></textarea>
                </div>
                <div class="form-field">
                    <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="复制代金券"></p>
                </div>
                <script>
                if (typeof _plugins_options === 'undefined') _plugins_options = [];
                jQuery(function($){
                    $('#submit').on('click', function(){
                        if( typeof document.execCommand !== 'undefined' ){
                            var t = document.querySelector('#vouchers');
                            t.select();
                            document.execCommand('copy');
                            alert('复制成功');
                        }else{
                            alert('浏览器不支持复制，请通过手动全选复制来完成复制操作');
                        }
                    })
                })
                </script>
            <?php } else { ?>
            <form name="add-voucher" id="edittag" method="post" action="" class="add-voucher validate">
                <?php wp_nonce_field('add-voucher', 'add-voucher-nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr id="wpcom-plugin-panel" class="wpcom-term-wrap">
                        <td colspan="2">
                            <term-panel :ready="ready" />
                        </td>
                    </tr>
                </table>
                <input type="submit" class="button button-primary" value="提交" />
            </form>
            <div style="display: none;"><?php wp_editor('EDITOR', 'WPCOM-EDITOR', WPCOM_ADMIN_UTILS::editor_settings(array('textarea_name' => 'EDITOR-NAME'))); ?></div>
            <script>
                if (typeof _plugins_options === 'undefined') _plugins_options = [];
                _plugins_options.push(<?php echo $this->get_vouchers_metas(); ?>);
            </script>
            <?php } ?>
        </div>
    <?php }

    public function edit_voucher(){
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        WPCOM_ADMIN_UTILS::panel_script();
        $data = map_deep($_POST, 'sanitize_text_field');
        $res = $data && isset($data['edit-voucher-nonce']) && wp_verify_nonce($data['edit-voucher-nonce'], 'edit-voucher') ? self::update_voucher($data) : '';
        $id = isset($_GET['id']) ? sanitize_text_field($_GET['id']) : 0;
        if($id && $voucher = self::get_voucher($id, 'ID')){
            if($data && $voucher && $res !== ''){
                $voucher->voucher = trim($data['wpcom_voucher']);
                $voucher->value = trim($data['wpcom_value']);
                $voucher->user_id = trim($data['wpcom_user_id']);
                $voucher->note = $data['wpcom_note'];
            }
            ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">编辑代金券</h1>
            <?php if (!is_wp_error($res) && !empty($res)) { ?>
                <div id="message" class="notice notice-success">
                    <p><strong>代金券更新成功。</strong></p>
                    <p><a href="<?php echo admin_url('admin.php?page=wpcom-vouchers'); ?>">← 返回“代金券”页面 </a></p>
                </div>
            <?php } else if (is_wp_error($res)) { ?>
                <div id="message" class="notice notice-error">
                    <p><strong>代金券更新失败。</strong></p>
                    <p><?php echo $res->get_error_message(); ?></p>
                </div>
            <?php } ?>
            <form name="edit-voucher" id="edittag" method="post" action="" class="add-voucher validate">
                <input type="hidden" name="voucher_id" value="<?php echo esc_attr($id); ?>" />
                <?php wp_nonce_field('edit-voucher', 'edit-voucher-nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr id="wpcom-plugin-panel" class="wpcom-term-wrap">
                        <td colspan="2">
                            <term-panel :ready="ready" />
                        </td>
                    </tr>
                </table>
                <input type="submit" class="button button-primary" value="提交" />
            </form>
            <div style="display: none;"><?php wp_editor('EDITOR', 'WPCOM-EDITOR', WPCOM_ADMIN_UTILS::editor_settings(array('textarea_name' => 'EDITOR-NAME'))); ?></div>
            <script>
                if (typeof _plugins_options === 'undefined') _plugins_options = [];
                _plugins_options.push(<?php echo $this->get_vouchers_metas($voucher); ?>);
            </script>
        </div>
        <?php }else{
            wp_die('代金券获取失败');
        }
    }

    function update_voucher($data){
        global $wpdb;
        $_voucher = isset($data['voucher_id']) ? self::get_voucher($data['voucher_id'], 'ID') : '';
        if(!$_voucher) return new WP_Error('voucher_error', '获取代金券信息失败');
        $voucher = array();
        $data['wpcom_voucher'] = isset($data['wpcom_voucher']) ? trim($data['wpcom_voucher']) : '';
        if($data['wpcom_voucher'] && preg_match('/^[a-zA-Z0-9_-]{6,64}$/', $data['wpcom_voucher'])){
            $voucher['voucher'] = $data['wpcom_voucher'];
        }else{
            return new WP_Error('voucher_error', '代金券错误：仅支持字母、数字以及 _ - 符号');
        }

        $voucher['value'] = isset($data['wpcom_value']) && is_numeric(trim($data['wpcom_value'])) && trim($data['wpcom_value']) > 0 ? trim($data['wpcom_value']) : 0;
        $voucher['value'] = number_format($voucher['value'], 2, '.', '');
        if(!($voucher['value'] && $voucher['value'] > 0)){
            return new WP_Error('value_error', '代金券面值出错');
        }
        $voucher['user_id'] = isset($data['wpcom_user_id']) && is_numeric(trim($data['wpcom_user_id'])) ? trim($data['wpcom_user_id']) : 0;
        $time = isset($data['wpcom_time']) && trim($data['wpcom_time']) ? trim($data['wpcom_time']) : '0000-00-00 00:00:00';
        if($time){
            $time = str_replace('：', ':', $time);
            try{
                new DateTime($time, wp_timezone());
                $voucher['time'] = $time;
            }catch(Exception $e){
                return new WP_Error('time_error', '兑换时间格式错误');
            }
        }
        if($voucher['user_id'] == 0){
            $voucher['time'] = '0000-00-00 00:00:00';
        }else if($voucher['user_id'] && ($voucher['time'] === '' || $voucher['time'] === '0000-00-00 00:00:00')){
            $voucher['time'] = current_time('mysql');
        }
        $voucher['note'] = isset($data['wpcom_note']) ? $data['wpcom_note'] : '';
        $table = $wpdb->prefix . self::$vouchers_table;
        return $wpdb->update($table, $voucher, array('ID' => $_voucher->ID));
    }

    public static function generate_voucher($data){
        $prefix = isset($data['wpcom_prefix']) ? trim($data['wpcom_prefix']) : '';
        if(!preg_match('/^[a-zA-Z0-9_-]{0,32}$/', $prefix)){
            return new WP_Error('prefix_error', '代金券前缀错误：仅支持字母、数字以及 _ - 符号');
        }
        $len = isset($data['wpcom_len']) && is_numeric(trim($data['wpcom_len'])) && trim($data['wpcom_len']) >= 6 && trim($data['wpcom_len']) <= 64 ? trim($data['wpcom_len']) : 32;
        $value = isset($data['wpcom_value']) && is_numeric(trim($data['wpcom_value'])) && trim($data['wpcom_value']) > 0 ? trim($data['wpcom_value']) : 0;
        $value = number_format($value, 2, '.', '');
        if(!($value && $value > 0)){
            return new WP_Error('value_error', '代金券面值出错');
        }
        $note = isset($data['wpcom_note']) && trim($data['wpcom_note']) ? trim($data['wpcom_note']) : '';
        $num = isset($data['wpcom_num']) && is_numeric(trim($data['wpcom_num'])) && trim($data['wpcom_num']) > 0 ? (int) trim($data['wpcom_num']) : 1;
        $num = $num > 100 ? 100 : $num;
        $vouchers = array();
        $i=0; $x = 0;
        while ( $i < $num && $x < 200 ){
            $voucher = $prefix . wp_generate_password($len, false);
            $res = self::insert_voucher($voucher, $value, $note);
            if($res) {
                $vouchers[] = $voucher;
                $i++;
            }
            $x++;
        }
        return $vouchers;
    }

    public static function insert_voucher($voucher, $value, $note){
        global $wpdb;
        $table = $wpdb->prefix . self::$vouchers_table;
        $sql = "insert ignore into $table ( voucher, value, user_id, time, note ) values( '$voucher', '$value', 0, '', '$note' )";
        return $wpdb->query($sql);
    }

    public static function get_voucher($val, $by='voucher'){
        global $wpdb;
        $table = $wpdb->prefix . self::$vouchers_table;
        $voucher = $wpdb->get_row("SELECT * FROM `$table` WHERE `$by` = '$val'");
        if ($voucher && $voucher->ID) return $voucher;
    }

    private function get_vouchers_metas($voucher = false) {
        $res = array('type' => 'taxonomy', 'tax' => 'vouchers', 'options' => array());
        if($voucher && isset($voucher->ID)){
            $res['options'] = $voucher;
        }
        $plugin = $GLOBALS['wpcom_mp']->info;
        $res['filters'] = apply_filters($voucher ? 'wpcom_member_edit_voucher_metas' : 'wpcom_member_vouchers_metas', array());
        $res['ver'] = $plugin['ver'];
        $res['plugin-id'] = $plugin['plugin_id'];
        $res['plugin-slug'] = $plugin['slug'];
        $res['framework_ver'] = WPCOM_ADMIN_UTILS::framework_version($plugin['slug']);
        return wp_json_encode($res);
    }

    public function vouchers_metas($metas) {
        $metas['vouchers'] = array(
            array(
                'n' => 'prefix',
                'l' => '代金券前缀',
                'd' => '可选，不设置则无前缀'
            ),
            array(
                'n' => 'len',
                'l' => '代金券长度',
                's' => 32,
                'd' => '字符长度，最少6，最大64，不包含前缀，不设置或者长度不符则为默认 32'
            ),
            array(
                'n' => 'value',
                'l' => '代金券面值',
                'd' => '必填，单位：元，保留2位小数'
            ),
            array(
                'n' => 'note',
                'l' => '备注说明',
                't' => 'ta',
                'rows' => 2,
                'd' => '可选'
            ),
            array(
                'n' => 'num',
                'l' => '生成数量',
                's' => 1,
                'd' => '可批量生成多个，不设置默认仅生成1个，同时为避免误输入导致性能问题，每次生成数量上限为100'
            ),
        );
        return $metas;
    }

    public function edit_voucher_metas($metas) {
        $metas['vouchers'] = array(
            array(
                'n' => 'voucher',
                'l' => '代金券券码',
                'd' => '长度最少6，最大64'
            ),
            array(
                'n' => 'value',
                'l' => '代金券面值',
                'd' => '必填，单位：元，保留2位小数'
            ),
            array(
                'n' => 'user_id',
                'l' => '兑换用户',
                'd' => '兑换用户的用户ID，如果<b>未兑换则默认为0</b>'
            ),
            array(
                'n' => 'time',
                'l' => '兑换时间',
                'd' => '可选，格式：'.current_time('mysql').'，<b>未兑换默认为 0000-00-00 00:00:00</b>'
            ),
            array(
                'n' => 'note',
                't' => 'ta',
                'rows' => 2,
                'l' => '备注说明',
                'd' => '可选'
            ),
        );
        return $metas;
    }

    public function parent_file_filter($parent_file) {
        global $_wp_real_parent_file, $plugin_page, $_wp_menu_nopriv;
        if($plugin_page === 'wpcom-add-voucher' || $plugin_page === 'wpcom-edit-voucher'){
            $_wp_real_parent_file[$plugin_page] = 'wpcom-member-pro';
            $_wp_menu_nopriv[$plugin_page] = 'wpcom-member-pro';
            if ($parent_file === 'wpcom-vouchers') $parent_file = 'wpcom-member-pro';
        }
        return $parent_file;
    }

    public function submenu_file_filter($submenu_file) {
        global $pagenow;
        $screen = get_current_screen();
        if ($pagenow == 'admin.php' && ($screen->base == 'admin_page_wpcom-add-voucher' || $screen->base == 'admin_page_wpcom-edit-voucher')) {
            $submenu_file = 'wpcom-vouchers';
        }
        return $submenu_file;
    }

    function users_columns($columns){
        $columns['balance'] = __('Balance', 'wpcom');
        return $columns;
    }

    function users_column_value($val, $column_name, $user_id){
        if($column_name === 'balance'){
            $balance = get_user_option( '_wpcom_balance', $user_id );
            $balance = $balance ? $balance : 0;
            $val = '￥' . $balance;
        }
        return $val;
    }

    function users_sortable($columns){
        $columns['balance'] = 'balance';
        return $columns;
    }

    function filter_users( $query ){
        global $pagenow;
        if (is_admin() && 'users.php' == $pagenow ) {
            if(isset($_GET['orderby']) && $_GET['orderby'] === 'balance'){
                $query_args = array(
                    'relation' => 'OR',
                    array(
                        'key'     => '_wpcom_balance',
                        'compare' => 'NOT EXISTS'
                    ),
                    array(
                        'key'     => '_wpcom_balance',
                        'compare' => 'EXISTS'
                    )
                );
                $meta_query = new WP_Meta_Query($query_args);
                $query->set('meta_query', $meta_query);
                $query->set('orderby', 'meta_value');
            }
        }
        return $query;
    }

    function user_row_actions($actions, $user){
        $actions['recharge'] = '<a class="j-recharge" href="#" title="余额充值" data-user="'.esc_attr($user->ID).'">充值</a>';
        return $actions;
    }

    function users_page_scripts(){
        wp_enqueue_script( 'jquery-ui-dialog' );
        wp_enqueue_style( 'wp-jquery-ui-dialog' ); ?>
        <div id="recharge-dialog">
            <form method="post" id="recharge-form">
                <?php wp_nonce_field( 'wpcom_users_recharge', 'wpcom_users_recharge_nonce' ); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="recharge-user">充值用户</label></th>
                        <td>
                            <p class="recharge-user"></p>
                            <input type="hidden" name="recharge-user" class="regular-text" value="">
                            <p class="description">请核对充值用户ID是否正确</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="recharge-value">充值金额</label></th>
                        <td>
                            <input type="number" step="0.01" name="recharge-value" class="regular-text" placeholder="请填写充值金额">
                            <p class="description">必填，可为负，如果是负数的话则会扣减余额；金额最多保留2位小数</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="recharge-title">充值标题</label></th>
                        <td>
                            <input type="text" name="recharge-title" class="regular-text" placeholder="可选，用于余额记录里面显示">
                            <p class="description">如无特殊说明可留空，留空的话默认为：余额充值[线下转账]</p>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <p class="submit"><input type="submit" name="submit" class="button button-primary" value="立即充值"></p>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
        <script>
            jQuery(function($){
                const $wrap = $('#recharge-dialog');
                $wrap.dialog({
                        title: '余额充值',
                        dialogClass: 'wp-dialog',
                        autoOpen: false,
                        width: '680',
                        modal: true,
                        focus: false,
                        position: {
                            my: "center",
                            at: "center",
                            of: window
                        }
                    });
                $('.wp-list-table').on('click', '.j-recharge', function(){
                    let user = $(this).data('user');
                    if(user){
                        $wrap.find('[name="recharge-user"]').val(user);
                        $wrap.find('.recharge-user').html(user);
                        $wrap.dialog('open');
                    }
                    return false;
                });
                $wrap.on('submit', 'form', function (e) {
                    var $form = $(this);
                    var $submit = $form.find('input[type=submit]');
                    if($submit.hasClass('disabled')) return false;
                    $submit.addClass('disabled').val('正在充值...');
                    $.ajax({
                        url: ajaxurl+'?action=wpcom_recharge_byadmin',
                        type: 'post',
                        data: $form.serialize(),
                        dataType: 'json',
                        success: function (res) {
                            $submit.removeClass('disabled').val('立即充值');
                            $wrap.dialog('close');
                            if(res.result==0){
                                alert('充值成功，请刷新页面查看最新余额！');
                            }else{
                                alert(res.msg ? res.msg : '充值失败，请稍后再试！');
                            }
                        },
                        error: function () {
                            $submit.removeClass('disabled').val('立即充值');
                            $wrap.dialog('close');
                            alert('充值失败，请稍后再试！');
                        }
                    });
                    return false;
                });
            })
        </script>
        <?php
    }

    function recharge_byadmin(){
        $res = array('result' => 0);
        if(current_user_can('edit_user')){
            $user_id = isset($_POST['recharge-user']) ? sanitize_text_field($_POST['recharge-user']) : 0;
            $value = isset($_POST['recharge-value']) ? trim(sanitize_text_field($_POST['recharge-value'])) : 0;
            $title = isset($_POST['recharge-title']) ? trim(sanitize_text_field($_POST['recharge-title'])) : '';
            $nonce = isset($_POST['wpcom_users_recharge_nonce']) ? sanitize_text_field($_POST['wpcom_users_recharge_nonce']) : '';
            if($nonce && wp_verify_nonce($nonce, 'wpcom_users_recharge')){
                $value = number_format($value, 2, '.', '');
                if($value && $value != 0 && is_numeric($value)){
                    $user = get_user_by('ID', $user_id);
                    if($user && isset($user->ID) && $user->ID){
                        $log_title = trim($title) ? trim($title) : '余额充值[线下转账]';
                        if(!$this->use_balance($value, $user->ID, $log_title)){
                            $res = array('result' => -5, 'msg' => '充值失败，请刷新页面核对用户金额是否变化');
                        }
                    }else{
                        $res = array('result' => -4, 'msg' => '充值用户获取失败');
                    }
                }else{
                    $res = array('result' => -3, 'msg' => '充值金额异常，请核对修改后重新提交');
                }
            }else{
                $res = array('result' => -2, 'msg' => '页面校验异常，请稍后再试');
            }
        }else{
            $res = array('result' => -1, 'msg' => '无充值权限');
        }
        wp_send_json($res);
    }

    function edit_user_balance($user){
        if (!current_user_can('edit_user')) return;
        $balance = get_user_option( '_wpcom_balance', $user->ID ); ?>
        <h3>余额设置</h3>
        <table class="form-table">
        <tr>
                <th><label for="vip_type">用户余额</label></th>
                <td>
                    <input type="number" name="user_balance" class="regular-text" value="<?php echo $balance !== '' ? $balance : '';?>">
                    <p class="description">温馨提示：此处的余额修改不会产生余额记录，用户在网站前台“我的钱包-余额记录”里面看不到记录，如需为用户充值建议通过用户列表操作</p>
                </td>
            </tr>
        </table>
    <?php }

    function save_user_balance($user_id){
        if (!current_user_can('edit_user', $user_id)) return false;
        if (isset($_POST['user_balance']) && trim($_POST['user_balance']) !== '') {
            $balance = sanitize_text_field(trim($_POST['user_balance']));
            if(is_numeric($balance)){
                $balance = number_format($balance, 2, '.', '');
                if($balance || $balance == 0) update_user_option($user_id, '_wpcom_balance', $balance);
            }
        }
    }

    private static function init_database(){
        global $wpdb, $wpmx_options;
        $logs_table = $wpdb->prefix . self::$logs_table;
        $vouchers_table = $wpdb->prefix . self::$vouchers_table;
        if( $wpdb->get_var("SHOW TABLES LIKE '$logs_table'") != $logs_table ){
            $charset_collate = $wpdb->get_charset_collate();
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            $create_sql = "CREATE TABLE $logs_table (".
                "ID BIGINT(20) NOT NULL auto_increment,".
                "user_id BIGINT(20) NOT NULL,".
                "title longtext,".
                "value decimal(10,2) NOT NULL,".
                "time datetime,".
                "PRIMARY KEY (ID)) $charset_collate;";
            dbDelta( $create_sql );
        }
        if(isset($wpmx_options['recharge_types']) && !empty($wpmx_options['recharge_types']) && in_array('t2', $wpmx_options['recharge_types'])){
            if( $wpdb->get_var("SHOW TABLES LIKE '$vouchers_table'") != $vouchers_table ){
                $charset_collate = $wpdb->get_charset_collate();
                require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
                $create_sql = "CREATE TABLE $vouchers_table (".
                    "ID BIGINT(20) NOT NULL auto_increment,".
                    "voucher varchar(100) NOT NULL,".
                    "value decimal(10,2) NOT NULL,".
                    "user_id BIGINT(20),".
                    "time datetime,".
                    "note longtext,".
                    "PRIMARY KEY (ID)) $charset_collate;";
                dbDelta( $create_sql );
            }
        }
    }
}

new WPCOM_Wallet();