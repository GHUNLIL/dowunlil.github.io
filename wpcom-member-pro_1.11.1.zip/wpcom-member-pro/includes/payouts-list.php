<?php
defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'WP_List_Table' ) ) require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
if ( ! class_exists( 'WPCOM_Payouts_List' ) ) :
    class WPCOM_Payouts_List extends WP_List_Table {
        protected $table;
        private $total_items = array();
        public function __construct(){
            global $wpdb;
            $this->table = $wpdb->prefix . 'wpcom_payouts';

            parent::__construct([
                'screen' => 'payouts'
            ]);
        }

        public function prepare_items() {
            global $wpdb, $orderby, $order;
            wp_reset_vars( array( 'orderby', 'order' ) );

            $this->process_bulk_action();

            $orderby = $orderby ?: 'ID';
            $order = $order ?: 'DESC';
            $per_page = 20;

            $paged = $this->get_pagenum();

            $status = isset($_GET['status']) && $_GET['status']!=='' ? sanitize_text_field($_GET['status']) : '';
            $args = ['per_page' => $per_page, 'paged' => $paged, 'orderby' => $orderby, 'order' => $order];
            if($status !== '') $args['status'] = $status;
            $results = WPCOM_Affiliate::get_payout_logs($args);

            $this->total_items['all'] =  $wpdb->get_var( "SELECT COUNT(*) FROM $this->table" );
            $this->total_items['pedding'] =  $wpdb->get_var( "SELECT COUNT(*) FROM $this->table WHERE status='0'" );
            $this->total_items['accept'] =  $wpdb->get_var( "SELECT COUNT(*) FROM $this->table WHERE status='1'" );
            $this->total_items['payout'] =  $wpdb->get_var( "SELECT COUNT(*) FROM $this->table WHERE status='2'" );
            $this->total_items['reject'] =  $wpdb->get_var( "SELECT COUNT(*) FROM $this->table WHERE status='-1'" );

            $this->set_pagination_args( [
                'total_items' => $results && is_array($results) ? count($results) : 0,
                'per_page'    => $per_page
            ] );
            $this->items = $results;
        }

        public function get_views(){
            $status = isset($_GET['status']) && $_GET['status']!=='' ? sanitize_text_field($_GET['status']) : '';
            $views = array(
                'all' => array(
                    'url' => esc_url( add_query_arg( array('page' => 'wpcom-affiliate-logs', 'tab' => 'payouts'), 'admin.php' ) ),
                    'label' => '全部 <span class="count">（'.$this->total_items['all'].'）</span>',
                    'current' => $status === ''
                ),
                'pedding' => array(
                    'url' => esc_url( add_query_arg( array('page' => 'wpcom-affiliate-logs', 'tab' => 'payouts', 'status' => 0), 'admin.php' ) ),
                    'label' => '等待审核 <span class="count">（'.$this->total_items['pedding'].'）</span>',
                    'current' => $status == 0
                ),
                'accept' => array(
                    'url' => esc_url( add_query_arg( array('page' => 'wpcom-affiliate-logs', 'tab' => 'payouts', 'status' => 1), 'admin.php' ) ),
                    'label' => '审核通过 <span class="count">（'.$this->total_items['accept'].'）</span>',
                    'current' => $status == 1
                ),
                'payout' => array(
                    'url' => esc_url( add_query_arg( array('page' => 'wpcom-affiliate-logs', 'tab' => 'payouts', 'status' => 2), 'admin.php' ) ),
                    'label' => '已提现 <span class="count">（'.$this->total_items['payout'].'）</span>',
                    'current' => $status == 2
                ),
                'reject' => array(
                    'url' => esc_url( add_query_arg( array('page' => 'wpcom-affiliate-logs', 'tab' => 'payouts', 'status' => -1), 'admin.php' ) ),
                    'label' => '审核未通过 <span class="count">（'.$this->total_items['reject'].'）</span>',
                    'current' => $status == -1
                )
            );
            return $this->get_views_links($views);
        }

        function get_columns(){
            $columns = array(
                'cb' => '<input type="checkbox" />',
                'user_id' => '提现用户',
                'total' => '提现金额',
                'time' => '申请时间',
                'status' => '处理状态',
                'data' => '提现信息'
            );
            return $columns;
        }

        public function process_bulk_action() {
            global $wpdb;
            if(!current_user_can('edit_user')) return false;
            if ( 'delete-payout' === $this->current_action() ) {
                $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                if ( wp_verify_nonce( $nonce, 'bulk-payouts' ) ) {
                    $ids = isset($_REQUEST['check']) ? $_REQUEST['check'] : array();
                    if(!empty($ids)) {
                        $ids = implode( ',', array_map( 'absint', $ids ) );
                        $wpdb->query("DELETE FROM $this->table WHERE ID IN($ids)");
                    }
                }else if(isset($_REQUEST['id']) && $_REQUEST['id']){
                    $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                    if ( wp_verify_nonce( $nonce, 'delete-payout_'.$_REQUEST['id'] ) ) {
                        $wpdb->delete($this->table, array('ID' => $_REQUEST['id']));
                    }
                }
            }else if ( 'payout-status' === $this->current_action() ) {
                $id = isset($_REQUEST['id']) && $_REQUEST['id'] ? $_REQUEST['id'] : '';
                $status = isset($_REQUEST['set-status']) && $_REQUEST['set-status'] ? $_REQUEST['set-status'] : '';
                $nonce = esc_attr( $_REQUEST['_wpnonce'] );
                if($id && $status !== '' && wp_verify_nonce( $nonce, 'payout-status_'.$id )){
                    $payout = $wpdb->get_row("SELECT * FROM `".$this->table."` WHERE ID = '$id'");
                    $prompt = isset($_REQUEST['prompt']) && $_REQUEST['prompt'] !== '' ? $_REQUEST['prompt'] : '';
                    $update = $wpdb->update($this->table, array('status' => $status, 'note' => $prompt), array('ID' => $id));
                    if($prompt) $payout->note = $prompt;
                    if($update) do_action('wpcom_payout_status_changed', $status, $payout->status, $payout );
                }
            }
        }

        protected function get_bulk_actions() {
            $actions           = array();
            $actions['delete-payout'] = __( 'Delete' );
            return $actions;
        }
        protected function get_sortable_columns() {
            return array(
                'user_id' => 'user_id',
                'total' => 'total',
                'status' => 'status',
                'time' => 'time'
            );
        }
        protected function get_default_primary_column_name() {
            return 'user_id';
        }
        public function column_cb( $log ) { ?>
            <label class="screen-reader-text" for="cb-select-<?php echo $log->ID; ?>"> </label>
            <input type="checkbox" name="check[]" id="cb-select-<?php echo $log->ID; ?>" value="<?php echo esc_attr( $log->ID ); ?>" />
            <?php
        }
        public function column_user_id( $log ) {
            $user = get_user_by('ID', $log->user_id);
            if(!is_wp_error($user) && isset($user->ID)) {
                $edit_link = add_query_arg( 'wp_http_referer', urlencode( wp_unslash( $_SERVER['REQUEST_URI'] ) ), get_edit_user_link( $user->ID ) );
                $html = '<a href="'.esc_url($edit_link).'" target="_blank">'.$user->display_name.'</a>';
                $incomes = WPCOM_Affiliate::get_aff_incomes($user->ID); // 累计佣金
                $payouts = WPCOM_Affiliate::get_aff_payouts($user->ID); // 已提现佣金
                $html .= '<div style="padding: 5px 10px;border-radius:4px;background: rgba(0,0,0,.04);line-height: 1.67;margin:4px 0;"><div><span>累计佣金：</span>' . number_format($incomes, 2, '.', '') .' 元</div><div><span>累计提现：</span>' . number_format($payouts, 2, '.', '') .' 元</div></div>';
                return $html;
            }else{
                return $log->user_id;
            }
        }
        public function column_total( $log ) {
            return $log->total;
        }
        public function column_time( $log ) {
            return $log->time;
        }
        public function column_status( $log ) {
            $html = '<span class="payout-status-'.$log->status.'">' . WPCOM_Affiliate::get_payout_status($log->status) . '</span>';
            if($log->status == -1 && $log->note){
                $html .= '<span style="display:block;color:#666;">['.$log->note.']</span>';
            }
            return $html;
        }
        public function column_data( $log ) {
            $data = isset($log->data) ? json_decode($log->data, true) : '';
            $html = '';
            if($data && is_array($data)){
                if(isset($data['name']) && $data['name'] !== ''){
                    $html .= '<p class="payout-data-item"><span>用户姓名：</span>' . $data['name'] .'</p>';
                }
                if(isset($data['idcard_num']) && $data['idcard_num'] !== ''){
                    $html .= '<p class="payout-data-item"><span>身份证号：</span>' . $data['idcard_num'] .'</p>';
                }
                if(isset($data['idcard_z']) && $data['idcard_z'] !== ''){
                    $html .= '<p class="payout-data-item"><span>身份证正面：</span><a href="javascript:;" data-src="'.$data['idcard_z'].'" target="_blank">点击查看图片</a></p>';
                }
                if(isset($data['idcard_f']) && $data['idcard_f'] !== ''){
                    $html .= '<p class="payout-data-item"><span>身份证反面：</span><a href="javascript:;" data-src="'.$data['idcard_f'].'" target="_blank">点击查看图片</a></p>';
                }
                if(isset($data['payout_type']) && $data['payout_type'] !== ''){
                    if($data['payout_type'] == 0){
                        $html .= '<p class="payout-data-item"><span>提现方式：</span>支付宝</p>';
                        if(isset($data['alipay']) && $data['alipay']){
                            $html .= '<p class="payout-data-item"><span>提现账号：</span>' . $data['alipay'] .'</p>';
                        }else if(isset($data['qrcode']) && $data['qrcode']){
                            $html .= '<p class="payout-data-item"><span>收款码：</span><a href="javascript:;" data-src="'.$data['qrcode'].'" target="_blank">点击查看图片</a></p>';
                        }
                    }else if($data['payout_type'] == 1){
                        $html .= '<p class="payout-data-item"><span>提现方式：</span>微信支付</p>';
                        if(isset($data['qrcode']) && $data['qrcode']){
                            $html .= '<p class="payout-data-item"><span>收款码：</span><a href="javascript:;" data-src="'.$data['qrcode'].'" target="_blank">点击查看图片</a></p>';
                        }
                    }else if($data['payout_type'] == 2){
                        $html .= '<p class="payout-data-item"><span>提现方式：</span>银行转账</p>';
                        if(isset($data['bank_name']) && $data['bank_name']){
                            $html .= '<p class="payout-data-item"><span>开户银行：</span>' . $data['bank_name'] .'</p>';
                        }
                        if(isset($data['bank_number']) && $data['bank_number']){
                            $html .= '<p class="payout-data-item"><span>银行账号：</span>' . $data['bank_number'] .'</p>';
                        }
                    }
                }

            }else{
                $html = '提现信息异常';
            }
            return $html;
        }
        protected function handle_row_actions( $log, $column_name, $primary ) {
            if ( $primary !== $column_name ) return '';

            $actions           = array();
            $actions['delete'] = sprintf(
                '<a class="submitdelete" href="%s" onclick="return confirm( \'%s\' );">%s</a>',
                wp_nonce_url( "?page=wpcom-affiliate-logs&tab=payouts&action=delete-payout&id=$log->ID", 'delete-payout_' . $log->ID ),
                esc_js( sprintf( __( "即将删除此提现申请记录，请问是否确认删除？", 'wpcom' ), $log->ID ) ),
                __( 'Delete' )
            );
            if($log->status != 1){
                $actions['accept'] = sprintf(
                    '<a href="%s" onclick="return confirm( \'%s\' );">%s</a>',
                    wp_nonce_url( "?page=wpcom-affiliate-logs&tab=payouts&action=payout-status&set-status=1&id=$log->ID", 'payout-status_' . $log->ID ),
                    esc_js( sprintf( __( "是否确认将此提现申请设置为审核通过？", 'wpcom' ), $log->ID ) ),
                    '审核通过'
                );
            }
            if($log->status != 2){
                $actions['done'] = sprintf(
                    '<a href="%s" onclick="return confirm( \'%s\' );">%s</a>',
                    wp_nonce_url( "?page=wpcom-affiliate-logs&tab=payouts&action=payout-status&set-status=2&id=$log->ID", 'payout-status_' . $log->ID ),
                    esc_js( sprintf( __( "是否确认将此提现申请设置为已提现？", 'wpcom' ), $log->ID ) ),
                    '已提现'
                );
            }
            if($log->status != -1){
                $actions['reject'] = sprintf(
                    '<a class="j-payout-reject" href="%s">%s</a>',
                    wp_nonce_url( "?page=wpcom-affiliate-logs&tab=payouts&action=payout-status&set-status=-1&id=$log->ID", 'payout-status_' . $log->ID ),
                    '审核不通过'
                );
            }

            return $this->row_actions( $actions );
        }
    }
endif;