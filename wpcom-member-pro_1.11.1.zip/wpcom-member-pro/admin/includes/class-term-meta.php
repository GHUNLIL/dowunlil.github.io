<?php defined( 'ABSPATH' ) || exit;
class WPCOM_Plugin_Term_Meta {
    protected $tax;
    protected $plugin;
    public function __construct( $tax, $plugin ) {
        $this->tax = $tax;
        $this->plugin = $plugin;
        add_action( $tax . '_add_form_fields', array($this, 'add'), 10, 2 );
        add_action( $tax . '_edit_form_fields', array($this, 'edit'), 10, 2 );
        add_action( 'created_' . $tax, array($this, 'save'), 50, 2 );
        add_action( 'edited_' . $tax, array($this, 'save'), 50, 2 );
    }

    function add(){
        global $is_wpcom_plugin_panel;
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        WPCOM_ADMIN_UTILS::panel_script(); ?>
        <script>if(typeof _plugins_options === 'undefined') _plugins_options = []; _plugins_options.push(<?php echo $this->get_term_metas(0);?>);</script>
        <?php if(!class_exists('WPCOM_Meta') && !$is_wpcom_plugin_panel){ $is_wpcom_plugin_panel = 1;?>
        <div id="wpcom-plugin-panel" class="wpcom-term-wrap"><term-panel :ready="ready"/></div>
        <div style="display: none;"><?php wp_editor( 'EDITOR', 'WPCOM-EDITOR', WPCOM_ADMIN_UTILS::editor_settings(array('textarea_name'=>'EDITOR-NAME')) );?></div>
    <?php } }

    function edit($term){
        global $is_wpcom_plugin_panel;
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        WPCOM_ADMIN_UTILS::panel_script(); ?>
        <script>if(typeof _plugins_options === 'undefined') _plugins_options = []; _plugins_options.push(<?php echo $this->get_term_metas($term->term_id);?>);</script>
        <?php if(!class_exists('WPCOM_Meta') && !$is_wpcom_plugin_panel){ $is_wpcom_plugin_panel = 1;?>
        <tr id="wpcom-plugin-panel" class="wpcom-term-wrap"><td colspan="2"><term-panel :ready="ready"/></td></tr>
        <tr style="display: none;"><th></th><td><div style="display: none;"><?php wp_editor( 'EDITOR', 'WPCOM-EDITOR', WPCOM_ADMIN_UTILS::editor_settings(array('textarea_name'=>'EDITOR-NAME')) );?></div>
        </td></tr>
    <?php } }

    function get_term_metas($term_id){
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        $res = array('type' => 'taxonomy', 'tax' => $this->tax, 'term_id' => $term_id);
        $res['options'] = $term_id ? get_term_meta( $term_id, '_wpcom_metas', true ) : array();
        $res['filters'] = apply_filters( $this->plugin['slug'] . '_tax_metas', array());
        $res['ver'] = $this->plugin['ver'];
        $res['plugin-id'] = $this->plugin['plugin_id'];
        $res['plugin-slug'] = $this->plugin['slug'];
        $res['framework_ver'] = WPCOM_ADMIN_UTILS::framework_version($this->plugin['slug']);
        $res = apply_filters( 'wpcom_init_plugin_options', $res );
        return json_encode($res);
    }

    function save($term_id){
        global $is_wpcom_plugin_panel_save;
        if($is_wpcom_plugin_panel_save) return false;
        $is_wpcom_plugin_panel_save = 1;
        $values = get_term_meta( $term_id, '_wpcom_metas', true );
        $values = $values ?: array();
        $_post = $_POST;
        foreach($_post as $key => $value) {
            if (preg_match('/^wpcom_/i', $key)) {
                $name = preg_replace('/^wpcom_/i', '', $key);
                $value = stripslashes_deep($value);

                if(preg_match('/^_/', $name)){
                    update_term_meta($term_id, $name, $value);
                }else{
                    if ( $value !== '' )
                        $values[$name] = $value;
                    else if ( isset($values[$name]) )
                        unset($values[$name]);
                }
            }
        }
        update_term_meta( $term_id, '_wpcom_metas', $values );
    }
}

add_action( 'wp_ajax_wpcom_plugin_get_taxs', 'wpcom_plugin_get_taxs' );
function wpcom_plugin_get_taxs(){
    $taxs = $_REQUEST['taxs'];
    $res = array();
    if( current_user_can( 'edit_posts' ) ){
        require_once WPCOM_ADMIN_PATH . 'includes/class-utils.php';
        foreach ($taxs as $tax){
            if($tax) $res[$tax] = WPCOM_ADMIN_UTILS::category($tax);
        }
    }
    $res = apply_filters('wpcom_themer_get_taxs', $res, $taxs);
    wp_send_json($res);
}