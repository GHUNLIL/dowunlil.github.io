<?php defined( 'ABSPATH' ) || exit;

add_filter('wpcom_plugin_themer_version', function($version){
    $current = array(
        'ver' => '2.8.0',
        'path' => plugin_dir_path( __FILE__ ),
        'uri' => plugins_url( '/', __FILE__ )
    );
    if(empty($version) || !isset($version['ver'])) return $current;
    return version_compare($version['ver'], $current['ver'], '<') ? $current : $version;
});

add_action('wpcom_setup_plugin_themer', function(){
    $version = apply_filters('wpcom_plugin_themer_version', array());
    if($version && isset($version['ver']) && !defined('WPCOM_ADMIN_VERSION') ) {
        define( 'WPCOM_ADMIN_VERSION', $version['ver'] );
        if( !defined('WPCOM_ADMIN_PATH') ) {
            define( 'WPCOM_ADMIN_PATH', $version['path'] );
            define( 'WPCOM_ADMIN_URI', $version['uri'] );
        }
        require_once WPCOM_ADMIN_PATH . 'includes/class-plugin-panel.php';
    }else if(!defined('WPCOM_ADMIN_VERSION')){
        define( 'WPCOM_ADMIN_VERSION', '2.8.0' );
        if( !defined('WPCOM_ADMIN_PATH') ) {
            define( 'WPCOM_ADMIN_PATH', plugin_dir_path( __FILE__ ) );
            define( 'WPCOM_ADMIN_URI', plugins_url( '/', __FILE__ ) );
        }
        require_once WPCOM_ADMIN_PATH . 'includes/class-plugin-panel.php';
    }
});