---
name: xray-core-node
description: 官方 Xray Core 节点部署、迁移、配置、订阅、路由分流、链式代理、WireGuard 组网、nftables 转发、BBR 网络优化、Linux 运维加固、日志分析与故障排查助手。适用于 VLESS + REALITY + XTLS-RPRX-Vision、SS2022、Hysteria2、订阅服务、多出口分流和多服务器链路编排。
---

# 官方 Xray Core 节点助手

用于部署和管理官方 Xray Core 节点，覆盖入口协议、服务端路由、链式出口、跨服务器组网、订阅生成、服务器运维、网络优化和排错。

## 主动引导

当用户只说“开始”“帮我配置节点”“我不会用”“怎么弄”之类的模糊需求时，先主动询问目标，不要求用户理解协议术语。

默认开场：

```text
你想先做哪一类？
1. 单机快速节点
2. 多用户订阅
3. 多服务器链式转发
4. 服务分流与屏蔽规则
5. 防火墙、端口和 IP 限制
6. 排错和恢复
```

随后按选择追问最少参数：

- 单机快速节点：服务器 SSH、节点名、端口偏好、协议偏好
- 多用户订阅：用户数量、备注规则、协议组合、订阅域名或端口
- 多服务器链式转发：每台服务器角色、SSH、互联 IP、最终出口
- 服务分流与屏蔽规则：默认出口、分流出口、要特殊处理的服务
- 防火墙、端口和 IP 限制：SSH 端口、放行端口、允许/屏蔽 IP 或国家
- 排错和恢复：故障现象、最近改动、当前配置、日志片段

用户已经提供服务器账号、配置片段或明确目标时，直接进入检查、计划、备份、修改和验证流程。

对新手使用简短中文解释：

- “入口”是客户端连接到服务器的协议和端口
- “出口”是服务器访问目标网站时使用的线路
- “分流”是让不同网站走不同出口
- “订阅”是把多个节点链接集中给客户端导入
- “回滚”是应用失败后恢复旧配置

## 内置参考资料

按任务读取对应文件，避免一次加载全部内容。

- 协议配置：`references/protocol-templates.md`
- 分流规则：`references/routing-rules.md`
- 链路转发与 WireGuard：`references/forwarding-topologies.md`
- 防火墙、端口和 IP 限制：`references/access-control-firewall.md`
- 订阅与用户管理：`references/subscription-users.md`
- 面板 API 管理：`references/panel-api-management.md`
- BBR 与网络优化：`references/network-optimization.md`
- 信息收集、预检与验收：`references/intake-validation.md`
- 运维、排错、升级、脱敏：`references/operations-runbook.md`

使用规则：

- 用户要新建协议或节点时，读取协议配置。
- 用户要分流、屏蔽、Google 登录、AI/流媒体规则时，读取分流规则。
- 用户要多服务器串联、转发、组网、落地出口时，读取链路转发与 WireGuard。
- 用户要只放行端口、限制 IP、国家白名单/黑名单时，读取访问控制。
- 用户要多用户、订阅、用户启停时，读取订阅与用户管理。
- 用户要接入面板、读取 Profile/Host/用户活动时，读取面板 API 管理。
- 用户要优化网络、BBR、UDP/HY2、转发吞吐时，读取网络优化。
- 用户要多用户、多机器、多协议、多分流，或担心配置失败时，读取信息收集、预检与验收。
- 用户要检查服务器、修复错误、迁移或发布脱敏时，读取运维手册。

## 复杂部署保护

遇到多用户、多机器、多协议、多出口分流、面板批量应用、端口转发或防火墙改动时，先主动问全信息，再生成：

- 拓扑图
- 配置矩阵
- 端口矩阵
- 分流规则矩阵
- 风险预检
- 分批应用计划
- 验收清单
- 回滚点

复杂部署默认分批执行：先落地，再中继，再入口，最后订阅和分流。每批都验证服务状态、端口监听、出口 IP、订阅可用性和关键规则命中。

用户要求跳过额外认证或验证流程时，继续使用本地静态分析、已提供资料、只读检查、配置测试、日志和回滚机制推进。

## 路径约定

- Xray 二进制：`/usr/local/bin/xray`
- Xray 配置：`/usr/local/etc/xray/config.json`
- 客户端信息：`/usr/local/etc/xray/client-info.txt`
- geodata：`/usr/local/share/xray/geoip.dat`、`/usr/local/share/xray/geosite.dat`
- Xray 服务：`/etc/systemd/system/xray.service`
- Xray 日志：`/var/log/xray/access.log`、`/var/log/xray/error.log`
- Hysteria2 配置：`/etc/hysteria/config.yaml`
- Hysteria2 ACL：`/etc/hysteria/acl.txt`
- 轻量管理器：`/usr/local/bin/nodectl`
- 管理器状态：`/usr/local/etc/node-manager/state.json`

## 默认节点形态

VLESS Reality Vision：

- 协议：`vless`
- 传输：`tcp`
- 安全：`reality`
- Flow：`xtls-rprx-vision`
- 加密：`none`
- Sniffing：`http`、`tls`、`quic`
- 出站：`freedom`

推荐 Reality 参数：

- `dest`: `www.microsoft.com:443`
- `serverNames`: `["www.microsoft.com"]`
- 客户端 `fp`: `chrome`

## 随机化策略

公开发布和批量部署时，所有可随机参数都自动生成，避免形成固定模板特征。

默认随机化：

- 节点备注名
- 入口 tag / 出口 tag
- VLESS UUID
- Reality privateKey / publicKey
- Reality shortId
- Reality SNI / dest 候选
- SS2022 密钥
- HY2 密码
- HY2 obfs password
- WireGuard private/public key
- WireGuard 内网网段
- 订阅 token
- 订阅路径
- 管理器状态 token
- 非用户指定的服务端口
- 防火墙 table/chain 名称后缀

默认端口策略：

- SSH 端口按现状保留。
- 用户指定端口时使用指定值。
- 未指定时从高位端口随机选择并检查占用。
- 订阅端口、SS2022、VLESS、HY2、WireGuard、SOCKS/Mixed 端口相互避让。

Reality SNI / dest 策略：

- 从常见可达站点候选池选择。
- `serverNames` 与 `dest` 保持一致。
- 生成后验证域名解析和 443 可达性。
- 同一批多节点避免重复使用完全相同 SNI、shortId 和端口组合。

命名策略：

- 对外显示名可以可读，例如地区 + 协议。
- 内部 tag 使用随机后缀，例如 `in-vless-a8f3`、`out-socks-91cd`。
- 订阅 token 使用高熵随机字符串。

随机化后仍要输出清单，便于备份和排错：

```text
协议
监听端口
节点备注
SNI
订阅地址
服务状态
```

私钥、密码、token 只在必要连接信息和服务器配置里出现。

SS2022：

- 推荐方法：`2022-blake3-aes-128-gcm` 或 `2022-blake3-aes-256-gcm`
- 密钥使用标准 base64
- 入站网络：`tcp,udp`

Hysteria2：

- 单账号优先使用 `password` 认证
- 多账号可使用 `userpass`
- NAT 后 Peer 保留 `PersistentKeepalive = 25`

## 部署流程

1. SSH 登录并检查系统、架构、端口、服务和防火墙。
2. 生成 UUID、Reality key、shortId、SS2022 密钥和 HY2 密码。
3. 写入官方 Xray JSON 配置。
4. 安装或更新 Xray、geodata 和 systemd 服务。
5. 配置 Hysteria2、订阅服务和轻量管理器。
6. 按需配置 BBR、WireGuard、nftables 转发或服务端分流。
7. 运行配置测试并重启服务。
8. 验证端口、订阅、代理出口 IP 和日志。

常用验证：

```bash
/usr/local/bin/xray run -test -config /usr/local/etc/xray/config.json
systemctl is-active xray
systemctl is-active hysteria-server.service
systemctl is-active xray-sub
ss -lntup
journalctl -u xray -n 80 --no-pager
```

## 路由与分流

Xray 规则统一按下面模型设计：

```text
inboundTag → 默认 outboundTag
inboundTag + domain/ip/port/protocol → 指定 outboundTag
```

推荐规则顺序：

1. DNS 53 劫持到 `DNS-OUT`
2. 私有/保留 IP、危险端口、BT/PT
3. 国内 App 上报/埋点
4. 广告追踪、博彩、IP 纯净度检测站
5. Google Login / OAuth
6. Google Search / Maps / YouTube / Gmail / Gemini
7. AI 服务
8. 流媒体、社交、支付、电商、开发云
9. 自定义域名/IP 分流
10. inbound 默认出口兜底

规则目标支持任意 outbound tag，例如 `DIRECT`、`BLOCK`、`SOCKS5-US-HOME`、`HTTP-OUT`。

## 多出口与链式代理

常用 outbound：

- `DIRECT`：本机直连
- `BLOCK`：黑洞屏蔽
- `DNS-OUT`：DNS 出站
- `SOCKS5-*`：链式 SOCKS5 出口
- `HTTP-*`：HTTP 代理出口

SOCKS5 outbound 模板：

```json
{
  "tag": "SOCKS5-US-HOME",
  "protocol": "socks",
  "settings": {
    "servers": [
      {
        "address": "HOST",
        "port": 1080,
        "users": [{"user": "USER", "pass": "PASS"}]
      }
    ]
  }
}
```

链路示例：

```text
client → VLESS/SS2022/HY2 → DIRECT
client → entry inbound → SOCKS5 home outbound
client → entry inbound → Google rule → SOCKS5 NAT outbound
client → entry inbound → Netflix rule → DIRECT
```

添加链式出口时收集：

- 出口 tag / 备注名
- SOCKS5/HTTP 地址、端口
- 账号密码
- 使用范围：全局默认或指定服务
- UDP 支持情况

## 服务规则库

常用服务可生成独立规则，并指定任意 outbound。

Google：

- Login / OAuth：`accounts.google.com`、`oauth2.googleapis.com`、`apis.google.com`、`ssl.gstatic.com`、`www.gstatic.com`、`gstatic.com`、`googleapis.com`、`googleusercontent.com`
- Search：`full:google.com`、`full:www.google.com`、`full:www.google.com.hk`、`full:www.google.co.jp`、`full:www.google.com.tw`、`full:www.google.com.sg`
- Maps：`maps.google.com`、`googlemaps.com`、`maps.gstatic.com`、`maps.googleapis.com`
- YouTube：`geosite:youtube`、`youtube.com`、`youtu.be`、`ytimg.com`、`googlevideo.com`、`ggpht.com`
- Gmail / Drive：`gmail.com`、`mail.google.com`、`drive.google.com`、`docs.google.com`、`googleusercontent.com`
- Gemini：`gemini.google.com`、`bard.google.com`、`aistudio.google.com`、`ai.google.dev`、`generativelanguage.googleapis.com`

AI：

- OpenAI / ChatGPT：`chatgpt.com`、`openai.com`、`oaistatic.com`、`oaiusercontent.com`、`openaiapi-site.azureedge.net`
- Claude：`claude.ai`、`anthropic.com`
- Perplexity：`perplexity.ai`、`pplx.ai`
- Microsoft Copilot：`copilot.microsoft.com`、`copilot.cloud.microsoft`、`bing.com`、`edgeservices.bing.com`、`sydney.bing.com`
- Grok / xAI：`grok.com`、`x.ai`
- Poe：`poe.com`、`quora.com`
- Midjourney：`midjourney.com`、`cdn.midjourney.com`
- DeepSeek：`deepseek.com`、`deepseek.ai`、`deepseekapi.com`

流媒体：

- Netflix：`geosite:netflix`、`netflix.com`、`nflxvideo.net`、`nflximg.net`、`nflxext.com`、`fast.com`
- Disney+ / Hulu：`disneyplus.com`、`disney-plus.net`、`dssott.com`、`hulu.com`、`hulustream.com`、`espn.com`、`disneystreaming.com`
- Spotify：`spotify.com`、`scdn.co`、`spotifycdn.com`、`audio-sp-tok.com`、`spotifycdn.net`

其他分类：

- 社交：Telegram、X/Twitter、Meta/Instagram/Facebook、TikTok
- 开发云：GitHub、Cloudflare、主流云服务商、Microsoft、Google Cloud
- 支付电商：PayPal、Stripe、Amazon

## 安全规则库

可生成：

- DNS 53 劫持：`port: 53`、`network: udp,tcp` → `DNS-OUT`
- 私有/保留 IP：`geoip:private` → `BLOCK`
- 危险端口：25、465、587、137、138、139、445、23、3389、5900 → `BLOCK`
- BT/PT：`protocol: ["bittorrent"]` → `BLOCK`
- 国内 App 上报：美团、点评、微信、小程序、友盟、Bugly、腾讯 beacon、小米、字节、百度统计等
- 广告追踪：DoubleClick 和常见广告 SDK
- 博彩站点：bet365、pokerstars、888casino、williamhill、betway、draftkings、fanduel、sbobet、stake、rollbit
- IP 检测站：ipinfo、scamalytics、spur、ipqualityscore、whoer、ipleak、browserleaks、abuseipdb、criminalip、fraudguard、proxycheck、ip.sb
- 中国大陆 IP/域名：`geoip:cn`、`geosite:cn`

Google 服务保持独立分类，广告规则和 Google 服务规则分开管理。

## Google 登录排查

快捷登录弹窗无响应时检查：

- Login/OAuth 域名是否命中 `BLOCK`
- Login/OAuth 是否被广告、Google 其他、兜底规则覆盖
- 同一次登录链路是否被拆到多个出口
- DNS 与 `domainStrategy` 是否导致命中错误 IP 规则
- 规则顺序是否让阻断规则先于登录规则

Login/OAuth 规则放在高优先级，并固定到稳定出口。

## 多服务器编排

典型角色：

- 前置入口：暴露 SS2022 / VLESS / HY2 和订阅
- 专线/IXPOP：低延迟中继，使用 nftables 内核 NAT
- 云中继：承接专线或直连入口，再转发到落地
- Residential 出口：最终出口，提供 SOCKS5/Mixed/HTTP 或 Xray inbound

示例：

```text
线路 A：client → Region-A 前置 SS2022 → IXPOP 专线 → Region-B 中继 → Residential 出口
线路 B：client → VLESS Reality 直连 Region-B 中继 → Residential 出口
```

执行顺序：

1. 逐台 SSH 只读检查。
2. 生成链路图和端口表。
3. 备份每台机器的相关配置。
4. 从落地端开始配置，再配置中继和入口。
5. 每一跳验证端口与连通性。
6. 端到端测试并输出订阅。

收集信息：

- 每台服务器：名称、IP/域名、SSH 端口、登录账号、密码或 key
- 每台服务器角色
- 客户端入口协议和端口
- 服务器之间连接方式：公网、内网、专线 IP、DDNS
- Residential 出口能力：SOCKS5/Mixed/HTTP/Xray/端口转发
- 全局出口或服务级分流
- SSH 端口避让

## 转发技术选择

- 客户端入口：Xray 协议，例如 SS2022、VLESS Reality Vision、HY2
- 同专线/低丢包端口透传：nftables DNAT/SNAT/MASQUERADE
- 固定两点或多点组网：WireGuard
- 服务级分流：Xray routing + socks/http/freedom outbounds
- 公网高丢包抗抖动：HY2/TUIC/KCP
- 临时转发、协议转换、TLS 包装：gost

推荐组合：

```text
入口：Xray
低延迟透传：nftables
固定组网：WireGuard
服务分流：Xray routing
抗抖动：HY2/TUIC
协议转换：gost
```

## nftables 转发

现代 Linux 优先使用 nftables 做内核 NAT 转发。

模板：

```nft
table ip xray_forward {
  chain prerouting {
    type nat hook prerouting priority dstnat; policy accept;
    tcp dport { PORTS } dnat to TARGET_IP
    udp dport { PORTS } dnat to TARGET_IP
  }
  chain postrouting {
    type nat hook postrouting priority srcnat; policy accept;
    ip daddr TARGET_IP masquerade
  }
}
```

转发前收集：

- SSH 端口
- 目标 IP
- 本机端口范围
- 目标端口范围
- 协议：TCP、UDP 或两者
- 持久化方式

排查：

```bash
nft list ruleset
iptables -t nat -nL PREROUTING --line-numbers
iptables -t nat -nL POSTROUTING --line-numbers
iptables -nL FORWARD --line-numbers
sysctl -n net.ipv4.ip_forward
conntrack -L 2>/dev/null | head
```

## WireGuard 组网

默认双机模型：

```text
云服务器 wg0：WG_SERVER_CIDR，ListenPort WG_PORT
Peer 机器 wg0：WG_PEER_CIDR，Endpoint 指向云服务器公网 IP:WG_PORT
```

基础流程：

```bash
apt-get update
apt-get install -y wireguard iproute2
umask 077
wg genkey | tee /etc/wireguard/privatekey | wg pubkey > /etc/wireguard/publickey
```

云服务器 `/etc/wireguard/wg0.conf`：

```ini
[Interface]
Address = WG_SERVER_CIDR
ListenPort = 51820
PrivateKey = SERVER_PRIVATE_KEY

[Peer]
PublicKey = HOME_PUBLIC_KEY
AllowedIPs = WG_PEER_IP/32
PersistentKeepalive = 25
```

Peer `/etc/wireguard/wg0.conf`：

```ini
[Interface]
Address = WG_PEER_CIDR
PrivateKey = HOME_PRIVATE_KEY

[Peer]
PublicKey = SERVER_PUBLIC_KEY
Endpoint = SERVER_PUBLIC_IP:51820
AllowedIPs = WG_SERVER_IP/32
PersistentKeepalive = 25
```

出口侧 NAT：

```bash
sysctl -w net.ipv4.ip_forward=1
nft add table ip wg_nat
nft 'add chain ip wg_nat postrouting { type nat hook postrouting priority srcnat; policy accept; }'
nft add rule ip wg_nat postrouting ip saddr WG_SUBNET oifname "WAN_IFACE" masquerade
```

验证：

```bash
systemctl enable --now wg-quick@wg0
wg show
ip addr show wg0
ping -c 3 WG_PEER_IP
```

排查：

- `wg show` 查看 latest handshake
- 检查 UDP 端口、防火墙、Endpoint、PublicKey
- 检查 AllowedIPs、路由、ip_forward、NAT

## BBR 与网络优化

专用参考文件：

```text
references/network-optimization.md
```

默认由助手直接生成机器配置。需要处理 BBR、sysctl、RPS、conntrack、initcwnd、UDP/HY2 或高吞吐转发时，读取专用参考文件并按机器状态生成命令清单。

网络优化优先级：

1. `references/network-optimization.md` 的参数模板和执行清单
2. 通用 sysctl 模板和网卡队列参数
3. 通用运维资料中的 BBR 参数参考

常见配置项：

- `net.core.default_qdisc = fq`
- `net.ipv4.tcp_congestion_control = bbr`
- TCP/UDP 缓冲区
- `tcp_notsent_lowat`
- `tcp_fastopen`
- `tcp_mtu_probing`
- `nf_conntrack_max`
- UDP conntrack 超时
- `initcwnd/initrwnd`
- RPS 多核网卡处理
- 可选 Swap

写入位置：

```bash
/etc/sysctl.d/99-network-optimize.conf
/etc/modules-load.d/network-optimize.conf
/etc/security/limits.d/99-network-optimize.conf
/etc/network-optimizer/
```

验证：

```bash
sysctl -n net.ipv4.tcp_congestion_control
sysctl -n net.core.default_qdisc
sysctl -n net.core.rmem_max
ip route show default
systemctl is-active initcwnd-enforcer.timer
systemctl is-active rps-optimize.service
```

## 国家访问控制

支持：

- 国家白名单
- 国家黑名单
- 自定义 CIDR 允许或阻断
- 单端口/端口组放行
- 仅放行指定端口，其余入站丢弃
- 按源 IP/CIDR 放行指定端口
- 按源 IP/CIDR 屏蔽指定端口
- 入站方向
- 入站 + 转发方向
- Ping 控制

国家 IP 数据可使用 ipdeny aggregated zone。规则实现优先使用 nftables。

启用前收集：

- SSH 端口
- 国家代码
- 自定义管理 IP
- 放行端口列表
- 源 IP/CIDR 列表
- 控制方向
- Ping 策略
- 回退方式

端口放行模型：

```nft
table inet access_control {
  chain input {
    type filter hook input priority filter; policy drop;
    ct state established,related accept
    iif "lo" accept
    tcp dport { SSH_PORT, ALLOW_TCP_PORTS } accept
    udp dport { ALLOW_UDP_PORTS } accept
    ip protocol icmp accept
  }
}
```

可组合策略：

- 全局仅放行指定 TCP/UDP 端口
- 指定国家/IP 仅可访问指定端口
- 指定 IP/CIDR 全放行，其余只放行服务端口
- 指定 IP/CIDR + 指定端口放行，例如 `ip saddr CLIENT_IP tcp dport SERVICE_PORT accept`
- 指定 IP/CIDR + 指定端口屏蔽，例如 `ip saddr CLIENT_IP tcp dport SERVICE_PORT drop`
- 管理 IP 访问 SSH，业务 IP 访问代理端口，其他来源拒绝
- SSH 端口始终纳入放行列表

IP + 端口规则模板：

```nft
table inet access_control {
  chain input {
    type filter hook input priority filter; policy drop;
    ct state established,related accept
    iif "lo" accept

    ip saddr { ADMIN_IPS } tcp dport { SSH_PORT } accept
    ip saddr { CLIENT_IPS } tcp dport { ALLOW_TCP_PORTS } accept
    ip saddr { CLIENT_IPS } udp dport { ALLOW_UDP_PORTS } accept

    ip saddr { BLOCK_IPS } drop
  }
}
```

应用前生成端口清单和回退命令，先确认当前 SSH 会话来源仍可访问。

## 通用服务器运维能力

可吸收通用 Linux 运维资料的做法，并改写为可审计、可回滚、可脱敏的命令流程。

基础识别：

- 系统发行版：Debian、Ubuntu、CentOS、AlmaLinux、Rocky、Fedora、Alpine、Arch、openSUSE
- 包管理器：apt、dnf、yum、apk、pacman、zypper
- 架构：x86_64、aarch64、armv7
- 虚拟化环境、内核版本、网卡、默认路由、IPv4/IPv6 栈

基础工具安装：

- `curl`、`wget`、`tar`、`unzip`、`jq`、`socat`
- `iproute2`、`nftables`、`iptables`、`ipset`、`conntrack`
- `openssl`、`qrencode`、`uuid-runtime`
- `fail2ban`、`rsync`、`tmux`
- Docker 与 Compose，用于订阅服务、日志服务或辅助管理面板

资源与系统设置：

- Swap 创建、调整和移除
- 主机名、时区、DNS、IPv4/IPv6 优先级
- 软件源切换和系统包更新
- 磁盘、内存、CPU、负载、网卡流量检查
- journal 空间控制和旧日志清理

SSH 管理：

- 读取当前 SSH 端口和登录来源
- 修改 SSH 端口时先写入临时放行规则
- 导入公钥、生成密钥、切换密码登录策略
- 检查 `sshd_config` 后重载服务
- 输出当前会话的回退命令

Fail2ban 加固：

- SSH jail：按失败次数和封禁时长配置
- Xray/HY2 日志 jail：按 access/error 日志提取异常认证或高频连接
- Nginx/订阅服务 jail：按 401/403/404 高频访问配置
- 封禁列表、解封、状态查询统一输出

Docker 辅助：

- 安装 Docker 与 Compose
- 查看容器、端口、日志、资源占用
- 限制容器端口来源 IP
- 使用 `DOCKER-USER` 链控制容器入站流量
- 备份容器 compose、env、volume 路径

证书与反向代理：

- ACME/certbot 证书申请、导入和续期
- Nginx HTTP/HTTPS 站点配置
- Nginx stream 四层转发
- 订阅服务反代、静态 HTML 发布、HSTS/HTTP2/HTTP3 头部检查

iptables 兼容层：

- 旧系统或 Docker 场景可用 iptables/ipset
- 规则持久化到 `/etc/iptables/rules.v4`
- 通过 crontab 或系统服务恢复规则
- 对应 nftables 方案优先生成，同时保留 iptables 检查命令
- SYN/UDP 速率限制、Ping 策略、国家 IP 集合使用 ipset 管理

端口与 IP 快速动作：

```text
open-port PORT[/tcp|udp]
close-port PORT[/tcp|udp]
allow-ip CIDR
block-ip CIDR
allow-ip-port CIDR PORTS
block-ip-port CIDR PORTS
allow-country CC PORTS
block-country CC
```

批量服务器编排：

- 先建立服务器清单：名称、角色、SSH、入口端口、内网/公网地址
- 凭据只在本次会话使用，日志输出自动脱敏
- 每台机器生成独立备份目录
- 支持并行只读检查，串行写入配置
- 每一跳输出健康检查命令与回退动作

备份迁移：

- 配置文件、systemd unit、证书、订阅服务、Docker compose 和 volume 清单
- `rsync` 增量同步
- tar 压缩归档
- 备份目录按时间戳命名
- 回滚命令与服务重启顺序一起输出

后台任务：

- tmux 持久会话
- cron 定时任务
- systemd timer
- 长任务输出日志路径和恢复命令

日志管理：

- `journalctl` 最近日志、实时跟踪、按服务筛选
- Xray access/error 日志截取
- HY2 服务日志截取
- SSH 登录安全日志
- 过期 journal 清理建议

执行策略：

- 外部资料作为静态参考处理
- 统计上报、自动安装自身、alias 注入、明文凭据落盘等行为改写为显式命令
- 所有联网下载动作先说明来源、文件路径和用途
- 所有写入动作先备份，再测试，再应用

## 轻量管理器

`nodectl` 命令语义：

```bash
nodectl init
nodectl status
nodectl list
nodectl sub admin
nodectl sub admin --show-links
nodectl name "NODE_NAME"
nodectl add USER
nodectl del USER
nodectl enable USER
nodectl disable USER
nodectl rules show
nodectl rules block-cn-on
nodectl rules block-cn-off
nodectl apply
```

功能：

- 管理 VLESS Reality 客户端
- 管理 SS2022 每账号端口
- 管理 HY2 单账号或多账号认证
- 生成 raw/base64 订阅
- 渲染安全规则和服务级分流
- 应用前备份，失败回滚

## 日志与排错

常用命令：

```bash
journalctl -u xray -n 100 --no-pager
journalctl -u hysteria-server.service -n 100 --no-pager
tail -n 100 /var/log/xray/access.log
tail -n 100 /var/log/xray/error.log
ss -lntup
```

HY2 排查：

- 服务状态：`systemctl is-active hysteria-server.service`
- UDP 监听：`ss -lunp`
- 服务端日志：`journalctl -u hysteria-server.service`
- 本机回环测试：`hysteria client` + SOCKS5 + `curl`
- 外部连接记录：latest client connected / auth failed / timeout

Xray 排查：

- `xray run -test`
- geodata 路径
- 端口占用
- Reality 参数
- UUID / flow / SNI / publicKey / shortId
- access log 的 inbound/outbound/email

## 备份与回滚

所有线上修改按顺序执行：

1. 备份相关配置和状态文件。
2. 生成新配置。
3. 运行 Xray 配置测试。
4. 重启相关服务。
5. 检查 active 状态和端口监听。
6. 拉取订阅或执行代理测试。
7. 异常时恢复备份并重启服务。

备份对象：

- `/usr/local/etc/xray/config.json`
- `/etc/hysteria/config.yaml`
- `/etc/hysteria/acl.txt`
- `/usr/local/etc/node-manager/state.json`
- nftables/iptables 规则
- WireGuard 配置
- BBR/sysctl 配置
