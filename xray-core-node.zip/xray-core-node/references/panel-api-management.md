# 面板 API 管理

用于把本 skill 的 Xray 配置能力接到可用的管理面板 API。不同版本 API 路径可能不同，先做能力发现，再做读写。

## 连接信息

收集：

- 面板 URL
- API Token
- 可选反代 API Key
- 当前 Profile / Host / Node ID

保存策略：

- 本次会话优先
- 本地缓存需明确说明路径
- 输出日志自动脱敏 token

## 能力发现

连接后依次读取：

```text
profiles / config-profiles
hosts / nodes
inbounds
outbounds
node plugins
users
user activity
request history
access logs
```

失败项记录：

```text
模块名
HTTP 状态
错误摘要
请求路径
是否影响主流程
```

## Profile 管理

动作：

- 读取配置列表
- 读取选中配置
- 新建配置
- 更新配置
- 应用到节点
- 应用前备份
- 失败回滚

应用前保存：

```text
profile_id
profile_name
old_config_hash
new_config_hash
changed_inbounds
changed_outbounds
changed_rules
timestamp
```

## Host / 节点管理

动作：

- 读取节点列表
- 新建节点
- 修改节点
- 删除节点
- 绑定 Profile
- 读取节点入站
- 检查节点版本
- 检查最后在线时间

快速创建节点时预设：

```text
节点名
协议
端口
Profile
入站数量
防护策略
```

## Node Plugins

可视化预设：

- 入站过滤
- 出站过滤
- 私有/保留 IP 拦截
- 危险端口拦截
- BT 阻断
- 连接断开策略
- 共享列表

生成原则：

- 默认展示开关和预设，不要求用户手写 JSON。
- 插件名允许用户修改。
- 与 Xray routing 重叠的规则优先放到 routing 中统一管理。

## 用户活动

优先读取面板原生能力：

```text
用户列表
当前客户端 IP
最后活动时间
请求历史
访问记录
设备 / HWID
```

如果面板 API 返回空，提示可能原因：

- 节点未上报
- 节点版本或权限不足
- 日志模块未启用
- 当前连接已经关闭
- API 路径变化

## 错误报告

生成错误报告时包含：

```text
操作名称
面板 URL 主机名
Profile / Host ID
应用前配置摘要
应用后配置摘要
变更列表
HTTP 状态
错误响应摘要
回滚结果
最近服务日志
```

敏感字段脱敏：

```text
token
password
uuid
privateKey
shortId
server address
user id
```
