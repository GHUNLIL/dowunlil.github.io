# 链路转发与组网

用于规划多服务器链路、端口转发、WireGuard 组网和链式代理。

## 角色

- 入口：客户端连接的机器，提供 VLESS、SS2022、HY2、订阅
- 中继：承接入口流量并转发
- 专线节点：低延迟内网或专线转发
- 落地：最终出口，可提供 SOCKS5/Mixed/HTTP/Xray inbound
- 管理节点：放订阅、日志、监控或面板

## 技术选择

```text
低延迟透明转发：nftables DNAT/SNAT/MASQUERADE
固定两点组网：WireGuard
服务级分流：Xray routing + socks/http/freedom outbounds
公网高丢包抗抖动：HY2/TUIC/KCP
临时协议转换：gost
```

## 链式代理

```text
client → entry inbound → DIRECT
client → entry inbound → SOCKS5 outbound →落地出口
client → entry inbound → Google rule → SOCKS5 outbound A
client → entry inbound → AI rule → SOCKS5 outbound B
```

SOCKS5 出站见 `protocol-templates.md`。

## nftables 端口转发

```nft
table ip xray_forward {
  chain prerouting {
    type nat hook prerouting priority dstnat; policy accept;
    tcp dport { PORTS } dnat to TARGET_IP
    udp dport { PORTS } dnat to TARGET_IP
  }
  chain postrouting {
    type nat hook postrouting priority srcnat; policy accept;
    ip daddr TARGET_IP masquerade
  }
}
```

启用转发：

```bash
sysctl -w net.ipv4.ip_forward=1
```

持久化：

```bash
/etc/nftables.conf
systemctl enable --now nftables
```

验证：

```bash
nft list ruleset
sysctl -n net.ipv4.ip_forward
conntrack -L 2>/dev/null | head
ss -lntup
```

## WireGuard 双机模板

服务端：

```ini
[Interface]
Address = WG_SERVER_CIDR
ListenPort = WG_PORT
PrivateKey = SERVER_PRIVATE_KEY

[Peer]
PublicKey = PEER_PUBLIC_KEY
AllowedIPs = WG_PEER_IP/32
PersistentKeepalive = 25
```

客户端：

```ini
[Interface]
Address = WG_PEER_CIDR
PrivateKey = PEER_PRIVATE_KEY

[Peer]
PublicKey = SERVER_PUBLIC_KEY
Endpoint = SERVER_PUBLIC_IP:WG_PORT
AllowedIPs = WG_SERVER_IP/32
PersistentKeepalive = 25
```

出口 NAT：

```bash
nft add table ip wg_nat
nft 'add chain ip wg_nat postrouting { type nat hook postrouting priority srcnat; policy accept; }'
nft add rule ip wg_nat postrouting ip saddr WG_SUBNET oifname "WAN_IFACE" masquerade
```

验证：

```bash
wg show
ip addr show wg0
ping -c 3 WG_PEER_IP
```

## 多服务器执行顺序

1. 收集每台机器：名称、角色、SSH、内网/公网地址、端口、系统。
2. 生成链路图、端口表、回滚表。
3. 从落地开始配置。
4. 配置中继和专线转发。
5. 配置入口协议和订阅。
6. 逐跳测试，再做端到端测试。

## 输出

```text
链路图
每台机器改动
端口表
防火墙规则
订阅链接
验证结果
回滚命令
```
