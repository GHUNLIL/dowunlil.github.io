# 路由分流规则

用于生成 Xray `routing.rules`。规则目标支持任意 outbound tag，例如 `DIRECT`、`BLOCK`、`OUT_SOCKS5_A`、`OUT_HTTP_B`、`OUT_WG_C`。

## 规则模型

```text
inboundTag → 默认 outboundTag
inboundTag + domain/ip/port/protocol → 指定 outboundTag
全局 domain/ip/port/protocol → 指定 outboundTag
```

## 推荐顺序

1. DNS 53 劫持
2. 私有/保留 IP、危险端口、BT/PT
3. 国内 App 上报/埋点
4. 广告追踪、博彩、IP 检测站
5. Google Login / OAuth
6. Google Search / Maps / YouTube / Gmail / Gemini
7. AI 服务
8. 流媒体、社交、支付、电商、开发云
9. 自定义域名/IP 分流
10. inbound 默认出口

## 安全基础规则

DNS：

```json
{
  "type": "field",
  "network": "udp,tcp",
  "port": "53",
  "outboundTag": "DNS-OUT"
}
```

私有/保留 IP：

```json
{
  "type": "field",
  "ip": ["geoip:private"],
  "outboundTag": "BLOCK"
}
```

危险端口：

```json
{
  "type": "field",
  "port": "25,465,587,137,138,139,445,23,3389,5900",
  "outboundTag": "BLOCK"
}
```

BT/PT：

```json
{
  "type": "field",
  "protocol": ["bittorrent"],
  "outboundTag": "BLOCK"
}
```

国内 App 上报集合：

```text
report.meituan.com
analytics.meituan.com
logan.meituan.com
frep.meituan.net
report.dianping.com
analytics.dianping.com
log.weixin.qq.com
support.weixin.qq.com
szshort.weixin.qq.com
long.weixin.qq.com
alog.umeng.com
ulogs.umeng.com
umeng.com
umengcloud.com
bugly.qq.com
beacon.qq.com
log.tbs.qq.com
oth.eve.mdt.qq.com
data.mistat.xiaomi.com
tracking.miui.com
applog.snssdk.com
log.snssdk.com
mon.snssdk.com
hm.baidu.com
hmma.baidu.com
afd.baidu.com
```

## Google 规则

Login / OAuth：

```text
accounts.google.com
oauth2.googleapis.com
apis.google.com
ssl.gstatic.com
www.gstatic.com
gstatic.com
googleapis.com
googleusercontent.com
```

Search：

```text
full:google.com
full:www.google.com
full:www.google.com.hk
full:www.google.co.jp
full:www.google.com.tw
full:www.google.com.sg
```

Maps：

```text
maps.google.com
googlemaps.com
maps.gstatic.com
maps.googleapis.com
```

YouTube：

```text
geosite:youtube
youtube.com
youtu.be
ytimg.com
googlevideo.com
ggpht.com
```

Gemini：

```text
gemini.google.com
bard.google.com
aistudio.google.com
ai.google.dev
generativelanguage.googleapis.com
```

Google 登录异常时，Login/OAuth 放在 Google 其他规则之前，并使用同一个稳定出口。

## AI 规则

```text
OpenAI / ChatGPT: chatgpt.com, openai.com, oaistatic.com, oaiusercontent.com
Claude: claude.ai, anthropic.com
Perplexity: perplexity.ai, pplx.ai
Microsoft Copilot: copilot.microsoft.com, copilot.cloud.microsoft, bing.com, edgeservices.bing.com, sydney.bing.com
Grok / xAI: grok.com, x.ai
Poe: poe.com, quora.com
Midjourney: midjourney.com, cdn.midjourney.com
DeepSeek: deepseek.com, deepseek.ai, deepseekapi.com
```

## 流媒体规则

```text
Netflix: geosite:netflix, netflix.com, nflxvideo.net, nflximg.net, nflxext.com, fast.com
Disney+ / Hulu: disneyplus.com, disney-plus.net, dssott.com, hulu.com, hulustream.com, espn.com, disneystreaming.com
Spotify: spotify.com, scdn.co, spotifycdn.com, audio-sp-tok.com, spotifycdn.net
```

## 自定义出口规则

将用户输入按行拆分。域名与 IP 分开写入：

```json
{
  "type": "field",
  "domain": ["domain:example.com"],
  "ip": ["203.0.113.0/24"],
  "outboundTag": "OUT_CUSTOM"
}
```

解析规则：

- `geoip:`、`geosite:`、`domain:`、`full:` 保留原样
- 普通域名转 `domain:`
- CIDR、IPv4、IPv6 写入 `ip`
- 空行和注释行跳过

## 生成注意

- 同一服务多条规则时，具体域名放在泛规则之前。
- `BLOCK` 规则应避免覆盖 Google Login/OAuth。
- inbound 默认兜底放到最后。
- 多服务器配置迁移时，确认目标机器存在每个 outbound tag。
