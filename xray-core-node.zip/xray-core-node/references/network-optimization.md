# 网络优化参考

此文件用于生成服务器网络优化方案。根据机器角色、系统版本、内存、带宽、协议和链路质量选择参数，输出可审计的命令清单、验证命令和回滚命令。

## 使用原则

- 先检查内核、发行版、虚拟化、内存、网卡、默认路由、当前拥塞控制和 qdisc。
- 先备份当前 sysctl、limits、modules、路由参数和相关 systemd 配置。
- 先记录基准数据，再一次只调整一组参数。
- 低内存机器使用保守缓冲区。
- 高带宽转发机提高 socket buffer、conntrack、backlog 和队列。
- UDP/HY2 场景关注 UDP buffer、conntrack UDP timeout、网卡队列和防火墙放行。
- WireGuard 场景同时检查 MTU、PersistentKeepalive、转发表和 NAT。
- 每次应用后运行验证命令，并保留回滚路径。

## 最优定义

BBR 调优的目标不是单次测速峰值，而是业务稳定性：

```text
吞吐：持续下载/上传速度接近线路能力
延迟：满载时 ping 抬升可控
丢包：无持续性丢包和重传风暴
抖动：HY2/WireGuard/UDP 场景稳定
CPU：软中断和单核占用不过载
内存：socket buffer 与 conntrack 不挤压系统内存
连接：多用户并发下无大量 reset、timeout、conntrack full
```

验收优先级：

1. 连接稳定
2. 满载延迟稳定
3. 多用户并发稳定
4. 持续吞吐
5. 单次峰值

## 主动询问

用户要求 BBR 或网络调优时，先问这些信息：

```text
机器角色：入口 / 中继 / 落地 / WireGuard / HY2 / 订阅
CPU 核数和内存
带宽上下行
主要协议：VLESS / SS2022 / HY2 / WireGuard / 转发
主要流量：TCP 多 / UDP 多 / 混合
用户数量和并发连接规模
链路 RTT：本地到服务器、服务器到落地、服务器到目标网站
是否有丢包或晚高峰波动
是否需要优先低延迟
是否允许重启网络或系统
```

缺省策略：

- 信息不全时使用均衡模板。
- 小内存机器先用低内存模板。
- HY2/WireGuard 先处理 UDP、MTU、防火墙和 conntrack。
- 高吞吐转发先处理 buffer、backlog、conntrack、RPS。

## 调优闭环

```text
1. 采集现状
2. 记录基准
3. 选择模板
4. 应用一组改动
5. 测试 3-5 分钟
6. 对比基准
7. 保留、微调或回滚
8. 输出最终参数和适用原因
```

每轮只改一类：

```text
BBR/qdisc
TCP buffer
UDP buffer
conntrack
backlog/somaxconn
RPS
MTU
initcwnd/initrwnd
```

回滚阈值：

```text
满载延迟比基准增加超过 30%
丢包或重传持续升高
CPU softirq 长时间占用过高
可用内存明显下降并触发 swap
conntrack 出现 table full
Xray/HY2 日志出现连续 timeout/reset
```

## 采集命令

```bash
uname -r
cat /etc/os-release
free -m
nproc
ip -br addr
ip route show default
ip -s link
ss -s
sysctl net.ipv4.tcp_congestion_control
sysctl net.core.default_qdisc
sysctl net.core.rmem_max
sysctl net.core.wmem_max
sysctl net.netfilter.nf_conntrack_max 2>/dev/null || true
lsmod | grep -E 'bbr|tcp_bbr|nf_conntrack' || true
tc -s qdisc show
nstat -az 2>/dev/null | grep -E 'TcpRetransSegs|TcpExtTCPSynRetrans|TcpExtTCPTimeouts|UdpInErrors|IpReasmFails' || true
dmesg | grep -i -E 'conntrack|nf_conntrack|oom|segfault' | tail -n 50 || true
```

## 基准测试

轻量检查：

```bash
ping -c 20 1.1.1.1
ping -c 20 8.8.8.8
curl -4 -o /dev/null -L --max-time 20 -w 'time=%{time_total} speed=%{speed_download}\n' https://speed.cloudflare.com/__down?bytes=50000000
ss -ti | head -n 80
```

有自建测试端时使用 iperf3：

```bash
iperf3 -c TEST_SERVER -t 30 -P 4
iperf3 -c TEST_SERVER -t 30 -P 4 -R
iperf3 -c TEST_SERVER -u -b 50M -t 30
```

Xray/HY2 业务测试：

```bash
journalctl -u xray -n 100 --no-pager
journalctl -u hysteria-server.service -n 100 --no-pager
tail -n 100 /var/log/xray/error.log
```

记录表：

```text
项目 | 基准 | 调整后 | 变化 | 结论
下载吞吐
上传吞吐
空载 ping
满载 ping
丢包
重传
CPU softirq
内存
conntrack
业务日志
```

## BBR 版本选择

默认使用当前内核自带 `bbr`，搭配 `fq`。

选择策略：

```text
稳定通用：bbr + fq
低延迟排队管理：bbr + fq_codel 或 cake，需要明确出口限速场景
高风险内核替换：只在用户明确要求、可回滚、可重启时规划
```

检查可用算法：

```bash
sysctl net.ipv4.tcp_available_congestion_control
sysctl net.core.default_qdisc
```

qdisc 说明：

- `fq` 是 BBR 常规搭配。
- `fq_codel` 适合降低排队延迟。
- `cake` 适合网关/路由器出口整形，需要知道真实带宽。
- 纯代理服务器优先 `fq`，再按测试结果调整。

## 参数选择

按角色选模板：

```text
小内存单节点：低内存模板
普通单节点：均衡模板
多用户订阅入口：均衡模板 + conntrack 上调
大带宽中继：高吞吐转发模板
HY2/UDP：UDP/HY2 模板 + MTU 检查
WireGuard：UDP/HY2 模板 + MTU + NAT/路由检查
```

缓冲区梯度：

```text
低内存：16M
普通：64M
中高带宽：128M
大带宽转发：256M
```

conntrack 梯度：

```text
轻量：131072
普通：262144
多用户：524288
高并发转发：1048576
```

内存保护：

- 512 MB 机器使用低内存模板。
- 1 GB 机器通常不超过 64M socket buffer。
- 2 GB 机器可用 64M-128M。
- 4 GB 以上再考虑 256M 和更高 conntrack。

## BBR 基础配置

适用于常规 Xray、SS2022、VLESS Reality、订阅服务和普通转发节点。

```conf
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_no_metrics_save = 1
net.ipv4.tcp_notsent_lowat = 16384
```

模块加载：

```conf
tcp_bbr
nf_conntrack
```

验证：

```bash
sysctl -n net.ipv4.tcp_congestion_control
sysctl -n net.core.default_qdisc
lsmod | grep bbr
```

## 均衡模板

适合 1-2 核、1-2 GB 内存、普通代理节点。

```conf
net.core.somaxconn = 4096
net.core.netdev_max_backlog = 16384
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.rmem_default = 1048576
net.core.wmem_default = 1048576
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.ipv4.udp_rmem_min = 8192
net.ipv4.udp_wmem_min = 8192
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_max_tw_buckets = 2000000
net.ipv4.ip_local_port_range = 10240 65535
net.netfilter.nf_conntrack_max = 262144
net.netfilter.nf_conntrack_tcp_timeout_established = 7440
net.netfilter.nf_conntrack_udp_timeout = 60
net.netfilter.nf_conntrack_udp_timeout_stream = 180
```

## 高吞吐转发模板

适合多用户订阅、链式代理中继、大带宽端口转发。

```conf
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 250000
net.core.optmem_max = 25165824
net.core.rmem_max = 268435456
net.core.wmem_max = 268435456
net.core.rmem_default = 8388608
net.core.wmem_default = 8388608
net.ipv4.tcp_rmem = 4096 87380 268435456
net.ipv4.tcp_wmem = 4096 65536 268435456
net.ipv4.udp_mem = 65536 131072 262144
net.ipv4.udp_rmem_min = 16384
net.ipv4.udp_wmem_min = 16384
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_max_tw_buckets = 4000000
net.ipv4.ip_local_port_range = 10000 65535
net.netfilter.nf_conntrack_max = 1048576
net.netfilter.nf_conntrack_buckets = 262144
net.netfilter.nf_conntrack_tcp_timeout_established = 7440
net.netfilter.nf_conntrack_tcp_timeout_time_wait = 30
net.netfilter.nf_conntrack_udp_timeout = 30
net.netfilter.nf_conntrack_udp_timeout_stream = 120
```

## UDP/HY2 模板

适合 HY2、WireGuard、游戏、语音、实时 UDP 代理。

```conf
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 4194304
net.core.wmem_default = 4194304
net.ipv4.udp_rmem_min = 16384
net.ipv4.udp_wmem_min = 16384
net.netfilter.nf_conntrack_udp_timeout = 30
net.netfilter.nf_conntrack_udp_timeout_stream = 180
net.ipv4.ipfrag_time = 15
net.ipv4.ipfrag_high_thresh = 67108864
net.ipv4.ipfrag_low_thresh = 50331648
```

HY2 排查重点：

```bash
ss -lunp
journalctl -u hysteria-server.service -n 100 --no-pager
nft list ruleset
```

MTU 检查：

```bash
ping -M do -s 1472 1.1.1.1
ping -M do -s 1372 1.1.1.1
```

如果大包失败，HY2/WireGuard 优先降低 MTU 或检查路径分片。

## 低内存模板

适合 512 MB 或更小内存机器。

```conf
net.core.somaxconn = 2048
net.core.netdev_max_backlog = 8192
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.rmem_default = 524288
net.core.wmem_default = 524288
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216
net.netfilter.nf_conntrack_max = 131072
```

## RPS 多核网卡处理

适合多核机器。根据 CPU 数量生成掩码，写入所有 `rx-*` 队列。

检查：

```bash
nproc
find /sys/class/net -path '*/queues/rx-*/rps_cpus' -type f
```

应用逻辑：

```text
1 核：跳过
2 核：3
4 核：f
8 核：ff
16 核：ffff
```

生成 systemd 服务：

```ini
[Unit]
Description=Apply RPS CPU mask
After=network.target

[Service]
Type=oneshot
ExecStart=/bin/sh -c 'for f in /sys/class/net/*/queues/rx-*/rps_cpus; do echo CPU_MASK > "$f" 2>/dev/null || true; done'

[Install]
WantedBy=multi-user.target
```

## initcwnd / initrwnd

适合短连接多、跨境高 RTT、订阅/API 请求多的节点。

检查默认路由：

```bash
ip route show default
```

临时应用：

```bash
ip route change default via GATEWAY dev IFACE initcwnd 10 initrwnd 10
```

持久化可用 systemd timer 或 network dispatcher。应用前确认默认路由稳定。

## 文件写入建议

sysctl：

```bash
/etc/sysctl.d/99-xray-network.conf
```

modules：

```bash
/etc/modules-load.d/99-xray-network.conf
```

limits：

```bash
/etc/security/limits.d/99-xray-network.conf
```

工作目录：

```bash
/etc/xray-node-optimizer/
```

## 备份

```bash
BACKUP_DIR="/root/xray-node-backup/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"
sysctl -a > "$BACKUP_DIR/sysctl-before.txt" 2>/dev/null || true
cp -a /etc/sysctl.conf "$BACKUP_DIR/" 2>/dev/null || true
cp -a /etc/sysctl.d "$BACKUP_DIR/sysctl.d" 2>/dev/null || true
cp -a /etc/modules-load.d "$BACKUP_DIR/modules-load.d" 2>/dev/null || true
cp -a /etc/security/limits.d "$BACKUP_DIR/limits.d" 2>/dev/null || true
```

## 应用

```bash
modprobe tcp_bbr 2>/dev/null || true
modprobe nf_conntrack 2>/dev/null || true
sysctl --system
```

## 验证

```bash
sysctl -n net.ipv4.tcp_congestion_control
sysctl -n net.core.default_qdisc
sysctl -n net.core.rmem_max
sysctl -n net.core.wmem_max
sysctl -n net.netfilter.nf_conntrack_max 2>/dev/null || true
ss -s
tc -s qdisc show
nstat -az 2>/dev/null | grep -E 'TcpRetransSegs|TcpExtTCPTimeouts|UdpInErrors|IpReasmFails' || true
systemctl --failed
```

## 回滚

```bash
cp -a "$BACKUP_DIR/sysctl.d/." /etc/sysctl.d/ 2>/dev/null || true
cp -a "$BACKUP_DIR/modules-load.d/." /etc/modules-load.d/ 2>/dev/null || true
cp -a "$BACKUP_DIR/limits.d/." /etc/security/limits.d/ 2>/dev/null || true
sysctl --system
systemctl daemon-reload
```

## 输出给用户

完成网络优化时输出：

```text
已应用模板和选择原因
备份目录
关键参数
基准结果
调整后结果
保留/回滚判断
回滚命令
```
