# 信息收集、预检与验收

用于复杂部署前主动收集信息，生成配置矩阵，降低多用户、多机器、多协议、多分流场景的失败概率。

## 触发场景

出现以下任一情况，先进入信息收集流程：

- 多台服务器串联
- 多用户或订阅
- 多协议同时启用
- 多出口分流
- 端口转发、WireGuard、nftables、SOCKS/HTTP 链式出口
- 改动面板 Profile、Host、Node Plugin
- 用户担心断网、不可用、配置冲突

## 主动提问

先问目标：

```text
你这次想做的是：
1. 新建节点
2. 修改现有节点
3. 多用户订阅
4. 多服务器链路
5. 分流和屏蔽规则
6. 防火墙/端口/IP 限制
7. 排错恢复
```

再按场景问细节。问题要一次问清，但保持中文易懂。

## 服务器清单

每台机器收集：

```text
机器备注名
角色：入口 / 中继 / 专线 / 落地 / 管理
SSH 地址、端口、登录方式
系统发行版和架构
公网 IP / 内网 IP / 专线 IP
当前 SSH 端口
已有服务：Xray / HY2 / Docker / 面板 / Nginx / WireGuard
已有监听端口
是否允许重启服务
```

## 用户与订阅

收集：

```text
用户数量
每个用户备注名
启用协议：VLESS / SS2022 / HY2 / Mixed
是否每个用户独立端口
是否需要到期时间
是否需要流量限制
订阅域名或订阅端口
客户端类型：sing-box / v2rayN / Shadowrocket / Clash Meta / 其他
```

## 协议参数

收集：

```text
指定端口或随机端口
Reality SNI / dest 偏好
SS2022 aes-128 或 aes-256
HY2 是否使用证书
是否需要 UDP 优先
是否需要混合 SOCKS/HTTP
```

缺省策略：

- 未指定端口时随机高位端口并避让占用。
- 未指定密钥时全部随机生成。
- 未指定 SNI 时从可达候选里选择。
- UDP 场景检查防火墙、协议和内核参数。

## 链路与出口

收集：

```text
默认出口
每条线路的入口、中继、落地顺序
每一跳使用公网、内网还是专线地址
落地出口类型：DIRECT / SOCKS5 / HTTP / Xray / WireGuard
是否需要备用线路
是否需要某些服务固定出口
```

生成链路矩阵：

```text
线路名 | 用户/入口 | 入口协议 | 中继方式 | 落地出口 | 默认出口 | 备用
```

## 分流规则

收集：

```text
Google Login/OAuth 出口
Google Search 出口
Google Maps 出口
YouTube 出口
Gemini 出口
OpenAI / Claude / 其他 AI 出口
Netflix / Disney / Spotify 出口
社交软件出口
国内域名/IP 策略
广告/上报/BT/危险端口策略
自定义域名/IP 到指定出口
兜底出口
```

生成规则矩阵：

```text
优先级 | 服务/规则 | inbound | domain/ip/port/protocol | outbound | 说明
```

## 防火墙与访问控制

收集：

```text
SSH 端口
允许访问 SSH 的 IP/CIDR
允许访问节点端口的 IP/CIDR
需要放行的 TCP/UDP 端口
需要屏蔽的 IP/CIDR
国家白名单/黑名单
是否保留 Ping
Docker 容器端口是否需要限制来源
```

生成端口矩阵：

```text
机器 | 协议 | 端口 | TCP/UDP | 来源限制 | 用途
```

## 面板与 API

收集：

```text
面板 URL
API Token
当前 Profile
目标 Host / Node
是否新建 Profile
是否绑定 Host
是否应用 Node Plugin
是否读取用户活动和请求历史
```

应用前记录：

```text
旧配置摘要
新配置摘要
新增/删除/修改的 inbound
新增/删除/修改的 outbound
新增/删除/修改的 rules
目标 Profile / Host
回滚点
```

## 风险预检

应用前检查：

```text
端口冲突
outbound tag 是否存在
inbound tag 是否重复
规则顺序是否覆盖关键登录规则
Google Login/OAuth 是否被 BLOCK
geosite/geoip 是否存在
SS2022 method 与 key 长度是否匹配
HY2 UDP 是否放行
WireGuard AllowedIPs 是否冲突
nftables 是否保留 SSH
面板 Profile/Host 是否选对
```

## 应用策略

优先顺序：

1. 只读检查
2. 备份
3. 写入临时配置
4. 本地测试配置
5. 应用到单台或单个 Profile
6. 健康检查
7. 批量应用
8. 输出验收结果

复杂场景使用分批应用：

```text
先落地
再中继
再入口
最后订阅和分流
```

## 验收清单

应用后逐项检查：

```text
服务 active
端口监听
Xray 配置测试通过
HY2 UDP 监听
WireGuard handshake
nftables 规则存在
订阅可拉取
客户端链接可解析
默认出口 IP 正确
指定服务出口 IP 正确
Google 登录正常
YouTube/AI/流媒体按预期分流
广告/BT/危险端口按预期阻断
日志无连续 error
```

## 错误处理

失败时输出：

```text
失败步骤
错误摘要
最近改动
影响范围
回滚动作
回滚结果
下一步建议
```

回滚后再次验证：

```text
服务状态
端口监听
旧订阅是否可用
关键网站是否恢复
```

## 输出格式

执行前输出：

```text
拓扑图
配置矩阵
端口矩阵
规则矩阵
风险预检
计划步骤
回滚点
```

执行后输出：

```text
已完成步骤
配置摘要
订阅/节点信息
验收结果
日志摘要
回滚路径
```
