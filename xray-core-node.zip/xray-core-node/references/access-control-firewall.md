# 访问控制与防火墙

用于配置端口放行、IP 限制、国家白名单/黑名单、单端口屏蔽、容器端口限制和 SSH 安全。

## 基本原则

- SSH 端口始终纳入放行列表。
- 先输出当前 SSH 来源 IP 和回退命令。
- nftables 作为主要规则生成目标。
- Docker 场景补充 `DOCKER-USER` 链。
- 旧系统可生成 iptables/ipset 兼容方案。

## 仅放行指定端口

```nft
table inet access_control {
  chain input {
    type filter hook input priority filter; policy drop;
    ct state established,related accept
    iif "lo" accept
    tcp dport { SSH_PORT, TCP_PORTS } accept
    udp dport { UDP_PORTS } accept
    ip protocol icmp accept
  }
}
```

## 指定 IP + 指定端口

```nft
table inet access_control {
  chain input {
    type filter hook input priority filter; policy drop;
    ct state established,related accept
    iif "lo" accept

    ip saddr { ADMIN_IPS } tcp dport { SSH_PORT } accept
    ip saddr { CLIENT_IPS } tcp dport { TCP_PORTS } accept
    ip saddr { CLIENT_IPS } udp dport { UDP_PORTS } accept
    ip saddr { BLOCK_IPS } drop
  }
}
```

## 国家访问控制

数据来源可采用 ipdeny aggregated zone，生成 set：

```nft
define allow_tcp = { SSH_PORT, SERVICE_PORTS }

table inet country_acl {
  set country_allow {
    type ipv4_addr
    flags interval
    elements = { COUNTRY_CIDRS }
  }

  chain input {
    type filter hook input priority filter; policy drop;
    ct state established,related accept
    iif "lo" accept
    ip saddr @country_allow tcp dport $allow_tcp accept
  }
}
```

## Docker 容器端口限制

```bash
iptables -I DOCKER-USER -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -I DOCKER-USER -s ALLOW_CIDR -p tcp --dport PORT -j ACCEPT
iptables -A DOCKER-USER -p tcp --dport PORT -j DROP
```

## Fail2ban

SSH jail：

```ini
[sshd]
enabled = true
port = SSH_PORT
filter = sshd
logpath = %(sshd_log)s
maxretry = 5
findtime = 10m
bantime = 1h
```

Xray/HY2 可按认证失败、高频连接、异常路径写自定义 filter。

## 常用动作

```text
open-port PORT[/tcp|udp]
close-port PORT[/tcp|udp]
allow-ip CIDR
block-ip CIDR
allow-ip-port CIDR PORTS
block-ip-port CIDR PORTS
allow-country CC PORTS
block-country CC
```

## 验证

```bash
nft list ruleset
iptables -S
iptables -S DOCKER-USER 2>/dev/null || true
ss -lntup
fail2ban-client status
```

## 回滚

- 保留应用前的 `/etc/nftables.conf`
- 保留 iptables-save 输出
- 保留 fail2ban jail 配置备份
- 应用新规则后保持当前 SSH 会话，另开连接测试
