# 运维执行手册

用于服务器检查、安装、升级、故障恢复、日志分析和发布前脱敏。

## 标准执行顺序

1. 明确目标。
2. 收集服务器和角色。
3. 只读检查。
4. 生成计划和回滚点。
5. 备份。
6. 写入配置。
7. 测试配置。
8. 重启服务。
9. 验证端口、日志和订阅。
10. 输出结果和回滚命令。

## 只读检查

```bash
whoami
hostnamectl 2>/dev/null || hostname
cat /etc/os-release
uname -a
ip -br addr
ip route show default
ss -lntup
systemctl is-active xray 2>/dev/null || true
systemctl is-active hysteria-server.service 2>/dev/null || true
nft list ruleset 2>/dev/null || true
iptables -S 2>/dev/null || true
```

## 安装 Xray

```text
1. 检查架构
2. 下载官方 release
3. 校验文件
4. 安装到 /usr/local/bin/xray
5. 安装 geodata
6. 写 systemd unit
7. 写配置
8. xray run -test
9. systemctl enable --now xray
```

## 升级

```text
备份二进制和配置
下载新版本
替换二进制
测试配置
重启服务
查看日志
异常时恢复旧二进制和配置
```

## 日志

```bash
journalctl -u xray -n 100 --no-pager
journalctl -u hysteria-server.service -n 100 --no-pager
tail -n 100 /var/log/xray/access.log
tail -n 100 /var/log/xray/error.log
```

## 常见故障

VLESS Reality：

- UUID、flow、SNI、publicKey、shortId 不一致
- Reality dest 不可达
- 端口被防火墙拦截
- 客户端 fingerprint 不匹配

SS2022：

- method 和 key 长度不匹配
- UDP 未开启
- 客户端不支持 2022

HY2：

- UDP 端口未放行
- 证书路径错误
- ACL 误拦截
- 服务端日志出现 auth failed 或 timeout

分流：

- 规则顺序错误
- outbound tag 不存在
- geosite/geoip 文件缺失
- Google Login/OAuth 被广告或兜底规则覆盖

## 发布前脱敏

检查：

```text
真实 IP
真实域名
账号密码
API token
UUID
privateKey
shortId
订阅 token
服务商名称
历史项目名
```

替换为：

```text
HOST
DOMAIN
TOKEN
UUID
PRIVATE_KEY
SHORT_ID
NODE_NAME
```
