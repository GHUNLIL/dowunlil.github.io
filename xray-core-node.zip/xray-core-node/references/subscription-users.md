# 订阅与用户管理

用于单用户、多用户、拼接多个协议、订阅链接生成和轻量管理器设计。

## 用户模型

```json
{
  "name": "USER_NAME",
  "enabled": true,
  "uuid": "UUID",
  "ssPassword": "SS2022_KEY",
  "hy2Password": "HY2_PASSWORD",
  "remark": "NODE_REMARK",
  "limits": {
    "expireAt": null,
    "trafficGB": null
  }
}
```

## 订阅内容

支持：

- VLESS Reality Vision
- SS2022
- Hysteria2
- SOCKS/Mixed 辅助链接

输出格式：

- raw links
- base64 subscription
- sing-box/clash meta 可扩展模板

## 轻量管理命令

```bash
nodectl init
nodectl status
nodectl list
nodectl add USER
nodectl del USER
nodectl enable USER
nodectl disable USER
nodectl sub USER
nodectl sub USER --show-links
nodectl apply
```

## 管理器状态

```json
{
  "version": 1,
  "nodeName": "NODE_NAME",
  "subscription": {
    "listen": "127.0.0.1",
    "port": 8088,
    "token": "TOKEN",
    "path": "/sub/TOKEN"
  },
  "users": []
}
```

## 订阅服务

systemd：

```ini
[Unit]
Description=Xray node subscription service
After=network.target

[Service]
ExecStart=/usr/local/bin/nodectl serve-sub
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

Nginx 反代：

```nginx
location /sub/ {
    proxy_pass http://127.0.0.1:SUB_PORT;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

## 应用流程

1. 修改用户状态。
2. 渲染 Xray/HY2 配置。
3. 配置测试。
4. 重启服务。
5. 生成订阅。
6. 抽样验证链接。
7. 异常回滚。

## 输出

```text
用户数量
启用用户
协议组合
订阅地址
服务状态
最近日志
```
