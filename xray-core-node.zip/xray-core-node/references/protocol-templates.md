# 协议模板

用于生成官方 Xray Core 与 Hysteria2 配置。所有示例均使用占位符，部署时随机生成 UUID、密钥、shortId、密码、token 和非指定端口。

## 通用原则

- 先确认端口占用、系统架构、已有 Xray/HY2 服务和防火墙状态。
- 每次写入前备份旧配置。
- Xray 配置先执行 `xray run -test`。
- 入站 tag、出站 tag、用户 email、订阅备注保持可读，内部敏感值随机。
- UDP 需求明确时检查协议、入站、出站、防火墙和内核参数是否都支持 UDP。

## VLESS Reality Vision

适合常规 TCP 节点。

```json
{
  "tag": "IN_VLESS_REALITY",
  "listen": "0.0.0.0",
  "port": PORT,
  "protocol": "vless",
  "settings": {
    "clients": [
      {
        "id": "UUID",
        "flow": "xtls-rprx-vision",
        "email": "USER_NAME"
      }
    ],
    "decryption": "none"
  },
  "streamSettings": {
    "network": "tcp",
    "security": "reality",
    "realitySettings": {
      "dest": "REALITY_DEST:443",
      "serverNames": ["REALITY_SNI"],
      "privateKey": "REALITY_PRIVATE_KEY",
      "shortIds": ["REALITY_SHORT_ID"]
    }
  },
  "sniffing": {
    "enabled": true,
    "destOverride": ["http", "tls", "quic"]
  }
}
```

客户端链接字段：

```text
vless://UUID@HOST:PORT?type=tcp&security=reality&pbk=PUBLIC_KEY&fp=chrome&sni=REALITY_SNI&sid=SHORT_ID&flow=xtls-rprx-vision#NODE_NAME
```

Reality key 生成：

```bash
/usr/local/bin/xray x25519
openssl rand -hex 8
```

## Shadowsocks 2022

推荐：

- `2022-blake3-aes-128-gcm`
- `2022-blake3-aes-256-gcm`

密钥长度：

- aes-128：16 字节 base64
- aes-256：32 字节 base64

生成：

```bash
openssl rand -base64 16
openssl rand -base64 32
```

入站模板：

```json
{
  "tag": "IN_SS2022",
  "listen": "0.0.0.0",
  "port": PORT,
  "protocol": "shadowsocks",
  "settings": {
    "method": "2022-blake3-aes-128-gcm",
    "password": "BASE64_KEY",
    "network": "tcp,udp",
    "clients": []
  },
  "sniffing": {
    "enabled": true,
    "destOverride": ["http", "tls", "quic"]
  }
}
```

多用户建议使用不同端口或外部用户管理器记录用户备注。

## SOCKS5 / Mixed / HTTP

适合落地出口、链式代理或本地转发。

Mixed 入站：

```json
{
  "tag": "IN_MIXED",
  "listen": "0.0.0.0",
  "port": PORT,
  "protocol": "mixed",
  "settings": {
    "auth": "password",
    "udp": true,
    "accounts": [
      {"user": "USER", "pass": "PASS"}
    ]
  },
  "sniffing": {
    "enabled": true,
    "destOverride": ["http", "tls", "quic"]
  }
}
```

SOCKS5 出站：

```json
{
  "tag": "OUT_SOCKS5",
  "protocol": "socks",
  "settings": {
    "servers": [
      {
        "address": "HOST",
        "port": PORT,
        "users": [{"user": "USER", "pass": "PASS"}]
      }
    ]
  }
}
```

HTTP 出站：

```json
{
  "tag": "OUT_HTTP",
  "protocol": "http",
  "settings": {
    "servers": [
      {
        "address": "HOST",
        "port": PORT,
        "users": [{"user": "USER", "pass": "PASS"}]
      }
    ]
  }
}
```

## Hysteria2

Hysteria2 使用独立服务配置。

```yaml
listen: :PORT
auth:
  type: password
  password: PASSWORD
tls:
  cert: /etc/hysteria/server.crt
  key: /etc/hysteria/server.key
masquerade:
  type: proxy
  proxy:
    url: https://REALITY_SNI/
    rewriteHost: true
```

多用户：

```yaml
auth:
  type: userpass
  userpass:
    USER_A: PASS_A
    USER_B: PASS_B
```

ACL 示例：

```text
reject(all, udp/443)
direct(all)
```

排查：

```bash
systemctl is-active hysteria-server.service
ss -lunp
journalctl -u hysteria-server.service -n 100 --no-pager
```

## 基础出站

```json
[
  {
    "tag": "DIRECT",
    "protocol": "freedom",
    "settings": {"domainStrategy": "UseIPv4v6"}
  },
  {
    "tag": "BLOCK",
    "protocol": "blackhole"
  },
  {
    "tag": "DNS-OUT",
    "protocol": "dns"
  }
]
```

## DNS

```json
{
  "servers": ["1.1.1.1", "1.0.0.1", "8.8.8.8"],
  "queryStrategy": "UseIP"
}
```

规则中将 53 端口置顶劫持到 `DNS-OUT`。

## 生成后验证

```bash
/usr/local/bin/xray run -test -config /usr/local/etc/xray/config.json
systemctl restart xray
systemctl is-active xray
ss -lntup
journalctl -u xray -n 80 --no-pager
```
