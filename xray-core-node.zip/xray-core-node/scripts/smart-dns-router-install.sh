#!/usr/bin/env bash
# =====================================================================
# Smart DNS Router  智能 DNS 路由调度脚本
# 单文件 · 纯 Bash · BBR 风格
#
# 思路: TCP Ping 你的"主目标 IP", 当延迟连续 N 次超阈值就调华为云 API
#       把域名 A 记录改到"备目标 IP", 持续监控直到主目标恢复再切回。
#
# 适用: Debian / Ubuntu
# 用法: bash install.sh    (安装后任意时刻输入 dns-router 进入同一菜单)
# =====================================================================
set -uo pipefail

VERSION="2.2"
INSTALL_DIR=/opt/dns-router
DAEMON_BIN=$INSTALL_DIR/daemon.sh
SELF_PATH=/usr/local/bin/dns-router
ENV_FILE=/etc/dns-router.env
CONFIG_DIR=/etc/dns-router
CONFIG_FILE=$CONFIG_DIR/config.json
SERVICE=dns-router
UNIT_FILE=/etc/systemd/system/$SERVICE.service
SERVICE_USER=dnsrouter

# ---------------------------------------------------------------------
# 颜色 + 输出工具
# ---------------------------------------------------------------------
if [[ -t 1 ]]; then
    R='\033[31m'; G='\033[32m'; Y='\033[33m'; C='\033[36m'
    BOLD='\033[1m'; DIM='\033[2m'; N='\033[0m'
else
    R=''; G=''; Y=''; C=''; BOLD=''; DIM=''; N=''
fi
红() { echo -e "${R}$*${N}"; }
绿() { echo -e "${G}$*${N}"; }
黄() { echo -e "${Y}$*${N}"; }
青() { echo -e "${C}$*${N}"; }
亮() { echo -e "${BOLD}$*${N}"; }
暗() { echo -e "${DIM}$*${N}"; }

报错() { echo -e "${R}[错误]${N} $*" >&2; }
提示() { echo -e "${G}[√]${N} $*"; }
警告() { echo -e "${Y}[!]${N} $*"; }
信息() { echo -e "${C}[i]${N} $*"; }

按键继续() { echo; read -n1 -srp "$(黄 '按任意键返回菜单...')"; echo; }
确认() {
    local r
    read -rp "$(黄 "$1 [y/N]: ")" r || return 1
    [[ "$r" =~ ^[Yy] ]]
}
要求root() {
    if [[ $EUID -ne 0 ]]; then 报错 "请用 root 或 sudo 运行"; exit 1; fi
}

# ---------------------------------------------------------------------
# 状态检测
# ---------------------------------------------------------------------
已安装()    { [[ -f $UNIT_FILE && -x $DAEMON_BIN ]]; }
正运行()    { systemctl is-active --quiet "$SERVICE.service" 2>/dev/null; }
已开机自启() { systemctl is-enabled --quiet "$SERVICE.service" 2>/dev/null; }

任务数() {
    [[ -f $CONFIG_FILE ]] || { echo 0; return; }
    jq -r '.tasks | length' "$CONFIG_FILE" 2>/dev/null || echo 0
}
凭证已设置() {
    [[ -f $ENV_FILE ]] || return 1
    grep -q '^HUAWEI_AK=..*' "$ENV_FILE" && grep -q '^HUAWEI_SK=..*' "$ENV_FILE"
}

# ---------------------------------------------------------------------
# 输入校验
# ---------------------------------------------------------------------
校验ipv4() {
    [[ "$1" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || return 1
    local IFS=.; local -a p=($1)
    for x in "${p[@]}"; do (( x >= 0 && x <= 255 )) || return 1; done
}
校验域名() {
    [[ "$1" =~ ^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$ ]]
}
校验host端口() {
    [[ "$1" == *:* ]] || return 1
    local h="${1%:*}" p="${1##*:}"
    校验ipv4 "$h" || return 1
    [[ "$p" =~ ^[0-9]+$ ]] && (( p >= 1 && p <= 65535 ))
}

# ---------------------------------------------------------------------
# 华为云 DNS 线路代码/区域 → 中文显示
# ---------------------------------------------------------------------
华为地区名() {
    case "$1" in
        Huabei|NorthChina)  echo "华北地区" ;;
        Dongbei|Northeast)  echo "东北地区" ;;
        Huadong|EastChina)  echo "华东地区" ;;
        Huanan|SouthChina)  echo "华南地区" ;;
        Huazhong|CentralChina) echo "华中地区" ;;
        Xinan|Southwest)    echo "西南地区" ;;
        Xibei|Northwest)    echo "西北地区" ;;
        Northeast)         echo "东北" ;;
        NorthChina)        echo "华北" ;;
        EastChina)         echo "华东" ;;
        SouthChina)        echo "华南" ;;
        CentralChina)      echo "华中" ;;
        Southwest)         echo "西南" ;;
        Northwest)         echo "西北" ;;
        Beijing)           echo "北京" ;;  Shanghai)   echo "上海" ;;
        Tianjin)           echo "天津" ;;  Chongqing)  echo "重庆" ;;
        Hebei)             echo "河北" ;;  Shanxi)     echo "山西" ;;
        Henan)             echo "河南" ;;  Hubei)      echo "湖北" ;;
        Hunan)             echo "湖南" ;;  Guangdong)  echo "广东" ;;
        Guangxi)           echo "广西" ;;  Hainan)     echo "海南" ;;
        Sichuan)           echo "四川" ;;  Yunnan)     echo "云南" ;;
        Guizhou)           echo "贵州" ;;  Tibet|Xizang) echo "西藏" ;;
        Shaanxi)           echo "陕西" ;;  Gansu)      echo "甘肃" ;;
        Ningxia)           echo "宁夏" ;;  Qinghai)    echo "青海" ;;
        Xinjiang)          echo "新疆" ;;
        InnerMongolia|NeiMonggol|InnerMongol|Neimenggu) echo "内蒙古" ;;
        Liaoning)          echo "辽宁" ;;  Jilin)      echo "吉林" ;;
        Heilongjiang)      echo "黑龙江" ;;
        Jiangsu)           echo "江苏" ;;  Zhejiang)   echo "浙江" ;;
        Anhui)             echo "安徽" ;;  Fujian)     echo "福建" ;;
        Jiangxi)           echo "江西" ;;  Shandong)   echo "山东" ;;
        Taiwan)            echo "台湾" ;;
        HongKong|Hongkong) echo "香港" ;;  Macau|Macao) echo "澳门" ;;
        *)                 echo "$1" ;;
    esac
}
华为线路名() {
    local l="${1:-default_view}"
    # 顶级线路
    case "$l" in
        default|default_view) echo "全网默认"; return ;;
        CN|Mainland_China)   echo "中国大陆"; return ;;
        Abroad|Foreign)      echo "境外"; return ;;
        AP)                  echo "亚太地区"; return ;;
        EU)                  echo "欧洲"; return ;;
        OA)                  echo "大洋洲"; return ;;
        NA)                  echo "北美洲"; return ;;
        LA)                  echo "南美洲"; return ;;
        AF)                  echo "非洲"; return ;;
    esac
    # 运营商前缀解析: Dianxin / Liantong / Yidong / Tietong / Jiaoyuwang / Pengbo
    local op="${l%%_*}" suffix="${l#*_}"
    local op_zh=""
    case "$op" in
        Dianxin)    op_zh="电信" ;;
        Liantong)   op_zh="联通" ;;
        Yidong)     op_zh="移动" ;;
        Tietong)    op_zh="铁通" ;;
        Jiaoyuwang) op_zh="教育网" ;;
        Pengbo|Pengboshi) op_zh="鹏博士" ;;
    esac
    if [[ -n "$op_zh" && "$suffix" != "$l" ]]; then
        # 后缀可能是省/区域, 也可能是再嵌套 (例: Liantong_Northeast_Liaoning)
        local parts="" first=1
        while [[ -n "$suffix" ]]; do
            local p="${suffix%%_*}" rest="${suffix#*_}"
            [[ -z "$first" ]] && parts+="-"
            parts+=$(华为地区名 "$p")
            first=""
            [[ "$rest" == "$suffix" ]] && break
            suffix="$rest"
        done
        echo "${op_zh}-${parts}"
        return
    fi
    if [[ -n "$op_zh" ]]; then echo "$op_zh"; return; fi
    # 不能解析的就原样
    echo "$l"
}

# ---------------------------------------------------------------------
# 上下键菜单 (纯 bash, 读 ESC 序列)
# 用法: 箭头菜单 "标题" "选项1" "选项2" ...
# 选中: $SELECTED_INDEX (0-based), $SELECTED_VALUE
# 返回: 0=已确认  1=用户取消(q 键)
# ---------------------------------------------------------------------
SELECTED_INDEX=-1
SELECTED_VALUE=""
箭头菜单() {
    local title="$1"; shift
    local opts=("$@")
    local n=${#opts[@]} sel=0 key rest
    [[ $n -eq 0 ]] && { 报错 "无可选项"; return 1; }

    # 隐藏光标, Ctrl+C 时还原
    printf '\033[?25l' >/dev/tty
    trap 'printf "\033[?25h\n" >/dev/tty; trap - INT; return 130' INT

    while :; do
        clear
        echo
        青 "  $title"
        echo
        local i
        for ((i=0; i<n; i++)); do
            if (( i == sel )); then
                printf '    \033[1;36;7m ▶ %s \033[0m\n' "${opts[i]}"
            else
                printf '      %s\n' "${opts[i]}"
            fi
        done
        echo
        暗 "  ↑/↓ 移动  ·  Enter 确认  ·  q 取消"

        IFS= read -rsn1 key </dev/tty || break
        case "$key" in
            $'\x1b')
                read -rsn2 -t 0.1 rest </dev/tty || rest=""
                case "$rest" in
                    '[A') (( sel > 0 )) && sel=$((sel-1)) ;;
                    '[B') (( sel < n-1 )) && sel=$((sel+1)) ;;
                esac ;;
            'k'|'K') (( sel > 0 )) && sel=$((sel-1)) ;;
            'j'|'J') (( sel < n-1 )) && sel=$((sel+1)) ;;
            '')
                printf '\033[?25h' >/dev/tty
                trap - INT
                SELECTED_INDEX=$sel; SELECTED_VALUE="${opts[sel]}"
                return 0 ;;
            'q'|'Q')
                printf '\033[?25h' >/dev/tty
                trap - INT
                SELECTED_INDEX=-1; SELECTED_VALUE=""
                return 1 ;;
        esac
    done
    printf '\033[?25h' >/dev/tty
    trap - INT
    return 1
}

# ---------------------------------------------------------------------
# 华为云 API 调用 (用于菜单交互, 与守护进程内的实现独立)
# ---------------------------------------------------------------------
读取env() { [[ -f $ENV_FILE ]] || return; grep -E "^$1=" "$ENV_FILE" | head -1 | cut -d= -f2-; }

api_request() {
    # 入: METHOD URI QUERY [BODY] [SIGN_URI]
    #   SIGN_URI 可选, 用于签名计算; 不传则与 URI 一致
    #   华为 API Gateway 集合端点会把 URI 规范化为带末尾 '/' 后参与签名,
    #   但 URL 的注册路由不带 '/'。所以集合端点要 URL='/v2/zones' SIGN='/v2/zones/'
    local method="$1" uri="$2" query="${3:-}" body="${4:-}" sign_uri="${5:-$2}"
    local AK SK REGION
    AK=$(读取env HUAWEI_AK); SK=$(读取env HUAWEI_SK)
    REGION=$(读取env HUAWEI_REGION); [[ -z "$REGION" ]] && REGION="cn-north-1"
    [[ -z "$AK" || -z "$SK" ]] && { echo "AK/SK 未设置" >&2; return 1; }

    local API_HOST="dns.${REGION}.myhuaweicloud.com"
    local dt body_sha cr cr_sha sts sig auth url resp http body_text
    dt=$(date -u +%Y%m%dT%H%M%SZ)
    body_sha=$(printf '%s' "$body" | openssl dgst -sha256 -hex | awk '{print $NF}')
    local ch="content-type:application/json
host:${API_HOST}
x-sdk-content-sha256:${body_sha}
x-sdk-date:${dt}
"
    local sh="content-type;host;x-sdk-content-sha256;x-sdk-date"
    cr=$(printf '%s\n%s\n%s\n%s\n%s\n%s' "$method" "$sign_uri" "$query" "$ch" "$sh" "$body_sha")
    cr_sha=$(printf '%s' "$cr" | openssl dgst -sha256 -hex | awk '{print $NF}')
    sts=$(printf 'SDK-HMAC-SHA256\n%s\n%s' "$dt" "$cr_sha")
    sig=$(printf '%s' "$sts" | openssl dgst -sha256 -hmac "$SK" -hex | awk '{print $NF}')
    auth="SDK-HMAC-SHA256 Access=${AK}, SignedHeaders=${sh}, Signature=${sig}"

    url="https://${API_HOST}${uri}"
    [[ -n "$query" ]] && url="${url}?${query}"

    local args=(-sS --max-time 10 -w '\n%{http_code}' -X "$method"
        -H "X-Sdk-Date: $dt" -H "X-Sdk-Content-Sha256: $body_sha"
        -H "Content-Type: application/json" -H "Authorization: $auth")
    [[ -n "$body" ]] && args+=(--data "$body")
    resp=$(curl "${args[@]}" "$url" 2>&1) || { echo "curl: $resp" >&2; return 1; }
    http="${resp##*$'\n'}"
    body_text="${resp%$'\n'*}"
    if [[ "$http" =~ ^2 ]]; then printf '%s' "$body_text"; return 0; fi
    echo "HTTP $http: $body_text" >&2
    return 1
}
# 集合类 endpoint:  URL 不带 '/', 签名带 '/'
# 资源类 endpoint:  URL 与签名一致 (都不带 '/')
api_列出zones()      { api_request GET "/v2/zones"             ""  "" "/v2/zones/"; }
api_列出记录单页()   { api_request GET "/v2.1/zones/$1/recordsets" "$2" "" "/v2.1/zones/$1/recordsets/"; }
api_获取记录详情()    { api_request GET "/v2.1/zones/$1/recordsets/$2" ""; }

api_列出记录() {
    # v2.1 才会完整返回智能线路 line 字段; limit 最大 500, 这里自动翻页拉全量。
    local zone_id="$1" marker="" query resp page_count total loaded next all="[]"
    while :; do
        query="limit=500"
        [[ -n "$marker" ]] && query="${query}&marker=${marker}"
        resp=$(api_列出记录单页 "$zone_id" "$query") || return 1

        page_count=$(echo "$resp" | jq -r '.recordsets | length') || return 1
        all=$(echo "$resp" | jq -c --argjson old "$all" '$old + (.recordsets // [])') || return 1
        loaded=$(echo "$all" | jq -r 'length') || return 1
        total=$(echo "$resp" | jq -r '.metadata.total_count // empty' 2>/dev/null || true)
        next=$(echo "$resp" | jq -r '.links.next // ""' 2>/dev/null || true)

        (( page_count == 0 )) && break
        [[ "$total" =~ ^[0-9]+$ ]] && (( loaded >= total )) && break
        [[ -z "$next" && "$page_count" -lt 500 ]] && break

        marker=$(echo "$resp" | jq -r '.recordsets[-1].id // ""')
        [[ -z "$marker" || "$marker" == "null" ]] && break
    done
    jq -nc --argjson recordsets "$all" '{recordsets:$recordsets, metadata:{total_count:($recordsets|length)}}'
}

# ---------------------------------------------------------------------
# 安装
# ---------------------------------------------------------------------
安装依赖() {
    信息 "安装系统依赖 (bash coreutils curl openssl jq ca-certificates)..."
    command -v apt-get >/dev/null || { 报错 "当前系统未找到 apt-get, 本脚本仅支持 Debian / Ubuntu"; return 1; }
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq || { 报错 "apt-get update 失败"; return 1; }
    apt-get install -y --no-install-recommends \
        bash coreutils curl openssl jq ca-certificates >/dev/null || { 报错 "依赖安装失败"; return 1; }
    提示 "依赖安装完成"
}
创建用户() {
    if ! id "$SERVICE_USER" &>/dev/null; then
        command -v useradd >/dev/null || { 报错 "未找到 useradd"; return 1; }
        useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER" || return 1
        提示 "已创建系统用户 $SERVICE_USER"
    fi
}
写入守护进程() {
    mkdir -p "$INSTALL_DIR" || return 1
    cat > "$DAEMON_BIN" <<'DAEMON_EOF'
#!/usr/bin/env bash
# Smart DNS Router 守护进程
# 每个 task = 一个域名规则:  TCP Ping 主目标 IP, 连续超阈值就调华为 DNS API 切到备目标 IP
set -uo pipefail
CONFIG_PATH="${CONFIG_FILE:-/etc/dns-router/config.json}"
HUAWEI_REGION="${HUAWEI_REGION:-cn-north-1}"
API_HOST="dns.${HUAWEI_REGION}.myhuaweicloud.com"

_log()  { printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" "${*:2}"; }
info()  { _log INFO  "$@"; }
warn()  { _log WARN  "$@" >&2; }
error() { _log ERROR "$@" >&2; }

require_env() {
    [[ -n "${HUAWEI_AK:-}" && -n "${HUAWEI_SK:-}" ]] || {
        warn "未设置 HUAWEI_AK / HUAWEI_SK, 守护进程进入空闲, 请配置后重启服务"
        sleep infinity
    }
    [[ -f "$CONFIG_PATH" ]] || { error "配置文件不存在: $CONFIG_PATH"; sleep infinity; }
    for c in jq curl openssl timeout; do
        command -v "$c" >/dev/null || { error "缺少命令: $c"; exit 2; }
    done
    jq -e '.tasks | type == "array"' "$CONFIG_PATH" >/dev/null || {
        error "配置文件格式错误: $CONFIG_PATH 需要包含 tasks 数组"
        sleep infinity
    }
}

# ----- 华为云 API 签名 -----
huawei_sign() {
    local method="$1" uri="$2" query="$3" body="$4" host="$5"
    local dt body_sha cr cr_sha sts sig
    dt=$(date -u +%Y%m%dT%H%M%SZ)
    body_sha=$(printf '%s' "$body" | openssl dgst -sha256 -hex | awk '{print $NF}')
    local ch="content-type:application/json
host:${host}
x-sdk-content-sha256:${body_sha}
x-sdk-date:${dt}
"
    local sh="content-type;host;x-sdk-content-sha256;x-sdk-date"
    cr=$(printf '%s\n%s\n%s\n%s\n%s\n%s' "$method" "$uri" "$query" "$ch" "$sh" "$body_sha")
    cr_sha=$(printf '%s' "$cr" | openssl dgst -sha256 -hex | awk '{print $NF}')
    sts=$(printf 'SDK-HMAC-SHA256\n%s\n%s' "$dt" "$cr_sha")
    sig=$(printf '%s' "$sts" | openssl dgst -sha256 -hmac "$HUAWEI_SK" -hex | awk '{print $NF}')
    printf '%s\t%s\t%s' "$dt" "$body_sha" \
        "SDK-HMAC-SHA256 Access=${HUAWEI_AK}, SignedHeaders=${sh}, Signature=${sig}"
}

# 通用 API 调用: 2xx 返回 body, 否则返回 1 并记录详细错误
api_call() {
    # 入: METHOD URI QUERY [BODY] [SIGN_URI]
    # 集合端点 URL 不带末尾 '/', 但签名规范路径带 '/', 否则部分区域会 401/404。
    local method="$1" uri="$2" query="${3:-}" body="${4:-}" sign_uri="${5:-$2}"
    local sig dt body_sha auth url resp http body_text
    sig=$(huawei_sign "$method" "$sign_uri" "$query" "$body" "$API_HOST")
    IFS=$'\t' read -r dt body_sha auth <<< "$sig"
    url="https://${API_HOST}${uri}"
    [[ -n "$query" ]] && url="${url}?${query}"

    local args=(-sS --max-time 10 -w '\n%{http_code}' -X "$method"
        -H "X-Sdk-Date: $dt" -H "X-Sdk-Content-Sha256: $body_sha"
        -H "Content-Type: application/json" -H "Authorization: $auth")
    [[ -n "$body" ]] && args+=(--data "$body")

    resp=$(curl "${args[@]}" "$url" 2>&1) || {
        error "curl 失败 ($method $uri): $resp"
        return 1
    }
    http="${resp##*$'\n'}"
    body_text="${resp%$'\n'*}"
    if [[ "$http" =~ ^2 ]]; then
        printf '%s' "$body_text"
        return 0
    fi
    error "API $method $uri 返回 HTTP $http: $body_text"
    return 1
}

# 用父域名(zone)反查 zone_id, 完全匹配; 找不到时把账号下所有 zone 列出来辅助排错
api_resolve_zone_id() {
    local zone="$1"
    local resp id
    resp=$(api_call GET "/v2/zones" "name=${zone}" "" "/v2/zones/") || return 1
    # API 返回的 name 带末尾点, 做精确匹配
    id=$(echo "$resp" | jq -r --arg name "${zone}." \
        '.zones[]? | select(.name == $name) | .id' | head -1)
    if [[ -z "$id" ]]; then
        warn "未找到与 '$zone' 完全匹配的公网 zone。账号下已有的 zone:"
        echo "$resp" | jq -r '.zones[]? | "    • \(.name)  (id=\(.id))"' >&2 || true
        warn "请检查华为云 DNS 控制台是否已添加该 zone, 或脚本中填错"
        return 1
    fi
    echo "$id"
}

# 用完整域名 + 类型 + 线路反查 recordset_id (精确匹配 type 和 line)
api_resolve_recordset_id() {
    local zone_id="$1" fqdn="$2" rtype="${3:-A}" line="${4:-default}"
    local resp id
    resp=$(api_call GET "/v2.1/zones/${zone_id}/recordsets" "name=${fqdn}.&type=${rtype}&search_mode=equal&limit=500" "" "/v2.1/zones/${zone_id}/recordsets/") || return 1
    id=$(echo "$resp" | jq -r --arg n "${fqdn}." --arg t "$rtype" --arg l "$line" \
         'def normline($x): if ($x == null or $x == "" or $x == "default" or $x == "default_view") then "default_view" else $x end;
          .recordsets[]? | select(.name == $n and .type == $t and (normline(.line) == normline($l))) | .id' | head -1)
    if [[ -z "$id" ]]; then
        warn "在 zone 内未找到匹配记录 (name=$fqdn, type=$rtype, line=$line)。zone 内已有记录:"
        echo "$resp" | jq -r '.recordsets[]? | "    • \(.name)  type=\(.type)  line=\(.line // "default_view")  → \((.records // []) | join(","))"' >&2 || true
        return 1
    fi
    echo "$id"
}

api_get_current_record() {
    local zone_id="$1" rs_id="$2" resp
    resp=$(api_call GET "/v2.1/zones/${zone_id}/recordsets/${rs_id}") || return 1
    echo "$resp" | jq -r '.records[0] // ""'
}

api_update_record() {
    local zone_id="$1" rs_id="$2" fqdn="$3" rtype="$4" target="$5" ttl="$6"
    local body
    body=$(jq -nc --arg name "${fqdn}." --arg t "$rtype" \
                  --argjson ttl "$ttl" --arg tgt "$target" \
        '{name:$name, type:$t, ttl:$ttl, records:[$tgt]}')
    api_call PUT "/v2.1/zones/${zone_id}/recordsets/${rs_id}" "" "$body" >/dev/null
}

# ----- TCP Ping (毫秒, 失败无输出) -----
tcp_ping() {
    local host="$1" port="$2" t="$3" s e
    s=$(date +%s%N)
    if timeout "$t" bash -c "exec 5<>/dev/tcp/$host/$port" 2>/dev/null; then
        e=$(date +%s%N)
        awk -v s="$s" -v e="$e" 'BEGIN{printf "%.2f", (e-s)/1000000}'
        return 0
    fi
    return 1
}

# ----- 任务 worker -----
task_worker() {
    local idx="$1"
    local NAME DOMAIN ZONE LINE RTYPE PRIMARY_TGT BACKUP_TGT PROBE_TGT MAX_LAT INTERVAL FAIL_THR REC_THR TTL TIMEOUT
    NAME=$(jq -r ".tasks[$idx].domain" "$CONFIG_PATH")
    DOMAIN=$NAME
    ZONE=$(jq -r ".tasks[$idx].zone" "$CONFIG_PATH")
    LINE=$(jq -r ".tasks[$idx].line // \"default\"" "$CONFIG_PATH")
    RTYPE=$(jq -r ".tasks[$idx].record_type // \"A\"" "$CONFIG_PATH")
    PRIMARY_TGT=$(jq -r ".tasks[$idx].primary_target // .tasks[$idx].primary_ip" "$CONFIG_PATH")
    BACKUP_TGT=$(jq -r ".tasks[$idx].backup_target  // .tasks[$idx].backup_ip"  "$CONFIG_PATH")
    PROBE_TGT=$(jq -r ".tasks[$idx].probe_target" "$CONFIG_PATH")
    MAX_LAT=$(jq -r ".tasks[$idx].max_latency_ms" "$CONFIG_PATH")
    INTERVAL=$(jq -r ".tasks[$idx].probe_interval" "$CONFIG_PATH")
    FAIL_THR=$(jq -r ".tasks[$idx].fail_threshold" "$CONFIG_PATH")
    REC_THR=$(jq -r ".tasks[$idx].recover_threshold" "$CONFIG_PATH")
    TTL=$(jq -r ".tasks[$idx].ttl // 1" "$CONFIG_PATH")
    TIMEOUT=$(jq -r ".tasks[$idx].probe_timeout // 2" "$CONFIG_PATH")

    local PROBE_HOST="${PROBE_TGT%:*}" PROBE_PORT="${PROBE_TGT##*:}"
    local -a missing=()
    local field value
    for field in NAME DOMAIN ZONE LINE RTYPE PRIMARY_TGT BACKUP_TGT PROBE_TGT MAX_LAT INTERVAL FAIL_THR REC_THR TTL TIMEOUT; do
        value="${!field:-}"
        [[ -n "$value" && "$value" != "null" ]] || missing+=("$field")
    done
    if (( ${#missing[@]} > 0 )); then
        error "[task#$idx] 配置缺少字段: ${missing[*]}, 已跳过"
        return 1
    fi
    case "$RTYPE" in
        A|AAAA|CNAME|MX|TXT|SRV|NS|SOA|CAA|PTR) ;;
        *) error "[$NAME] 不支持的记录类型: $RTYPE, 已跳过"; return 1 ;;
    esac
    if [[ "$PROBE_HOST" == "$PROBE_TGT" || -z "$PROBE_HOST" || ! "$PROBE_HOST" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ || ! "$PROBE_PORT" =~ ^[0-9]+$ ]]; then
        error "[$NAME] probe_target 格式错误: $PROBE_TGT, 应为 IPv4:端口, 已跳过"
        return 1
    fi
    if (( 10#$PROBE_PORT < 1 || 10#$PROBE_PORT > 65535 )); then
        error "[$NAME] probe_target 端口超出范围: $PROBE_TGT, 已跳过"
        return 1
    fi
    local IFS=. oct
    local -a octets=($PROBE_HOST)
    for oct in "${octets[@]}"; do
        (( 10#$oct <= 255 )) || {
            error "[$NAME] probe_target IPv4 超出范围: $PROBE_TGT, 已跳过"
            return 1
        }
    done
    for value in "$MAX_LAT" "$INTERVAL" "$FAIL_THR" "$REC_THR" "$TTL" "$TIMEOUT"; do
        [[ "$value" =~ ^[0-9]+$ ]] && (( 10#$value >= 1 )) || {
            error "[$NAME] 数值参数必须是大于 0 的整数, 已跳过"
            return 1
        }
    done

    trap 'exit 0' SIGTERM SIGINT

    # 启动时解析 zone_id 和 recordset_id (失败 60s 后重试, 不退出守护)
    local ZONE_ID="" RS_ID=""
    while [[ -z "$ZONE_ID" || -z "$RS_ID" ]]; do
        if [[ -z "$ZONE_ID" ]]; then
            ZONE_ID=$(api_resolve_zone_id "$ZONE") || ZONE_ID=""
            [[ -n "$ZONE_ID" ]] && info "[$NAME] 解析 zone '$ZONE' → $ZONE_ID"
        fi
        if [[ -n "$ZONE_ID" && -z "$RS_ID" ]]; then
            RS_ID=$(api_resolve_recordset_id "$ZONE_ID" "$DOMAIN" "$RTYPE" "$LINE") || RS_ID=""
            [[ -n "$RS_ID" ]] && info "[$NAME] 解析记录集 '$DOMAIN' type=$RTYPE line=$LINE → $RS_ID"
        fi
        if [[ -z "$ZONE_ID" || -z "$RS_ID" ]]; then
            warn "[$NAME] 解析失败, 60 秒后重试"
            sleep 60 & wait $! 2>/dev/null
        fi
    done

    # 自检当前指向
    local current cur_route="primary"
    current=$(api_get_current_record "$ZONE_ID" "$RS_ID" 2>/dev/null || echo "")
    if [[ "$current" == "$BACKUP_TGT" ]]; then
        cur_route="backup"
        info "[$NAME] 自检: 当前=$current → 初始=备目标"
    elif [[ "$current" == "$PRIMARY_TGT" ]]; then
        info "[$NAME] 自检: 当前=$current → 初始=主目标"
    else
        warn "[$NAME] 自检: 当前=$current 与配置不一致, 假设为主目标"
    fi

    info "[$NAME] worker 启动 type=$RTYPE line=$LINE 探测=${PROBE_HOST}:${PROBE_PORT} 阈值=${MAX_LAT}ms 失败x${FAIL_THR} 恢复x${REC_THR} 间隔=${INTERVAL}s TTL=${TTL}s"

    local fail_streak=0 rec_streak=0
    while :; do
        local lat is_bad=0
        lat=$(tcp_ping "$PROBE_HOST" "$PROBE_PORT" "$TIMEOUT") || lat=""

        if [[ -z "$lat" ]]; then
            is_bad=1
        else
            is_bad=$(awk -v l="$lat" -v t="$MAX_LAT" 'BEGIN{print (l>t)?1:0}')
        fi

        if (( is_bad )); then
            fail_streak=$((fail_streak+1)); rec_streak=0
        else
            rec_streak=$((rec_streak+1)); fail_streak=0
        fi

        local lat_str="${lat:-超时}"; [[ -n "$lat" ]] && lat_str="${lat}ms"
        info "[$NAME] ${PROBE_HOST}:${PROBE_PORT}=$lat_str 路由=$cur_route 失败=${fail_streak}/${FAIL_THR} 恢复=${rec_streak}/${REC_THR}"

        if [[ "$cur_route" == "primary" && "$fail_streak" -ge "$FAIL_THR" ]]; then
            warn "[$NAME] 触发切换: 主($PRIMARY_TGT) → 备($BACKUP_TGT)"
            if api_update_record "$ZONE_ID" "$RS_ID" "$DOMAIN" "$RTYPE" "$BACKUP_TGT" "$TTL"; then
                cur_route="backup"; fail_streak=0; rec_streak=0
                warn "[$NAME] DNS 已切到备目标 $BACKUP_TGT"
            else
                error "[$NAME] DNS 切换失败, 下轮重试"
            fi
        elif [[ "$cur_route" == "backup" && "$rec_streak" -ge "$REC_THR" ]]; then
            warn "[$NAME] 触发恢复: 备($BACKUP_TGT) → 主($PRIMARY_TGT)"
            if api_update_record "$ZONE_ID" "$RS_ID" "$DOMAIN" "$RTYPE" "$PRIMARY_TGT" "$TTL"; then
                cur_route="primary"; fail_streak=0; rec_streak=0
                warn "[$NAME] DNS 已切回主目标 $PRIMARY_TGT"
            else
                error "[$NAME] DNS 切换失败, 下轮重试"
            fi
        fi

        sleep "$INTERVAL" & wait $! 2>/dev/null
    done
}

declare -a WORKER_PIDS=()
shutdown_all() {
    warn "收到信号, 优雅退出..."
    for pid in "${WORKER_PIDS[@]}"; do kill -TERM "$pid" 2>/dev/null || true; done
    wait 2>/dev/null
    info "守护进程已退出"
    exit 0
}

main() {
    require_env
    local n; n=$(jq -r '.tasks | length' "$CONFIG_PATH")
    if (( n == 0 )); then
        warn "尚未配置任何域名规则, 守护进程空闲等待 (请用 dns-router 添加规则后重启服务)"
        trap 'exit 0' SIGTERM SIGINT
        sleep infinity & wait $! 2>/dev/null
        exit 0
    fi
    info "守护进程启动, 共 $n 条域名规则"
    trap shutdown_all SIGTERM SIGINT
    for ((i=0; i<n; i++)); do
        task_worker "$i" &
        WORKER_PIDS+=($!)
    done
    wait
}
main "$@"
DAEMON_EOF
    [[ -s "$DAEMON_BIN" ]] || { 报错 "守护进程写入失败"; return 1; }
    chmod 0755 "$DAEMON_BIN" || return 1
    chown "$SERVICE_USER:$SERVICE_USER" "$DAEMON_BIN" || return 1
    提示 "守护进程已写入"
}
写入systemd单元() {
    command -v systemctl >/dev/null || { 报错 "未找到 systemctl, 请在 systemd 环境中运行"; return 1; }
    cat > "$UNIT_FILE" <<UNIT_EOF
[Unit]
Description=Smart DNS Router Daemon
After=network-online.target
Wants=network-online.target
# 防止异常崩溃导致重启风暴: 10 分钟内最多重启 5 次
StartLimitIntervalSec=600
StartLimitBurst=5

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$DAEMON_BIN
Restart=on-failure
RestartSec=30
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$SERVICE

NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
RestrictRealtime=true
RestrictNamespaces=true
SystemCallArchitectures=native
CapabilityBoundingSet=
AmbientCapabilities=

[Install]
WantedBy=multi-user.target
UNIT_EOF
    systemctl daemon-reload || return 1
    提示 "systemd 服务已注册 (默认未启动, 配置完成后请选择启动)"
}
初始化配置() {
    if [[ ! -f $ENV_FILE ]]; then
        cat > "$ENV_FILE" <<EOF
# 华为云访问凭证 (敏感, 权限 0600)
HUAWEI_AK=
HUAWEI_SK=
HUAWEI_REGION=cn-north-1
EOF
    fi
    chmod 0600 "$ENV_FILE" || return 1
    chown "$SERVICE_USER:$SERVICE_USER" "$ENV_FILE" || return 1
    mkdir -p "$CONFIG_DIR" || return 1
    chown "$SERVICE_USER:$SERVICE_USER" "$CONFIG_DIR" || return 1
    chmod 0750 "$CONFIG_DIR" || return 1
    if [[ ! -f $CONFIG_FILE ]]; then
        echo '{"tasks": []}' > "$CONFIG_FILE"
    fi
    jq -e '.tasks | type == "array"' "$CONFIG_FILE" >/dev/null || { 报错 "配置文件不是合法 JSON tasks 数组: $CONFIG_FILE"; return 1; }
    chmod 0640 "$CONFIG_FILE" || return 1
    chown "$SERVICE_USER:$SERVICE_USER" "$CONFIG_FILE" || return 1
}
复制自身() {
    if [[ "$(realpath "$0")" != "$SELF_PATH" ]]; then
        cp -f "$0" "$SELF_PATH" || return 1
        chmod 0755 "$SELF_PATH" || return 1
        提示 "管理命令已安装: $(亮 dns-router)"
    fi
}
执行安装() {
    clear
    青 "════════ 开始安装 ════════"; echo
    local was_running=0
    已安装 && 正运行 && was_running=1
    安装依赖 || { 按键继续; return; }
    创建用户 || { 报错 "创建系统用户失败"; 按键继续; return; }
    写入守护进程 || { 按键继续; return; }
    写入systemd单元 || { 按键继续; return; }
    初始化配置 || { 按键继续; return; }
    复制自身 || { 报错 "复制管理命令失败"; 按键继续; return; }
    echo
    绿 "════════════════════════════════════════════════"
    绿 "  安装完成！请按顺序配置:"
    echo
    echo "  $(亮 1.) 在主菜单选择 [6] 修改华为云凭证 → 填 AK/SK"
    echo "  $(亮 2.) 选择 [8] 测试华为云 API 连接 → 验证凭证 + 看到 zone 列表"
    echo "  $(亮 3.) 选择 [7] 管理域名 → 添加你的第一条规则"
    echo "  $(亮 4.) 选择 [1] 启动服务"
    echo
    绿 "  之后任何时间输入 $(亮 dns-router) 都能进入本菜单"
    绿 "════════════════════════════════════════════════"
    if (( was_running )) && 确认 "服务之前正在运行, 是否立即重启加载新版脚本？"; then
        systemctl reset-failed "$SERVICE.service" 2>/dev/null
        systemctl restart "$SERVICE.service" && 提示 "已重启" || 报错 "重启失败, 请查看日志"
    fi
    按键继续
}
执行卸载() {
    if ! 已安装; then 警告 "尚未安装"; 按键继续; return; fi
    if ! 确认 "确认卸载吗？(配置和凭证将默认保留)"; then return; fi
    systemctl stop "$SERVICE.service" 2>/dev/null
    systemctl disable "$SERVICE.service" 2>/dev/null
    rm -f "$UNIT_FILE"
    systemctl daemon-reload
    rm -rf "$INSTALL_DIR"
    rm -f "$SELF_PATH"
    提示 "已卸载"
    if 确认 "是否同时删除配置和凭证？"; then
        rm -rf "$CONFIG_DIR" "$ENV_FILE"
        提示 "配置已清理"
    fi
    if id "$SERVICE_USER" &>/dev/null && 确认 "是否删除系统用户 $SERVICE_USER？"; then
        userdel "$SERVICE_USER" 2>/dev/null
    fi
    按键继续
    exit 0
}

# ---------------------------------------------------------------------
# 服务控制 (启动 = enable + start)
# ---------------------------------------------------------------------
执行_启动() {
    if (( $(任务数) == 0 )); then
        警告 "尚未添加任何域名规则, 启动后会空闲等待"
        if ! 确认 "仍要启动吗？"; then 按键继续; return; fi
    fi
    if ! 凭证已设置; then
        报错 "尚未设置华为云 AK/SK, 请先选择 [6]"; 按键继续; return
    fi
    systemctl reset-failed "$SERVICE.service" 2>/dev/null  # 清掉历史失败计数
    systemctl enable "$SERVICE.service" >/dev/null 2>&1
    systemctl start "$SERVICE.service" && 提示 "服务已启动并已设为开机自启" || 报错 "启动失败"
    按键继续
}
执行_停止() {
    systemctl stop "$SERVICE.service" && 提示 "服务已停止" || 报错 "停止失败"
    按键继续
}
执行_重启() {
    systemctl reset-failed "$SERVICE.service" 2>/dev/null
    systemctl restart "$SERVICE.service" && 提示 "服务已重启" || 报错 "重启失败"
    按键继续
}
执行_状态() {
    clear; 青 "════════ 服务状态 ════════"
    systemctl --no-pager status "$SERVICE.service" || true
    按键继续
}
执行_日志() {
    clear; 青 "════════ 实时日志 (Ctrl+C 退出) ════════"; echo
    journalctl -fu "$SERVICE.service" -n 50 || true
    按键继续
}

# ---------------------------------------------------------------------
# 凭证编辑
# ---------------------------------------------------------------------
写入env() {
    local ak="$1" sk="$2" region="${3:-}"
    [[ -z "$region" ]] && region=$(读取env HUAWEI_REGION)
    [[ -z "$region" ]] && region="cn-north-1"
    cat > "$ENV_FILE" <<EOF
# 华为云访问凭证 (敏感, 权限 0600)
HUAWEI_AK=$ak
HUAWEI_SK=$sk
HUAWEI_REGION=$region
EOF
    chmod 0600 "$ENV_FILE"
    chown "$SERVICE_USER:$SERVICE_USER" "$ENV_FILE"
}
执行_修改凭证() {
    while :; do
        clear
        local ak sk region masked
        ak=$(读取env HUAWEI_AK); sk=$(读取env HUAWEI_SK)
        region=$(读取env HUAWEI_REGION); [[ -z "$region" ]] && region="cn-north-1"
        masked="(未设置)"; [[ -n "$sk" ]] && masked="${sk:0:4}******"
        青 "════════ 华为云访问凭证 ════════"; echo
        echo "  当前 AK     : $(亮 "${ak:-(未设置)}")"
        echo "  当前 SK     : $(亮 "$masked")"
        echo "  当前 区域   : $(亮 "$region")  $(暗 "(API 端点 dns.${region}.myhuaweicloud.com)")"
        echo
        echo "  $(绿 1). 修改 HUAWEI_AK"
        echo "  $(绿 2). 修改 HUAWEI_SK"
        echo "  $(绿 3). 修改区域代码 (国内/国际站不同)"
        echo
        echo "  $(绿 0). 返回"
        echo
        local c; read -rp "$(黄 '请选择 [0-3]: ')" c
        case "$c" in
            1) local v; read -rp "请输入新 HUAWEI_AK: " v
               [[ -n "$v" ]] && { 写入env "$v" "$sk" "$region"; 提示 已保存; sleep 1; } ;;
            2) local v; read -rsp "请输入新 HUAWEI_SK (输入隐藏): " v; echo
               [[ -n "$v" ]] && { 写入env "$ak" "$v" "$region"; 提示 已保存; sleep 1; } ;;
            3) 修改区域 "$ak" "$sk" "$region" ;;
            0) 询问重启; return ;;
            *) 报错 "无效选项"; sleep 1 ;;
        esac
    done
}

修改区域() {
    local ak="$1" sk="$2" cur="$3"
    clear
    青 "════════ 修改华为云区域代码 ════════"; echo
    echo "  当前: $(亮 "$cur")"
    echo
    暗 "  常见区域参考:"
    暗 "  ─ 国内站 (console.huaweicloud.com) ─"
    暗 "    cn-north-1       华北-北京一"
    暗 "    cn-north-4       华北-北京四"
    暗 "    cn-east-3        华东-上海一"
    暗 "    cn-south-1       华南-广州"
    暗 "  ─ 国际站 (console-intl.huaweicloud.com) ─"
    暗 "    ap-southeast-1   亚太-新加坡"
    暗 "    ap-southeast-2   亚太-曼谷"
    暗 "    ap-southeast-3   亚太-香港"
    暗 "    af-south-1       非洲-约翰内斯堡"
    暗 "    sa-brazil-1      拉美-圣保罗"
    暗 "    eu-west-101      欧洲-巴黎"
    echo
    暗 "  完整列表: console URL 中 region= 的值"
    echo
    local v; read -rp "$(黄 '请输入新区域代码 (留空保持当前): ')" v
    [[ -z "$v" ]] && return
    写入env "$ak" "$sk" "$v"
    提示 "区域已改为 $v"
    sleep 1
}
询问重启() {
    if 已安装 && 正运行 && 确认 "配置已修改, 是否立即重启服务以应用？"; then
        systemctl restart "$SERVICE.service" && 提示 "已重启"
        sleep 1
    fi
}

# ---------------------------------------------------------------------
# 配置 IO
# ---------------------------------------------------------------------
原子写json() {
    local content="$1" tmp
    tmp=$(mktemp -p "$(dirname "$CONFIG_FILE")" .dns-router.XXXX) || { 报错 "创建临时配置文件失败"; return 1; }
    printf '%s\n' "$content" > "$tmp" || { rm -f "$tmp"; 报错 "写入临时配置文件失败"; return 1; }
    chmod --reference="$CONFIG_FILE" "$tmp" 2>/dev/null || chmod 0640 "$tmp"
    chown --reference="$CONFIG_FILE" "$tmp" 2>/dev/null || true
    mv "$tmp" "$CONFIG_FILE" || { rm -f "$tmp"; 报错 "替换配置文件失败"; return 1; }
}
jq设置() {
    local expr="$1"; shift
    local new
    new=$(jq "$@" "$expr" "$CONFIG_FILE") || { 报错 "jq 操作失败"; return 1; }
    原子写json "$new"
}

# ---------------------------------------------------------------------
# 输入助手
# ---------------------------------------------------------------------
读_整数() {
    local prompt="$1" default="$2" min="${3:-1}"
    local v
    while :; do
        if [[ -n "$default" ]]; then
            read -rp "$(黄 "$prompt") [默认 $(亮 "$default")]: " v
            [[ -z "$v" ]] && v="$default"
        else
            read -rp "$(黄 "$prompt"): " v
        fi
        [[ -z "$v" ]] && { 报错 "不能为空"; continue; }
        [[ "$v" =~ ^[0-9]+$ ]] || { 报错 "请输入整数"; continue; }
        (( v < min )) && { 报错 "不能小于 $min"; continue; }
        echo "$v"; return 0
    done
}
读_文本() {
    local prompt="$1" default="${2:-}" v
    if [[ -n "$default" ]]; then
        read -rp "$(黄 "$prompt") [默认 $(亮 "$default")]: " v
        [[ -z "$v" ]] && v="$default"
    else
        read -rp "$(黄 "$prompt"): " v
    fi
    echo "$v"
}
读_域名() {
    local prompt="$1" default="${2:-}" v
    while :; do
        v=$(读_文本 "$prompt" "$default")
        [[ -z "$v" ]] && { 报错 "不能为空"; continue; }
        校验域名 "$v" || { 报错 "不是合法域名 (示例: example.com)"; continue; }
        echo "$v"; return 0
    done
}
读_ip() {
    local prompt="$1" default="${2:-}" v
    while :; do
        v=$(读_文本 "$prompt" "$default")
        [[ -z "$v" ]] && { 报错 "不能为空"; continue; }
        校验ipv4 "$v" || { 报错 "不是合法 IPv4"; continue; }
        echo "$v"; return 0
    done
}
校验ipv6() {
    local ip="$1" left right part count=0
    local -a parts_left parts_right parts_full
    [[ -n "$ip" && "$ip" == *:* ]] || return 1
    [[ "$ip" =~ ^[0-9a-fA-F:]+$ ]] || return 1
    [[ "$ip" != *:::* ]] || return 1

    if [[ "$ip" == *::* ]]; then
        [[ "${ip#*::}" != *::* ]] || return 1
        left="${ip%%::*}"
        right="${ip#*::}"
        if [[ -n "$left" ]]; then
            IFS=: read -ra parts_left <<< "$left"
            for part in "${parts_left[@]}"; do
                [[ "$part" =~ ^[0-9a-fA-F]{1,4}$ ]] || return 1
                count=$((count+1))
            done
        fi
        if [[ -n "$right" ]]; then
            IFS=: read -ra parts_right <<< "$right"
            for part in "${parts_right[@]}"; do
                [[ "$part" =~ ^[0-9a-fA-F]{1,4}$ ]] || return 1
                count=$((count+1))
            done
        fi
        (( count <= 7 ))
    else
        IFS=: read -ra parts_full <<< "$ip"
        (( ${#parts_full[@]} == 8 )) || return 1
        for part in "${parts_full[@]}"; do
            [[ "$part" =~ ^[0-9a-fA-F]{1,4}$ ]] || return 1
        done
    fi
}
校验fqdn() {
    [[ "$1" =~ \.$ ]] && [[ "${1%.}" =~ ^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$ ]]
}
校验域名可选点() {
    local d="${1%.}"
    校验域名 "$d"
}
读_目标() {
    # 入: prompt rtype default
    local prompt="$1" rtype="$2" default="${3:-}" v
    while :; do
        v=$(读_文本 "$prompt" "$default")
        [[ -z "$v" ]] && { 报错 "不能为空"; continue; }
        case "$rtype" in
            A)     校验ipv4 "$v" && { echo "$v"; return 0; } || 报错 "需要 IPv4 地址 (例: 1.2.3.4)" ;;
            AAAA)  校验ipv6 "$v" && { echo "$v"; return 0; } || 报错 "需要 IPv6 地址 (例: 2001:db8::1)" ;;
            CNAME) 校验域名可选点 "$v" && { echo "$v"; return 0; } || 报错 "需要域名 (例: backup.example.com 或 backup.example.com.)" ;;
            *)     echo "$v"; return 0 ;;
        esac
    done
}
读_host端口() {
    local prompt="$1" default="${2:-}" v
    while :; do
        v=$(读_文本 "$prompt" "$default")
        [[ -z "$v" ]] && { 报错 "不能为空"; continue; }
        校验host端口 "$v" || { 报错 "格式应为 IP:端口 (例如 1.1.1.1:80)"; continue; }
        echo "$v"; return 0
    done
}

显示常用ping参考() {
    echo
    暗 "  ─ TCP Ping 目标参考 ─"
    暗 "  通常填【主目标 IP】+ 它已开放的端口, 例如:"
    暗 "    你的代理服务器:443    HTTPS / Trojan / Vless"
    暗 "    你的代理服务器:80     HTTP / WS"
    暗 "    你的代理服务器:22     SSH"
    暗 "  也可以是任何能代表"国内→该 IP"链路质量的目标"
    echo
}

# ---------------------------------------------------------------------
# 添加任务 (向导式)
# ---------------------------------------------------------------------
执行_添加域名() {
    clear
    青 "════════ 添加新域名规则 ════════"; echo

    if ! 凭证已设置; then
        报错 "请先 [6] 设置华为云 AK / SK"
        按键继续; return
    fi

    # ----- 第 1 步: 拉 zone 列表, 箭头选择 -----
    信息 "正在从华为云拉取所有公网 DNS Zone..."
    local zones_json
    zones_json=$(api_列出zones 2>&1) || {
        报错 "API 调用失败:"; echo "$zones_json"; echo
        警告 "请检查 AK/SK 是否正确, 或网络是否通"
        按键继续; return
    }
    local zone_count
    zone_count=$(echo "$zones_json" | jq -r '.zones | length' 2>/dev/null || echo 0)
    if (( zone_count == 0 )); then
        警告 "账号下没有任何公网 zone, 请先在华为云 DNS 控制台创建"
        按键继续; return
    fi

    local -a zone_names=() zone_ids=() zone_options=()
    while IFS=$'\t' read -r nm id; do
        zone_names+=("${nm%.}")  # 去末尾点
        zone_ids+=("$id")
        zone_options+=("${nm%.}  $(暗 "(id=${id:0:16}...)")")
    done < <(echo "$zones_json" | jq -r '.zones[] | "\(.name)\t\(.id)"')

    if ! 箭头菜单 "选择父域名 (Zone) — 共 $zone_count 个:" "${zone_options[@]}"; then
        警告 "已取消"; 按键继续; return
    fi
    local zone="${zone_names[$SELECTED_INDEX]}"
    local zone_id="${zone_ids[$SELECTED_INDEX]}"

    # ----- 第 2 步: 拉这个 zone 下所有记录集, 包括智能线路解析 -----
    clear
    信息 "正在拉取 [$zone] 下所有记录集 (含 A/AAAA/CNAME/MX/TXT/SRV/CAA/NS/SOA 等和智能线路)..."
    local rs_json
    rs_json=$(api_列出记录 "$zone_id" 2>&1) || {
        报错 "API 调用失败:"; echo "$rs_json"
        按键继续; return
    }
    local rs_count
    rs_count=$(echo "$rs_json" | jq -r '.recordsets | length' 2>/dev/null || echo 0)
    if (( rs_count == 0 )); then
        警告 "$zone 内没有任何记录集, 请先在华为云 DNS 控制台创建一条"
        暗 "  操作步骤: 控制台 → 公网解析 → $zone → 添加记录集"
        按键继续; return
    fi

    local -a rs_names=() rs_targets=() rs_ids=() rs_lines=() rs_types=() rs_options=()
    while IFS=$'\t' read -r nm tgt id ln rt status is_default; do
        local short="${nm%.}"
        local ln_label; ln_label=$(华为线路名 "$ln")
        rs_names+=("$short"); rs_targets+=("$tgt"); rs_ids+=("$id")
        rs_lines+=("${ln:-default_view}"); rs_types+=("$rt")
        local flag=""
        [[ "$status" != "ACTIVE" && -n "$status" && "$status" != "null" ]] && flag=" ${status}"
        [[ "$is_default" == "true" ]] && flag="${flag} 系统默认"
        rs_options+=("$(printf '%-34s [%-5s] [%-24s] → %s%s' "$short" "$rt" "${ln_label}(${ln:-default_view})" "$tgt" "$flag")")
    done < <(echo "$rs_json" | jq -r '.recordsets[]? |
        [
            (.name // ""),
            ((.records // []) | join(",")),
            (.id // ""),
            (.line // "default_view"),
            (.type // ""),
            (.status // ""),
            ((.default // false) | tostring)
        ] | @tsv')

    if ! 箭头菜单 "选择要管理的记录 — 共 $rs_count 条:" "${rs_options[@]}"; then
        警告 "已取消"; 按键继续; return
    fi
    local domain="${rs_names[$SELECTED_INDEX]}"
    local current_target="${rs_targets[$SELECTED_INDEX]}"
    local line="${rs_lines[$SELECTED_INDEX]}"
    local rtype="${rs_types[$SELECTED_INDEX]}"

    # ----- 第 3 步起: 文本输入剩余字段 -----
    clear
    青 "════════ 配置: $(亮 "$domain") ════════"; echo
    echo "  父域名      : $zone"
    echo "  记录类型    : $rtype"
    echo "  线路        : $(华为线路名 "$line")  $(暗 "($line)")"
    echo "  当前记录值  : $current_target"
    echo
    暗 "  下面填主备目标和阈值参数 (回车使用默认值)"
    echo

    local primary_target backup_target probe_tgt max_lat interval fail_thr rec_thr ttl timeout_s

    local 类型说明=""
    case "$rtype" in
        A)     类型说明="IPv4 地址, 例如 1.2.3.4" ;;
        AAAA)  类型说明="IPv6 地址, 例如 2001:db8::1" ;;
        CNAME) 类型说明="域名, 例如 backup.example.com 或 backup.example.com." ;;
        MX)    类型说明="MX 记录值, 例如 10 mail.example.com." ;;
        SRV)   类型说明="SRV 记录值, 例如 10 5 443 target.example.com." ;;
        TXT)   类型说明="TXT 文本, 保持华为云控制台里的记录值格式" ;;
        CAA)   类型说明="CAA 记录值, 例如 0 issue letsencrypt.org" ;;
        NS)    类型说明="NS 记录值, 例如 ns1.example.com." ;;
        SOA)   类型说明="SOA 记录值。通常不建议交给自动切换脚本修改" ;;
        PTR)   类型说明="PTR 记录值, 例如 host.example.com." ;;
        *)     类型说明="记录值按华为云该类型要求填写" ;;
    esac

    亮 "▶ 主目标 ($rtype)"
    暗 "  正常情况下域名解析到这个目标 (默认 = 当前记录值)"
    暗 "  $类型说明"
    primary_target=$(读_目标 "主目标" "$rtype" "$current_target") || return
    echo

    亮 "▶ 备目标 ($rtype)"
    暗 "  主目标延迟过高时自动切换到这个目标"
    暗 "  $类型说明"
    backup_target=$(读_目标 "备目标" "$rtype" "") || return
    echo

    亮 "▶ TCP Ping 目标 (host:端口)"
    暗 "  健康检查地址。可以是任何能代表线路质量的 IPv4:端口"
    if [[ "$rtype" == "A" ]]; then
        暗 "  默认使用主目标 IP, 端口 80"
        local default_probe="${primary_target}:80"
    else
        暗 "  AAAA/CNAME 任务的主目标不是 IPv4, 需要单独指定一个用于探测的 IPv4:端口"
        local default_probe=""
    fi
    显示常用ping参考
    probe_tgt=$(读_host端口 "TCP Ping 目标" "$default_probe") || return
    echo

    max_lat=$(读_整数 "最大允许延迟 (毫秒, 超此即算异常)" "80" 1) || return
    interval=$(读_整数 "探测间隔 (秒)" "5" 1) || return
    timeout_s=$(读_整数 "TCP 连接超时 (秒)" "2" 1) || return
    fail_thr=$(读_整数 "失败次数 (连续 N 次异常切到备目标)" "6" 1) || return
    rec_thr=$(读_整数 "恢复次数 (连续 N 次正常切回主目标)" "18" 1) || return
    ttl=$(读_整数 "TTL 秒" "1" 1) || return
    echo

    青 "═══ 即将保存 ═══"
    echo "  父域名      : $zone"
    echo "  完整域名    : $domain"
    echo "  记录类型    : $rtype"
    echo "  线路        : $(华为线路名 "$line")  $(暗 "($line)")"
    echo "  主目标      : $primary_target"
    echo "  备目标      : $backup_target"
    echo "  探测目标    : $probe_tgt"
    echo "  最大延迟    : ${max_lat} ms"
    echo "  探测间隔    : ${interval} 秒"
    echo "  连接超时    : ${timeout_s} 秒"
    echo "  失败次数    : ${fail_thr} 次"
    echo "  恢复次数    : ${rec_thr} 次"
    echo "  TTL         : ${ttl} 秒"
    echo
    if ! 确认 "确认保存？"; then 警告 "已取消"; 按键继续; return; fi

    jq设置 '.tasks += [{
        domain:$d, zone:$z, line:$ln, record_type:$rtype,
        primary_target:$p, backup_target:$b,
        probe_target:$pt,
        max_latency_ms:$ml, probe_interval:$pi, probe_timeout:$to,
        fail_threshold:$ft, recover_threshold:$recover,
        ttl:$ttl
    }]' \
        --arg d "$domain" --arg z "$zone" --arg ln "$line" --arg rtype "$rtype" \
        --arg p "$primary_target" --arg b "$backup_target" \
        --arg pt "$probe_tgt" \
        --argjson ml "$max_lat" --argjson pi "$interval" --argjson to "$timeout_s" \
        --argjson ft "$fail_thr" --argjson recover "$rec_thr" \
        --argjson ttl "$ttl"

    提示 "已添加: $domain"
    echo
    if 已安装 && 正运行 && 确认 "立即重启服务以生效？"; then
        systemctl reset-failed "$SERVICE.service" 2>/dev/null
        systemctl restart "$SERVICE.service" && 提示 "已重启"
    fi
    按键继续
}

# ---------------------------------------------------------------------
# 编辑/查看单条任务
# ---------------------------------------------------------------------
执行_编辑域名() {
    local idx="$1"
    while :; do
        clear
        local domain zone rtype nip dip pt ml iv ft rt ttl ln to
        domain=$(jq -r ".tasks[$idx].domain" "$CONFIG_FILE")
        zone=$(jq -r ".tasks[$idx].zone" "$CONFIG_FILE")
        rtype=$(jq -r ".tasks[$idx].record_type // \"A\"" "$CONFIG_FILE")
        nip=$(jq -r ".tasks[$idx].primary_target // .tasks[$idx].primary_ip" "$CONFIG_FILE")
        dip=$(jq -r ".tasks[$idx].backup_target  // .tasks[$idx].backup_ip"  "$CONFIG_FILE")
        pt=$(jq -r ".tasks[$idx].probe_target" "$CONFIG_FILE")
        ml=$(jq -r ".tasks[$idx].max_latency_ms" "$CONFIG_FILE")
        iv=$(jq -r ".tasks[$idx].probe_interval" "$CONFIG_FILE")
        to=$(jq -r ".tasks[$idx].probe_timeout // 2" "$CONFIG_FILE")
        ft=$(jq -r ".tasks[$idx].fail_threshold" "$CONFIG_FILE")
        rt=$(jq -r ".tasks[$idx].recover_threshold" "$CONFIG_FILE")
        ttl=$(jq -r ".tasks[$idx].ttl // 1" "$CONFIG_FILE")
        ln=$(jq -r ".tasks[$idx].line // \"default\"" "$CONFIG_FILE")

        青 "════════ 编辑域名: $domain ════════"; echo
        printf "      %-22s : %s\n" "父域名 (Zone)"      "$zone"
        printf "      %-22s : %s\n" "完整域名"           "$domain"
        printf "      %-22s : %s\n" "记录类型"           "$rtype"
        printf "      %-22s : %s  $(暗 "($ln)")\n" "线路" "$(华为线路名 "$ln")"
        echo "      $(暗 "(以上字段不可修改, 如需更换请删除后重新添加)")"
        echo
        printf "  %s. %-22s : %s\n" "$(绿 3)" "主目标"             "$nip"
        printf "  %s. %-22s : %s\n" "$(绿 4)" "备目标"             "$dip"
        printf "  %s. %-22s : %s\n" "$(绿 5)" "TCP Ping 目标"      "$pt"
        printf "  %s. %-22s : %s 毫秒\n" "$(绿 6)" "最大允许延迟"  "$ml"
        printf "  %s. %-22s : %s 秒\n" "$(绿 7)" "探测间隔"        "$iv"
        printf "  %s. %-22s : %s 次\n" "$(绿 8)" "失败次数(切换)"  "$ft"
        printf "  %s. %-22s : %s 次\n" "$(绿 9)" "恢复次数(切回)"  "$rt"
        printf "  %s. %-22s : %s 秒\n" "$(绿 10)" "TTL"            "$ttl"
        printf "  %s. %-22s : %s 秒\n" "$(绿 11)" "TCP 连接超时"   "$to"
        echo
        echo "  $(绿 0). 返回上层"
        echo
        local c; read -rp "$(黄 '请选择要修改的项 [0,3-11]: ')" c
        case "$c" in
            3) local v; v=$(读_目标 "新主目标 ($rtype)" "$rtype" "$nip"); jq设置 ".tasks[$idx].primary_target=\$v" --arg v "$v" ;;
            4) local v; v=$(读_目标 "新备目标 ($rtype)" "$rtype" "$dip"); jq设置 ".tasks[$idx].backup_target=\$v" --arg v "$v" ;;
            5) 显示常用ping参考
               local v; v=$(读_host端口 "新探测目标" "$pt"); jq设置 ".tasks[$idx].probe_target=\$v" --arg v "$v" ;;
            6) local v; v=$(读_整数 "新最大允许延迟 ms" "$ml" 1); jq设置 ".tasks[$idx].max_latency_ms=\$v" --argjson v "$v" ;;
            7) local v; v=$(读_整数 "新探测间隔秒" "$iv" 1); jq设置 ".tasks[$idx].probe_interval=\$v" --argjson v "$v" ;;
            8) local v; v=$(读_整数 "新失败次数" "$ft" 1); jq设置 ".tasks[$idx].fail_threshold=\$v" --argjson v "$v" ;;
            9) local v; v=$(读_整数 "新恢复次数" "$rt" 1); jq设置 ".tasks[$idx].recover_threshold=\$v" --argjson v "$v" ;;
           10) local v; v=$(读_整数 "新 TTL 秒" "$ttl" 1); jq设置 ".tasks[$idx].ttl=\$v" --argjson v "$v" ;;
           11) local v; v=$(读_整数 "新 TCP 连接超时秒" "$to" 1); jq设置 ".tasks[$idx].probe_timeout=\$v" --argjson v "$v" ;;
            0) 询问重启; return ;;
            *) 报错 "无效选项"; sleep 1 ;;
        esac
    done
}

# ---------------------------------------------------------------------
# 域名列表 (箭头菜单)
# ---------------------------------------------------------------------
执行_管理域名() {
    while :; do
        local n; n=$(任务数)
        local -a opts=()
        if (( n > 0 )); then
            local i
            for ((i=0; i<n; i++)); do
                local dm pt bt ln rt ln_label
                dm=$(jq -r ".tasks[$i].domain" "$CONFIG_FILE")
                pt=$(jq -r ".tasks[$i].primary_target // .tasks[$i].primary_ip" "$CONFIG_FILE")
                bt=$(jq -r ".tasks[$i].backup_target  // .tasks[$i].backup_ip"  "$CONFIG_FILE")
                ln=$(jq -r ".tasks[$i].line // \"default\"" "$CONFIG_FILE")
                rt=$(jq -r ".tasks[$i].record_type // \"A\"" "$CONFIG_FILE")
                ln_label=$(华为线路名 "$ln")
                opts+=("$(printf '%-28s [%-5s] [%-22s]  %s ←→ %s' "$dm" "$rt" "${ln_label}(${ln})" "$pt" "$bt")")
            done
            opts+=("─────────────")
        fi
        opts+=("➕ 添加新域名规则")
        opts+=("← 返回主菜单")

        if ! 箭头菜单 "域名规则列表 (共 $n 条):" "${opts[@]}"; then
            return
        fi

        local idx=$SELECTED_INDEX
        local total=${#opts[@]}
        if (( idx == total - 1 )); then
            return  # 返回主菜单
        elif (( idx == total - 2 )); then
            执行_添加域名
        elif (( n > 0 && idx == n )); then
            : # 分隔线, 忽略
        elif (( idx >= 0 && idx < n )); then
            # 选中某条规则 → 二级菜单 (查看/编辑/删除)
            local dm; dm=$(jq -r ".tasks[$idx].domain" "$CONFIG_FILE")
            local sub_opts=("✎ 编辑此规则" "✗ 删除此规则" "← 返回列表")
            if 箭头菜单 "已选中: $dm" "${sub_opts[@]}"; then
                case "$SELECTED_INDEX" in
                    0) 执行_编辑域名 "$idx" ;;
                    1)
                        if 确认 "确认删除 [$dm] 吗？"; then
                            jq设置 ".tasks |= del(.[$idx])"
                            提示 "已删除"
                            if 已安装 && 正运行 && 确认 "立即重启服务以生效？"; then
                                systemctl reset-failed "$SERVICE.service" 2>/dev/null
                                systemctl restart "$SERVICE.service" && 提示 "已重启"
                            fi
                            sleep 1
                        fi ;;
                    2) : ;;  # 返回列表
                esac
            fi
        fi
    done
}

# ---------------------------------------------------------------------
# 测试华为云 API 连接 (列出账号下所有公网 zone, 用于排错)
# ---------------------------------------------------------------------
执行_测试连接() {
    clear
    青 "════════ 测试华为云 API 连接 ════════"; echo
    if ! 凭证已设置; then 报错 "尚未设置 AK/SK, 请先选择 [6]"; 按键继续; return; fi

    local region; region=$(读取env HUAWEI_REGION); [[ -z "$region" ]] && region="cn-north-1"
    信息 "区域 = $region  (端点 dns.${region}.myhuaweicloud.com)"
    信息 "调用 GET /v2/zones ..."
    echo
    local resp err
    resp=$(api_列出zones 2>&1) || err=1
    if [[ -z "${err:-}" ]]; then
        local n; n=$(echo "$resp" | jq -r '.zones | length' 2>/dev/null || echo 0)
        提示 "API 连接成功, 账号下共有 $n 个公网 zone:"
        echo
        if (( n == 0 )); then
            警告 "无任何公网 zone, 请先在华为云控制台添加"
        else
            echo "$resp" | jq -r '.zones[]? | "  • \(.name)  (id=\(.id))"'
        fi
    else
        报错 "API 调用失败:"; echo "  $resp"; echo
        case "$resp" in
            *401*) 警告 "AK / SK 错误, 或 SK 末尾混了空格 → [6] 重新设置" ;;
            *403*) 警告 "权限不足, 请检查 IAM 子用户是否授权了 DNS 操作" ;;
            *404*) 警告 "API 不存在 — 多半是【区域代码】不对!"
                   暗 "  你账号在哪个 region 控制台 → 改成那个 → [6] → 修改区域代码" ;;
            *curl*) 警告 "网络不通, 检查能否访问 dns.${region}.myhuaweicloud.com" ;;
            *)     警告 "未知错误, 详见上方响应" ;;
        esac
    fi
    按键继续
}

# ---------------------------------------------------------------------
# 状态行 + 主菜单
# ---------------------------------------------------------------------
显示状态行() {
    if 已安装; then
        local svc auto cnt cred region
        正运行       && svc="$(绿 ●运行中)"   || svc="$(红 ●已停止)"
        已开机自启   && auto="$(绿 是)"        || auto="$(暗 否)"
        cnt=$(任务数)
        凭证已设置   && cred="$(绿 已设置)"    || cred="$(红 未设置)"
        region=$(读取env HUAWEI_REGION); [[ -z "$region" ]] && region="cn-north-1"
        echo "  安装状态  : $(绿 已安装) v$VERSION"
        echo "  服务状态  : $svc      开机自启 : $auto"
        echo "  凭证      : $cred      区域     : $(亮 "$region")"
        echo "  域名规则  : $(亮 "$cnt") 条"
    else
        echo "  $(红 ○ 未安装) — 请选择 [1] 安装"
    fi
}

主菜单() {
    while :; do
        clear; echo
        青 "  ┌──────────────────────────────────────────────┐"
        青 "  │                                              │"
        青 "  │      Smart DNS Router 智能 DNS 调度          │"
        青 "  │      华为云 · TCP Ping · 自动切换 · v$VERSION    │"
        青 "  │                                              │"
        青 "  └──────────────────────────────────────────────┘"
        echo
        显示状态行
        echo
        if 已安装; then
            echo "  $(绿 1). 启动服务         $(绿 2). 停止服务         $(绿 3). 重启服务"
            echo "  $(绿 4). 查看服务状态     $(绿 5). 查看实时日志"
            echo "  $(暗 ─────────────────────────────────────────)"
            echo "  $(绿 6). 修改华为云凭证 (AK/SK)"
            echo "  $(绿 7). 管理域名规则 (添加 / 编辑 / 删除)"
            echo "  $(绿 8). 测试华为云 API 连接 (列出账号下所有 zone)"
            echo "  $(暗 ─────────────────────────────────────────)"
            echo "  $(绿 9). 重新安装 / 升级"
            echo "  $(红 10). 卸载脚本"
        else
            echo "  $(绿 1). 安装服务"
        fi
        echo
        echo "  $(绿 0). 退出"
        echo
        local c; read -rp "$(黄 '请输入选项: ')" c

        if ! 已安装; then
            case "$c" in
                1) 执行安装 ;;
                0) clear; exit 0 ;;
                *) 报错 "无效选项"; sleep 1 ;;
            esac
            continue
        fi

        case "$c" in
            1)  执行_启动 ;;
            2)  执行_停止 ;;
            3)  执行_重启 ;;
            4)  执行_状态 ;;
            5)  执行_日志 ;;
            6)  执行_修改凭证 ;;
            7)  执行_管理域名 ;;
            8)  执行_测试连接 ;;
            9)  执行安装 ;;
            10) 执行卸载 ;;
            0)  clear; exit 0 ;;
            *)  报错 "无效选项"; sleep 1 ;;
        esac
    done
}

# ---------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------
确保入口依赖() {
    local -a missing=()
    local c
    for c in jq curl openssl; do
        command -v "$c" >/dev/null || missing+=("$c")
    done
    (( ${#missing[@]} == 0 )) && return 0

    信息 "首次运行检测到缺少依赖: ${missing[*]}, 自动安装..."
    command -v apt-get >/dev/null || { 报错 "当前系统未找到 apt-get, 无法自动安装依赖"; exit 1; }
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq || { 报错 "apt-get update 失败"; exit 1; }
    apt-get install -y --no-install-recommends jq curl openssl ca-certificates >/dev/null || { 报错 "依赖安装失败"; exit 1; }
}

要求root
确保入口依赖
主菜单
